import type { Config } from 'tailwindcss';

export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0D1B2A', soft: '#465466' },
        paper: '#F2F5F8',
        line: '#D5DCE4',
        cyan: { ink: '#00A3E0' },
        magenta: { ink: '#E6007E' },
        yellow: { ink: '#FFD500' },
        brand: { DEFAULT: '#0B5FD8', dark: '#0847A3' },
      },
      fontFamily: {
        display: ['var(--font-display)', 'Trebuchet MS', 'sans-serif'],
        sans: ['var(--font-body)', 'Segoe UI', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
} satisfies Config;
