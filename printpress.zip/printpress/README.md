# PrintPress

Multi-tenant SaaS for printing presses. Each press gets a branded public page, a QR code that opens its order form, customer ordering with private file uploads, order and payment management, staff accounts and revenue analytics. A platform super admin approves presses, manages users, monitors orders, reads the audit log and manages settings and plans.

**Stack:** Next.js 15 (App Router, Server Actions) · TypeScript · Tailwind CSS · Supabase (PostgreSQL, Auth, Storage) · zod · Recharts · qrcode

## Status: read this first

This codebase was written in an environment with **no network access**, so it has **not been installed, built or run against a live Supabase project**. What was verified there:

| Check | Result |
|---|---|
| All 71 TS/TSX files parse (TypeScript compiler API) | pass |
| Unit tests: pricing engine, upload validation, opening hours (`npm test`, 17 tests) | pass |
| Dependency-free core modules type-check under `strict` | pass |
| SQL migrations, RLS policies, RPCs | **not executed** |
| Full `next build` / `tsc --noEmit` with real dependencies | **not run** |
| End-to-end flows in a browser | **not run** |

Expect a small number of fixes on first run (type errors against the real Supabase/Next types, SQL typos). Work through the smoke-test checklist below before going live.

## Setup

1. Create a Supabase project.
2. Run the migrations in order in the SQL editor (or `supabase db push`):
   - `supabase/migrations/001_core_schema.sql`
   - `supabase/migrations/002_rate_limit_and_analytics.sql`
3. Copy `.env.example` to `.env.local` and fill in the URL, anon key and **service role key** (server only).
4. Supabase dashboard, Authentication:
   - URL configuration: set Site URL to `NEXT_PUBLIC_APP_URL` and add `<app url>/auth/callback` to redirect URLs.
   - Email templates (Confirm signup and Invite user): point the link at
     `{{ .SiteURL }}/auth/callback?token_hash={{ .TokenHash }}&type=signup` (and `type=invite`).
   - Configure SMTP for production (the built-in mailer is rate limited).
5. `npm install`, then `npm run seed` (creates demo data), then `npm run dev`.

Seed logins (password `Demo#Press2026!`, override with `SEED_PASSWORD`): `admin@printpress.test` (super admin), `ama@cityline.test` (owner), `abena@cityline.test` (manager), `kwesi@cityline.test` (staff), `kofi@quickcopy.test`, `esi@pixelpress.test` (pending press), `yaw@oldtown.test` (suspended press). **Never seed a production project.**

## Architecture

```
supabase/migrations   schema, RLS, triggers, storage policies, analytics + rate-limit functions
src/lib/pricing       pure pricing engine (integer minor units), shared by browser preview and server
src/lib/security      upload validation (magic bytes), origin check, Postgres rate limiter
src/lib/auth          session helpers: requireUser / requireSuperAdmin / requirePress(minRole)
src/lib/supabase      server (RLS), admin (service role, server only), browser, public (anon) clients
src/app/p/[slug]      public storefront, order form, order APIs at /api/public/*
src/app/dashboard     press dashboard (owner / manager / staff)
src/app/admin         super admin dashboard
scripts/seed.ts       demo data
```

**Tenant isolation.** Every tenant row has `press_id`. Row Level Security decides access in the database (`has_press_role`, `is_press_member`, `is_super_admin`), so an application bug cannot read another press's rows. App code uses the session-bound client by default. The service-role client is used only for public order creation, storage signing, invitations, audit inserts, rate limiting and seeding.

**Customer order flow.** (1) `POST /api/public/orders` validates input, rate-limits, recomputes prices from the database (client prices are ignored), creates a hidden *draft* order and returns one-time signed upload URLs. (2) The browser uploads directly to the private `order-files` bucket. (3) `POST /api/public/orders/:id/finalize` reads each object's real size and first bytes, rejects mismatches (deleting the draft and files), then publishes the order and assigns its order number.

**Files.** Private bucket, no public URLs. Staff download through `/api/files/:id`, which checks membership of the file's own press and redirects to a 60-second signed URL, and logs the download. Super admins cannot open customer files.

## Security summary

Auth via Supabase (password policy, generic login errors, per-IP and per-account rate limits) · role checks in server code and RLS · strict security headers plus nonce-based CSP (`src/middleware.ts`) · origin check on public POST endpoints · zod validation on every input · parameterised queries only (Supabase client), search input sanitised before use in filters · upload type/size/magic-byte checks · append-only audit log (DB triggers block update and delete) · payments are voided, never deleted · suspended presses lose access at the database level · deactivated users are banned in Auth.

Deployment notes: rate limiting keys on `x-forwarded-for`, so deploy behind a proxy that sets it (Vercel does). Schedule `select public.run_maintenance()` hourly (pg_cron) to purge stale drafts and old rate-limit rows; storage objects of purged drafts should be swept by a scheduled job (not included).

## Smoke-test checklist

1. Register a new account, create a press at `/onboarding`, confirm the dashboard shows the "awaiting approval" banner and `/p/<slug>` returns 404.
2. Sign in as `admin@printpress.test`, approve it under Printing presses, confirm the public page loads.
3. As the owner add a service and a price, edit opening hours, upload a logo, download the QR code.
4. Scan or open the QR link, place an order with a PDF and a JPG. Then try a renamed `.exe` as `.pdf` and confirm it is rejected.
5. Confirm the order appears in the dashboard with the price you saw, download a file, record a partial then full payment, void one, and check totals.
6. Log in as staff and confirm no access to Services, Staff, Settings or Analytics.
7. Log in as `kofi@quickcopy.test` and confirm none of Cityline's orders, files or staff are visible (isolation).
8. Suspend a press as admin: its page goes offline and its owner sees the suspended notice.
9. Deactivate a user: they are signed out and cannot log back in.
10. Check `/admin/logs` shows sign-ins, approvals, payments and the file download.
11. Track an order at `/track` with its code and phone; confirm a wrong phone gives the generic error.

## Extending

- **Paystack:** `payments.provider` and `reference` already exist. Add `/api/webhooks/paystack` (verify the signature, insert a payment with `provider='paystack'` using the service client). The order form's "pay online" step slots in after finalize.
- **WhatsApp / notifications:** add an `outbox` table written by DB triggers on `orders.status`, and a worker that sends messages. Customer phone and email are already on the order.
- **Printer integration:** a device token table plus a queue endpoint that hands out verified files as signed URLs.
- **AI document optimisation:** run after finalize on verified files, storing results beside `order_files.page_count`.
- **Marketplace:** the `storefronts` / `storefront_prices` views are the public read model; add a listing page over them.
- **Plans:** limits are stored in `plans.limits` and assigned per press; enforcement is not implemented yet.

## Known gaps

No multi-press membership switcher (a user belongs to one press), no automated browser tests, no email notifications to customers, plan limits are recorded but not enforced, storage sweep for abandoned drafts is manual, and order discounts are applied per line rather than as an order-level field.
