/**
 * Demo data: 1 super admin, 4 presses (approved / pending / suspended), staff, services,
 * prices, ~135 orders across 45 days with items and payments.
 * Idempotent: safe to run again. Refuses to run in production.
 *
 *   npm run seed        (reads .env.local)
 */
import { createClient } from '@supabase/supabase-js';
import { normalizeTiers, quoteLine, toMinor } from '../src/lib/pricing/engine.ts';

if (process.env.NODE_ENV === 'production') throw new Error('Refusing to seed in production.');
const url = process.env.NEXT_PUBLIC_SUPABASE_URL; const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw new Error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (see .env.example).');
const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
const PASSWORD = process.env.SEED_PASSWORD ?? 'Demo#Press2026!';

// Deterministic pseudo-random so reruns and screenshots are stable.
let seed = 42; const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const pickOne = <T,>(a: T[]): T => a[Math.floor(rnd() * a.length)]!;
const int = (a: number, b: number) => a + Math.floor(rnd() * (b - a + 1));

async function user(email: string, name: string): Promise<string> {
  const { data: existing } = await db.from('profiles').select('id').eq('email', email).maybeSingle();
  if (existing) return existing.id;
  const { data, error } = await db.auth.admin.createUser({ email, password: PASSWORD, email_confirm: true, user_metadata: { full_name: name } });
  if (error || !data.user) throw new Error(`createUser ${email}: ${error?.message}`);
  return data.user.id;
}

const hours = (o: string, c: string, satC = '15:00') => ({ mon: { open: o, close: c }, tue: { open: o, close: c }, wed: { open: o, close: c }, thu: { open: o, close: c }, fri: { open: o, close: c }, sat: { open: '09:00', close: satC }, sun: null });
const TIERS = [{ min_qty: 100, percent_off: 10 }, { min_qty: 500, percent_off: 20 }];

type Tier = { min_qty: number; percent_off: number };
type RuleDef = [label: string, paper: string, color: 'bw' | 'color', sides: 'single' | 'double', unit: 'per_page' | 'per_item', price: number, tiers: Tier[]];
const CATALOG: { name: string; description: string; rules: RuleDef[] }[] = [
  { name: 'Document printing', description: 'Reports, CVs, assignments and slides on 80gsm paper.', rules: [
    ['A4 black and white, single-sided', 'A4', 'bw', 'single', 'per_page', 0.5, TIERS], ['A4 black and white, double-sided', 'A4', 'bw', 'double', 'per_page', 0.4, TIERS],
    ['A4 colour, single-sided', 'A4', 'color', 'single', 'per_page', 2, TIERS], ['A4 colour, double-sided', 'A4', 'color', 'double', 'per_page', 1.6, TIERS], ['A3 colour, single-sided', 'A3', 'color', 'single', 'per_page', 5, []] ] },
  { name: 'Photocopying', description: 'Bring originals or upload a scan.', rules: [['A4 black and white', 'A4', 'bw', 'single', 'per_page', 0.3, TIERS], ['A3 black and white', 'A3', 'bw', 'single', 'per_page', 0.8, []]] },
  { name: 'Posters and banners', description: 'Large format on gloss or matte stock.', rules: [['A2 poster, colour', 'A2', 'color', 'single', 'per_item', 25, []], ['A1 poster, colour', 'A1', 'color', 'single', 'per_item', 40, []], ['A0 poster, colour', 'A0', 'color', 'single', 'per_item', 70, []]] },
  { name: 'Binding', description: 'Spiral binding with clear cover and back sheet.', rules: [['Spiral bind, up to 100 sheets', 'A4', 'bw', 'single', 'per_item', 8, []]] },
];

async function seedCatalog(pressId: string, factor = 1) {
  const { count } = await db.from('services').select('id', { count: 'exact', head: true }).eq('press_id', pressId);
  if ((count ?? 0) > 0) return;
  for (const [i, s] of CATALOG.entries()) {
    const { data: svc, error } = await db.from('services').insert({ press_id: pressId, name: s.name, description: s.description, sort_order: i }).select('id').single();
    if (error) throw error;
    const rows = s.rules.map((r) => ({ press_id: pressId, service_id: svc.id, label: r[0], paper_size: r[1], color_mode: r[2], sides: r[3], unit: r[4], unit_price: Math.round(r[5] * factor * 100) / 100, bulk_tiers: r[6] }));
    const { error: e2 } = await db.from('price_rules').insert(rows); if (e2) throw e2;
  }
}

const NAMES = ['Kwame Mensah', 'Akosua Boateng', 'Yaw Owusu', 'Efua Addo', 'Kofi Asante', 'Ama Darko', 'Nana Yeboah', 'Esi Quaye', 'Kojo Appiah', 'Abena Sarpong', 'Fiifi Ansah', 'Adwoa Frimpong'];

async function seedOrders(press: { id: string }, staffIds: string[], count: number) {
  const { count: existing } = await db.from('orders').select('id', { count: 'exact', head: true }).eq('press_id', press.id);
  if ((existing ?? 0) > 0) return;
  const { data: rules } = await db.from('price_rules').select('id, service_id, label, unit, unit_price, bulk_tiers, services(name)').eq('press_id', press.id);
  if (!rules?.length) return;
  for (let n = 0; n < count; n++) {
    const daysAgo = Math.floor(Math.pow(rnd(), 1.4) * 45);
    const created = new Date(Date.now() - daysAgo * 86_400_000 - int(0, 10) * 3_600_000);
    const status = daysAgo > 3 ? (rnd() < 0.08 ? 'cancelled' : 'completed') : pickOne(['submitted', 'confirmed', 'printing', 'ready', 'completed']);
    const who = pickOne(NAMES);
    const { data: order, error } = await db.from('orders').insert({
      press_id: press.id, status, customer_name: who, customer_phone: `+23324${int(1000000, 9999999)}`, created_at: created.toISOString(),
    }).select('id').single();
    if (error) throw error;
    const lines = Array.from({ length: int(1, 2) }, () => {
      const r = pickOne(rules); const svc = Array.isArray(r.services) ? r.services[0] : r.services;
      const q = quoteLine({ unit: r.unit, unitPriceMinor: toMinor(r.unit_price), tiers: normalizeTiers(r.bulk_tiers) }, { pages: r.unit === 'per_page' ? int(2, 240) : undefined, copies: r.unit === 'per_page' ? int(1, 3) : int(1, 4), areaSqm: 1 });
      return { press_id: press.id, order_id: order.id, service_id: r.service_id, price_rule_id: r.id, description: `${svc?.name}: ${r.label}`, quantity: q.quantity, unit_price: q.unitPriceMinor / 100, line_total: q.totalMinor / 100 };
    });
    await db.from('order_items').insert(lines);
    const total = lines.reduce((s, l) => s + l.line_total, 0);
    if (status !== 'cancelled' && (status === 'completed' || rnd() < 0.5)) {
      const full = status === 'completed' ? rnd() < 0.9 : rnd() < 0.4;
      const paid = full ? total : Math.round(total * 0.5 * 100) / 100;
      if (paid > 0) await db.from('payments').insert({ press_id: press.id, order_id: order.id, amount: paid, method: pickOne(['cash', 'mobile_money', 'mobile_money', 'card', 'bank_transfer']), reference: rnd() < 0.5 ? `TX${int(100000, 999999)}` : null, recorded_by: pickOne(staffIds), paid_at: new Date(created.getTime() + int(1, 48) * 3_600_000).toISOString() });
    }
  }
}

async function press(slug: string, name: string, status: 'approved' | 'pending' | 'suspended', extra: Record<string, unknown>, ownerId: string) {
  const { data: existing } = await db.from('presses').select('id').eq('slug', slug).maybeSingle();
  if (existing) return existing.id as string;
  const { data, error } = await db.from('presses').insert({ slug, name, status, approved_at: status === 'approved' ? new Date().toISOString() : null, ...extra }).select('id').single();
  if (error) throw error;
  await db.from('press_members').insert({ press_id: data.id, user_id: ownerId, role: 'owner' });
  return data.id as string;
}

async function main() {
  const adminId = await user('admin@printpress.test', 'Platform Admin');
  await db.from('profiles').update({ platform_role: 'super_admin' }).eq('id', adminId);

  const ama = await user('ama@cityline.test', 'Ama Serwaa');
  const abena = await user('abena@cityline.test', 'Abena Konadu');
  const kwesi = await user('kwesi@cityline.test', 'Kwesi Badu');
  const kofi = await user('kofi@quickcopy.test', 'Kofi Manu');
  const esi = await user('esi@pixelpress.test', 'Esi Tetteh');
  const yaw = await user('yaw@oldtown.test', 'Yaw Adjei');

  const cityline = await press('cityline-print-studio', 'Cityline Print Studio', 'approved', {
    description: 'Documents, copies, posters and binding, printed while you wait or ready for pickup.', brand_color: '#0B5FD8',
    email: 'hello@cityline.test', phone: '+233200000001', whatsapp: '+233200000001', address: '14 Foundry Lane, Riverside', city: 'Accra', opening_hours: hours('08:00', '18:00'),
  }, ama);
  await db.from('press_members').upsert([{ press_id: cityline, user_id: abena, role: 'manager' }, { press_id: cityline, user_id: kwesi, role: 'staff' }], { onConflict: 'press_id,user_id' });

  const quick = await press('quickcopy-hub', 'QuickCopy Hub', 'approved', {
    description: 'Fast, cheap copies for students and offices. Open late on weekdays.', brand_color: '#E6007E',
    email: 'desk@quickcopy.test', phone: '+233200000002', address: 'Campus Road, Block C', city: 'Kumasi', opening_hours: hours('07:30', '20:00', '17:00'),
  }, kofi);
  await press('pixelpress-labs', 'PixelPress Labs', 'pending', { description: 'Photo prints and canvas.', email: 'studio@pixelpress.test', phone: '+233200000003', city: 'Takoradi' }, esi);
  const oldtown = await press('oldtown-prints', 'OldTown Prints', 'suspended', { description: 'Family printing shop.', phone: '+233200000004', city: 'Cape Coast', suspended_reason: 'Unpaid platform fees. Contact support to reactivate.' }, yaw);

  await seedCatalog(cityline); await seedCatalog(quick, 0.85); await seedCatalog(oldtown);
  await seedOrders({ id: cityline }, [ama, abena, kwesi], 90);
  await seedOrders({ id: quick }, [kofi], 45);

  console.log('\nSeed complete. Sign in with (password for all: %s)', PASSWORD);
  console.table([
    { role: 'Super admin', email: 'admin@printpress.test', lands_on: '/admin' },
    { role: 'Press owner (approved)', email: 'ama@cityline.test', lands_on: '/dashboard' },
    { role: 'Press manager', email: 'abena@cityline.test', lands_on: '/dashboard' },
    { role: 'Press staff', email: 'kwesi@cityline.test', lands_on: '/dashboard' },
    { role: 'Second press owner', email: 'kofi@quickcopy.test', lands_on: '/dashboard' },
    { role: 'Owner of pending press', email: 'esi@pixelpress.test', lands_on: '/dashboard' },
    { role: 'Owner of suspended press', email: 'yaw@oldtown.test', lands_on: '/dashboard' },
  ]);
  console.log('Public pages: /p/cityline-print-studio and /p/quickcopy-hub');
}
main().catch((e) => { console.error(e); process.exit(1); });
