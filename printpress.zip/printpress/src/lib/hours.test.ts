import { test } from 'node:test';
import assert from 'node:assert/strict';
import { openStatus } from './hours.ts';

const hours = { mon: { open: '08:00', close: '18:00' }, sun: null };

test('open during hours in the press time zone', () => {
  // Monday 2026-09-21 10:30 UTC == 10:30 in Accra (UTC+0)
  const r = openStatus(hours, 'Africa/Accra', new Date('2026-09-21T10:30:00Z'));
  assert.equal(r.open, true);
});
test('closed before opening and after closing', () => {
  assert.equal(openStatus(hours, 'Africa/Accra', new Date('2026-09-21T06:00:00Z')).label, 'Closed now, opens at 08:00');
  assert.equal(openStatus(hours, 'Africa/Accra', new Date('2026-09-21T19:00:00Z')).open, false);
});
test('time zone shifts the day', () => {
  // 23:30 UTC Monday is already Tuesday 07:30 in Asia/Tokyo+8? (Tokyo is UTC+9 => Tue 08:30) and Tuesday has no hours
  assert.equal(openStatus(hours, 'Asia/Tokyo', new Date('2026-09-21T23:30:00Z')).open, false);
});
test('closed day and bad zone', () => {
  assert.equal(openStatus(hours, 'Africa/Accra', new Date('2026-09-20T12:00:00Z')).open, false);
  assert.equal(openStatus(hours, 'Nope/Zone', new Date()).label, 'Hours unavailable');
});
