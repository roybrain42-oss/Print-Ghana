import type { ZodError } from 'zod';

export type ActionState = { ok: boolean; message: string; fieldErrors?: Record<string, string> } | null;

export const okState = (message: string): ActionState => ({ ok: true, message });
export const failState = (message: string, fieldErrors?: Record<string, string>): ActionState => ({
  ok: false,
  message,
  fieldErrors,
});

export function fromZod(err: ZodError): ActionState {
  const fieldErrors: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = String(issue.path[0] ?? '_');
    if (!fieldErrors[key]) fieldErrors[key] = issue.message;
  }
  return failState('Please fix the highlighted fields.', fieldErrors);
}
