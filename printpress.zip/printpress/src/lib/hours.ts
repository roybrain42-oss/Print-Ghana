export type Hours = Record<string, { open: string; close: string } | null | undefined>;
const KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const;

/** Is the press open at `now`, judged in the press's own time zone? */
export function openStatus(hours: Hours, timeZone: string, now: Date = new Date()): { open: boolean; label: string } {
  let parts: Intl.DateTimeFormatPart[];
  try {
    parts = new Intl.DateTimeFormat('en-GB', { timeZone, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(now);
  } catch {
    return { open: false, label: 'Hours unavailable' };
  }
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  const day = KEYS.find((k) => k === get('weekday').slice(0, 3).toLowerCase());
  const mins = parseInt(get('hour'), 10) * 60 + parseInt(get('minute'), 10);
  const today = day ? hours[day] : null;
  const toMin = (s: string) => parseInt(s.slice(0, 2), 10) * 60 + parseInt(s.slice(3, 5), 10);
  if (today && mins >= toMin(today.open) && mins < toMin(today.close)) return { open: true, label: `Open now, until ${today.close}` };
  if (today && mins < toMin(today.open)) return { open: false, label: `Closed now, opens at ${today.open}` };
  return { open: false, label: 'Closed now' };
}
