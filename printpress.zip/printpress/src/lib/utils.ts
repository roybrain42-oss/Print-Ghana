export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

export function formatDate(iso: string | null | undefined, withTime = true): string {
  if (!iso) return '';
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {}),
  }).format(new Date(iso));
}

export function money(value: number | string | null | undefined, currency = 'GHS'): string {
  return new Intl.NumberFormat('en-GH', { style: 'currency', currency }).format(Number(value ?? 0));
}

/** Keep only characters that are safe inside a PostgREST ilike filter. */
export function sanitizeSearch(q: string | undefined): string {
  return (q ?? '').replace(/[^\p{L}\p{N}\s@.+_-]/gu, '').trim().slice(0, 60);
}

export function slugify(input: string): string {
  return input.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}

export function normalizePhone(p: string): string {
  return p.replace(/\D/g, '').slice(-9);
}

export function pick<T extends string>(value: string | undefined, allowed: readonly T[], fallback: T): T {
  return (allowed as readonly string[]).includes(value ?? '') ? (value as T) : fallback;
}

export function toInt(v: string | undefined, fallback: number, min = 1, max = 10_000): number {
  const n = parseInt(v ?? '', 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
