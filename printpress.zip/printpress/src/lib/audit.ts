import 'server-only';
import { createAdminClient } from '@/lib/supabase/admin';
import { currentRequestMeta } from '@/lib/security/http';

export interface AuditEntry {
  action: string;               // e.g. 'auth.login', 'press.approve', 'files.download'
  entityType: string;
  entityId?: string | null;
  pressId?: string | null;
  actorId?: string | null;
  metadata?: Record<string, unknown>;
}

/** Append-only audit trail. Never throws: auditing must not break the user's action. */
export async function audit(entry: AuditEntry, meta?: { ip: string; userAgent: string }) {
  try {
    const { ip, userAgent } = meta ?? (await currentRequestMeta());
    const admin = createAdminClient();
    const { error } = await admin.from('audit_logs').insert({
      action: entry.action,
      entity_type: entry.entityType,
      entity_id: entry.entityId ?? null,
      press_id: entry.pressId ?? null,
      actor_id: entry.actorId ?? null,
      metadata: { source: 'app', ...(entry.metadata ?? {}) },
      ip: ip === 'unknown' ? null : ip,
      user_agent: userAgent,
    });
    if (error) console.error('audit insert failed', error.message);
  } catch (e) {
    console.error('audit exception', e);
  }
}
