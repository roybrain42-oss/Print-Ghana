import 'server-only';
import { createAdminClient } from '@/lib/supabase/admin';

export type PlatformSettings = { registration_open: boolean; require_press_approval: boolean };
const DEFAULTS: PlatformSettings = { registration_open: true, require_press_approval: true };

export async function getPlatformSettings(): Promise<PlatformSettings> {
  const { data } = await createAdminClient().from('platform_settings').select('key, value');
  const out = { ...DEFAULTS };
  for (const row of data ?? []) {
    if (row.key === 'registration_open' && typeof row.value === 'boolean') out.registration_open = row.value;
    if (row.key === 'require_press_approval' && typeof row.value === 'boolean') out.require_press_approval = row.value;
  }
  return out;
}
