/**
 * Upload validation. Client-supplied MIME types and extensions are untrusted:
 * we check the declared metadata up front, then verify the real bytes
 * (magic numbers) after the file lands in private storage.
 */

export const MAX_FILE_BYTES = 50 * 1024 * 1024;
export const MAX_FILES_PER_ORDER = 10;

type Sniffed = 'pdf' | 'jpeg' | 'png' | 'zip' | 'ole';

const TYPES: Record<string, { mime: string; family: Sniffed }> = {
  pdf: { mime: 'application/pdf', family: 'pdf' },
  jpg: { mime: 'image/jpeg', family: 'jpeg' },
  jpeg: { mime: 'image/jpeg', family: 'jpeg' },
  png: { mime: 'image/png', family: 'png' },
  doc: { mime: 'application/msword', family: 'ole' },
  docx: { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', family: 'zip' },
  pptx: { mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', family: 'zip' },
};

export const ALLOWED_EXTENSIONS = Object.keys(TYPES);

export function mimeForExtension(ext: string): string | null {
  return TYPES[ext]?.mime ?? null;
}

export function extensionOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i < 0 ? '' : name.slice(i + 1).toLowerCase();
}

/** Strip path parts and control characters; cap length. Used for display and download names only. */
export function sanitizeFileName(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? 'file';
  // eslint-disable-next-line no-control-regex
  const cleaned = base.replace(/[\u0000-\u001f\u007f<>:"|?*]/g, '').replace(/\s+/g, ' ').trim();
  const trimmed = cleaned.length > 120 ? cleaned.slice(-120) : cleaned;
  return trimmed || 'file';
}

export type UploadMeta = { name: string; size: number; type: string };
export type UploadCheck =
  | { ok: true; ext: string; mime: string; family: Sniffed; safeName: string }
  | { ok: false; error: string };

export function validateUploadMeta(meta: UploadMeta): UploadCheck {
  const safeName = sanitizeFileName(meta.name);
  const ext = extensionOf(safeName);
  const def = TYPES[ext];
  if (!def) return { ok: false, error: `${safeName}: this file type is not supported` };
  if (meta.type !== def.mime) return { ok: false, error: `${safeName}: file type does not match its extension` };
  if (!Number.isInteger(meta.size) || meta.size <= 0) return { ok: false, error: `${safeName}: file is empty` };
  if (meta.size > MAX_FILE_BYTES) return { ok: false, error: `${safeName}: file is larger than 50 MB` };
  return { ok: true, ext, mime: def.mime, family: def.family, safeName };
}

export function sniffFamily(b: Uint8Array): Sniffed | null {
  const starts = (sig: number[]) => sig.every((v, i) => b[i] === v);
  if (starts([0x25, 0x50, 0x44, 0x46, 0x2d])) return 'pdf';               // %PDF-
  if (starts([0xff, 0xd8, 0xff])) return 'jpeg';
  if (starts([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return 'png';
  if (starts([0x50, 0x4b, 0x03, 0x04])) return 'zip';                      // docx / pptx
  if (starts([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1])) return 'ole'; // legacy .doc
  return null;
}

export function bytesMatchDeclared(bytes: Uint8Array, declaredFamily: Sniffed): boolean {
  return sniffFamily(bytes) === declaredFamily;
}
