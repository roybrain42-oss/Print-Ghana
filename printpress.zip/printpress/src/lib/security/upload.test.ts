import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateUploadMeta, sniffFamily, sanitizeFileName, bytesMatchDeclared, MAX_FILE_BYTES } from './upload.ts';

test('accepts a valid pdf', () => {
  const r = validateUploadMeta({ name: 'CV final.pdf', size: 1024, type: 'application/pdf' });
  assert.equal(r.ok, true);
});

test('rejects unsupported and spoofed types', () => {
  assert.equal(validateUploadMeta({ name: 'run.exe', size: 10, type: 'application/pdf' }).ok, false);
  assert.equal(validateUploadMeta({ name: 'a.pdf', size: 10, type: 'image/png' }).ok, false);
  assert.equal(validateUploadMeta({ name: 'noext', size: 10, type: 'application/pdf' }).ok, false);
  assert.equal(validateUploadMeta({ name: 'a.pdf.exe', size: 10, type: 'application/pdf' }).ok, false);
});

test('rejects empty and oversized files', () => {
  assert.equal(validateUploadMeta({ name: 'a.pdf', size: 0, type: 'application/pdf' }).ok, false);
  assert.equal(validateUploadMeta({ name: 'a.pdf', size: MAX_FILE_BYTES + 1, type: 'application/pdf' }).ok, false);
  assert.equal(validateUploadMeta({ name: 'a.pdf', size: 1.5, type: 'application/pdf' }).ok, false);
});

test('magic byte sniffing', () => {
  assert.equal(sniffFamily(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31])), 'pdf');
  assert.equal(sniffFamily(new Uint8Array([0xff, 0xd8, 0xff, 0xe0])), 'jpeg');
  assert.equal(sniffFamily(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), 'png');
  assert.equal(sniffFamily(new Uint8Array([0x50, 0x4b, 0x03, 0x04, 0x14])), 'zip');
  assert.equal(sniffFamily(new Uint8Array([0x4d, 0x5a, 0x90, 0x00])), null); // Windows executable
  assert.equal(bytesMatchDeclared(new Uint8Array([0x4d, 0x5a, 0x90]), 'pdf'), false);
});

test('file names are sanitized', () => {
  assert.equal(sanitizeFileName('../../etc/passwd'), 'passwd');
  assert.equal(sanitizeFileName('C:\\temp\\a<b>.pdf'), 'ab.pdf');
  assert.equal(sanitizeFileName('   '), 'file');
});
