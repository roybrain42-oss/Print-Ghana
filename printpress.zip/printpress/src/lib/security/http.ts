import 'server-only';
import { headers } from 'next/headers';
import { createAdminClient } from '@/lib/supabase/admin';

/** Best-effort client IP. On Vercel/most proxies the first x-forwarded-for entry is the client. */
export function ipFromHeaders(h: Headers): string {
  const fwd = h.get('x-forwarded-for');
  const first = fwd?.split(',')[0]?.trim();
  return first || h.get('x-real-ip') || 'unknown';
}

export async function currentRequestMeta(): Promise<{ ip: string; userAgent: string }> {
  const h = await headers();
  return { ip: ipFromHeaders(h), userAgent: (h.get('user-agent') ?? '').slice(0, 300) };
}

/**
 * CSRF defence for cookie-less and cookie-bearing mutation endpoints:
 * a browser always sends Origin on cross-site POSTs, so a mismatch is rejected.
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get('origin');
  if (!origin) return false;
  const host = req.headers.get('x-forwarded-host') ?? req.headers.get('host');
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

/** Fixed-window limiter backed by Postgres. Returns true when the request may proceed. Fails closed. */
export async function rateLimit(key: string, windowSeconds: number, max: number): Promise<boolean> {
  try {
    const admin = createAdminClient();
    const { data, error } = await admin.rpc('rate_limit_hit', {
      p_key: key, p_window_seconds: windowSeconds, p_max: max,
    });
    if (error) {
      console.error('rate limit error', error.message);
      return false;
    }
    return data === true;
  } catch (e) {
    console.error('rate limit exception', e);
    return false;
  }
}
