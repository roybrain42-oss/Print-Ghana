export type Role = 'owner' | 'manager' | 'staff';
export type PressStatus = 'pending' | 'approved' | 'suspended';
export type OrderStatus = 'draft' | 'submitted' | 'confirmed' | 'printing' | 'ready' | 'completed' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'partial' | 'paid';

export interface Press {
  id: string; slug: string; name: string; description: string | null; logo_path: string | null;
  brand_color: string; email: string | null; phone: string | null; whatsapp: string | null;
  address: string | null; city: string | null; region: string | null; country: string;
  opening_hours: Record<string, { open: string; close: string } | null>;
  currency: string; timezone: string; status: PressStatus; suspended_reason: string | null; created_at: string;
}

export interface Order {
  id: string; press_id: string; order_number: string | null; tracking_code: string;
  customer_name: string; customer_phone: string; customer_email: string | null; notes: string | null;
  status: OrderStatus; subtotal: number; discount: number; total: number; amount_paid: number;
  payment_status: PaymentStatus; assigned_to: string | null; created_at: string;
}

export const ORDER_STATUSES: OrderStatus[] = ['submitted', 'confirmed', 'printing', 'ready', 'completed', 'cancelled'];
export const PAYMENT_METHODS = ['cash', 'mobile_money', 'card', 'bank_transfer', 'other'] as const;
export const METHOD_LABEL: Record<string, string> = {
  cash: 'Cash', mobile_money: 'Mobile money', card: 'Card', bank_transfer: 'Bank transfer', other: 'Other',
};
