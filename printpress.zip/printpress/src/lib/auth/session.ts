import 'server-only';
import { cache } from 'react';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import type { Press, Role } from '@/lib/types';

export interface Profile {
  id: string; full_name: string; email: string | null;
  platform_role: 'user' | 'super_admin'; is_active: boolean;
}

const RANK: Record<Role, number> = { staff: 1, manager: 2, owner: 3 };

/** Verified user (validated with the Auth server, not just the cookie) plus profile. */
export const getCurrentUser = cache(async () => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: profile } = await supabase
    .from('profiles').select('id, full_name, email, platform_role, is_active').eq('id', user.id).single();
  if (!profile || !profile.is_active) return null;
  return { user, profile: profile as Profile };
});

export async function requireUser() {
  const s = await getCurrentUser();
  if (!s) redirect('/login');
  return s;
}

export async function requireSuperAdmin() {
  const s = await requireUser();
  if (s.profile.platform_role !== 'super_admin') redirect('/dashboard');
  return s;
}

export interface PressContext {
  user: { id: string; email?: string };
  profile: Profile;
  press: Press;
  role: Role;
}

/**
 * Resolve the caller's press and role. Membership is read with the service client so a
 * SUSPENDED press can still be recognised (RLS hides suspended tenants from their own members).
 * This lookup is keyed strictly by the verified user id.
 */
export async function requirePress(min: Role = 'staff'): Promise<PressContext> {
  const { user, profile } = await requireUser();
  const admin = createAdminClient();
  const { data: m } = await admin
    .from('press_members')
    .select('role, presses(*)')
    .eq('user_id', user.id).eq('is_active', true)
    .order('created_at', { ascending: true }).limit(1).maybeSingle();

  const press = (Array.isArray(m?.presses) ? m?.presses[0] : m?.presses) as Press | undefined;
  if (!m || !press) {
    redirect(profile.platform_role === 'super_admin' ? '/admin' : '/onboarding');
  }
  const role = m.role as Role;
  if (RANK[role] < RANK[min]) redirect('/dashboard');
  return { user: { id: user.id, email: user.email }, profile, press, role };
}

/** For server actions: same as requirePress but returns null instead of redirecting. */
export async function tryPress(min: Role): Promise<PressContext | null> {
  try {
    return await requirePress(min);
  } catch (e) {
    // redirect() throws NEXT_REDIRECT; treat as unauthorized inside actions.
    if (e && typeof e === 'object' && 'digest' in e) return null;
    throw e;
  }
}
