import 'server-only';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { assertPublicEnv, publicEnv } from '@/lib/env';

/**
 * Service-role client: BYPASSES Row Level Security.
 * Use only for: public order creation, storage signing, invites, audit inserts,
 * rate limiting and seeding. Every call site must do its own authorization.
 */
export function createAdminClient() {
  assertPublicEnv();
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set');
  return createSupabaseClient(publicEnv.supabaseUrl, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
