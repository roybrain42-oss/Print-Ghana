import { createBrowserClient } from '@supabase/ssr';
import { publicEnv } from '@/lib/env';

export function createBrowserSupabase() {
  return createBrowserClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey);
}
