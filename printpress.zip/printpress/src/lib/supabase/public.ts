import { createClient } from '@supabase/supabase-js';
import { assertPublicEnv, publicEnv } from '@/lib/env';

/** Cookie-less anonymous client for public pages. It can only read the storefront views. */
export function createPublicClient() {
  assertPublicEnv();
  return createClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, { auth: { persistSession: false, autoRefreshToken: false } });
}
