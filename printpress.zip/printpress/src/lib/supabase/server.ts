import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { assertPublicEnv, publicEnv } from '@/lib/env';

/** Session-bound client. Row Level Security applies: this is the default client for app code. */
export async function createClient() {
  assertPublicEnv();
  const store = await cookies();
  return createServerClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list) => {
        try {
          list.forEach(({ name, value, options }) => store.set(name, value, options));
        } catch {
          // Called from a Server Component: middleware refreshes the session instead.
        }
      },
    },
  });
}
