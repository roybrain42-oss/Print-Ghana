import { test } from 'node:test';
import assert from 'node:assert/strict';
import { quoteLine, normalizeTiers, toMinor, PricingError } from './engine.ts';

const tiers = normalizeTiers([
  { min_qty: 500, percent_off: 20 },
  { min_qty: 100, percent_off: 10 },
]);

test('tiers are sorted and junk is dropped', () => {
  assert.deepEqual(tiers.map((t) => t.min_qty), [100, 500]);
  assert.deepEqual(normalizeTiers('nope'), []);
  assert.deepEqual(normalizeTiers([{ min_qty: -1, percent_off: 10 }, { min_qty: 5, percent_off: 150 }, null]), []);
});

test('per-page quote without discount', () => {
  const q = quoteLine({ unit: 'per_page', unitPriceMinor: 50, tiers }, { pages: 20, copies: 1 });
  assert.equal(q.quantity, 20);
  assert.equal(q.grossMinor, 1000);
  assert.equal(q.discountPercent, 0);
  assert.equal(q.totalMinor, 1000);
  assert.deepEqual(q.nextTier, { minQty: 100, percentOff: 10, moreNeeded: 80 });
});

test('pages x copies drives the tier', () => {
  const q = quoteLine({ unit: 'per_page', unitPriceMinor: 200, tiers }, { pages: 50, copies: 2 });
  assert.equal(q.quantity, 100);
  assert.equal(q.discountPercent, 10);
  assert.equal(q.grossMinor, 20000);
  assert.equal(q.discountMinor, 2000);
  assert.equal(q.totalMinor, 18000);
});

test('top tier applies and there is no next tier', () => {
  const q = quoteLine({ unit: 'per_page', unitPriceMinor: 40, tiers }, { pages: 500, copies: 1 });
  assert.equal(q.discountPercent, 20);
  assert.equal(q.totalMinor, 16000);
  assert.equal(q.nextTier, null);
});

test('discount rounds half up in integer maths', () => {
  // gross 105 minor units, 10% off = 10.5 -> 11
  const q = quoteLine({ unit: 'per_item', unitPriceMinor: 105, tiers: [{ min_qty: 1, percent_off: 10 }] }, { copies: 1 });
  assert.equal(q.discountMinor, 11);
  assert.equal(q.totalMinor, 94);
});

test('per-item and per-sqm units', () => {
  const item = quoteLine({ unit: 'per_item', unitPriceMinor: 2500, tiers: [] }, { copies: 3 });
  assert.equal(item.totalMinor, 7500);
  const sqm = quoteLine({ unit: 'per_sqm', unitPriceMinor: 4000, tiers: [] }, { copies: 2, areaSqm: 1.5 });
  assert.equal(sqm.unitPriceMinor, 6000);
  assert.equal(sqm.totalMinor, 12000);
});

test('rejects invalid quantities', () => {
  const rule = { unit: 'per_page' as const, unitPriceMinor: 50, tiers };
  assert.throws(() => quoteLine(rule, { pages: 0, copies: 1 }), PricingError);
  assert.throws(() => quoteLine(rule, { pages: 1.5, copies: 1 }), PricingError);
  assert.throws(() => quoteLine(rule, { pages: 5001, copies: 1 }), PricingError);
  assert.throws(() => quoteLine(rule, { copies: 1 }), PricingError);
  assert.throws(() => quoteLine(rule, { pages: 1, copies: 1001 }), PricingError);
  assert.throws(() => quoteLine({ unit: 'per_sqm', unitPriceMinor: 100, tiers: [] }, { copies: 1 }), PricingError);
  assert.throws(() => quoteLine({ ...rule, unitPriceMinor: -5 }, { pages: 1, copies: 1 }), PricingError);
});

test('toMinor avoids float drift', () => {
  assert.equal(toMinor('0.30'), 30);
  assert.equal(toMinor(19.99), 1999);
});
