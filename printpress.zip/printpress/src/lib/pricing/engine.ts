/**
 * Pricing engine. Pure functions, no I/O, integer minor units (pesewas/cents)
 * so totals never suffer floating point drift. The server is the only source
 * of truth for prices: the browser may call this for a live preview, but
 * order creation always recomputes from database rules.
 */

export type Unit = 'per_page' | 'per_copy' | 'per_item' | 'per_sqm';

export interface Tier {
  min_qty: number;
  percent_off: number;
}

export interface PriceRuleInput {
  unit: Unit;
  unitPriceMinor: number;
  tiers: Tier[];
}

export interface QuoteInput {
  pages?: number;
  copies: number;
  areaSqm?: number;
}

export interface LineQuote {
  quantity: number;
  unitPriceMinor: number;
  grossMinor: number;
  discountPercent: number;
  discountMinor: number;
  totalMinor: number;
  nextTier: { minQty: number; percentOff: number; moreNeeded: number } | null;
}

export class PricingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PricingError';
  }
}

export const MAX_PAGES = 5000;
export const MAX_COPIES = 1000;
export const MAX_AREA_SQM = 100;

export const toMinor = (amount: number | string): number => Math.round(Number(amount) * 100);
export const fromMinor = (minor: number): number => minor / 100;

/** Parse bulk_tiers JSON from the database defensively. */
export function normalizeTiers(raw: unknown): Tier[] {
  if (!Array.isArray(raw)) return [];
  const tiers: Tier[] = [];
  for (const t of raw) {
    if (!t || typeof t !== 'object') continue;
    const min = Number((t as Record<string, unknown>).min_qty);
    const off = Number((t as Record<string, unknown>).percent_off);
    if (Number.isInteger(min) && min > 0 && Number.isFinite(off) && off > 0 && off <= 100) {
      tiers.push({ min_qty: min, percent_off: off });
    }
  }
  return tiers.sort((a, b) => a.min_qty - b.min_qty);
}

function assertInt(name: string, value: unknown, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) {
    throw new PricingError(`${name} must be a whole number between ${min} and ${max}`);
  }
  return value;
}

export function quoteLine(rule: PriceRuleInput, input: QuoteInput): LineQuote {
  if (!Number.isInteger(rule.unitPriceMinor) || rule.unitPriceMinor < 0) {
    throw new PricingError('invalid unit price');
  }
  const copies = assertInt('copies', input.copies, 1, MAX_COPIES);

  let quantity: number;
  let unitPriceMinor = rule.unitPriceMinor;

  switch (rule.unit) {
    case 'per_page': {
      const pages = assertInt('pages', input.pages, 1, MAX_PAGES);
      quantity = pages * copies;
      break;
    }
    case 'per_copy':
    case 'per_item':
      quantity = copies;
      break;
    case 'per_sqm': {
      const area = input.areaSqm;
      if (typeof area !== 'number' || !Number.isFinite(area) || area <= 0 || area > MAX_AREA_SQM) {
        throw new PricingError(`area must be between 0 and ${MAX_AREA_SQM} square metres`);
      }
      unitPriceMinor = Math.round(rule.unitPriceMinor * area);
      quantity = copies;
      break;
    }
    default:
      throw new PricingError('unsupported unit');
  }

  const grossMinor = quantity * unitPriceMinor;

  let discountPercent = 0;
  for (const t of rule.tiers) {
    if (quantity >= t.min_qty && t.percent_off > discountPercent) discountPercent = t.percent_off;
  }
  // Round half up in integer arithmetic.
  const discountMinor = Math.floor((grossMinor * discountPercent * 100 + 5000) / 10000);

  const upcoming = rule.tiers.find((t) => t.min_qty > quantity && t.percent_off > discountPercent);

  return {
    quantity,
    unitPriceMinor,
    grossMinor,
    discountPercent,
    discountMinor,
    totalMinor: grossMinor - discountMinor,
    nextTier: upcoming
      ? { minQty: upcoming.min_qty, percentOff: upcoming.percent_off, moreNeeded: upcoming.min_qty - quantity }
      : null,
  };
}

export function sumQuotes(lines: LineQuote[]): { subtotalMinor: number; totalMinor: number } {
  const totalMinor = lines.reduce((s, l) => s + l.totalMinor, 0);
  return { subtotalMinor: totalMinor, totalMinor };
}

export function formatMoney(minor: number, currency = 'GHS', locale = 'en-GH'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(minor / 100);
}
