import { z } from 'zod';

const trimmed = (min: number, max: number, label: string) =>
  z.string().trim().min(min, `${label} is required`).max(max, `${label} is too long`);

export const phoneSchema = z
  .string()
  .trim()
  .regex(/^\+?[0-9 ()-]{7,20}$/, 'Enter a phone number with 7 to 20 digits');

export const emailSchema = z.string().trim().toLowerCase().email('Enter a valid email address').max(200);

export const slugSchema = z
  .string()
  .trim()
  .toLowerCase()
  .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Use lowercase letters, numbers and single hyphens')
  .min(3, 'At least 3 characters')
  .max(60);

export const RESERVED_SLUGS = new Set(['admin', 'api', 'dashboard', 'login', 'register', 'p', 'track', 'onboarding', 'www', 'app']);

export const passwordSchema = z
  .string()
  .min(10, 'Use at least 10 characters')
  .max(128)
  .refine((v) => /[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v), 'Include upper case, lower case and a number');

export const loginSchema = z.object({ email: emailSchema, password: z.string().min(1, 'Enter your password').max(128) });
export const registerSchema = z.object({ fullName: trimmed(2, 120, 'Your name'), email: emailSchema, password: passwordSchema });
export const onboardingSchema = z.object({ name: trimmed(2, 120, 'Business name'), slug: slugSchema });

export const serviceSchema = z.object({
  name: trimmed(2, 120, 'Name'),
  description: z.string().trim().max(1000).optional().default(''),
  category: z.string().trim().max(60).optional().default('printing'),
  active: z.coerce.boolean().optional().default(false),
});

const money = z.coerce.number({ invalid_type_error: 'Enter a price' }).min(0, 'Price cannot be negative').max(1_000_000);

export const priceRuleSchema = z.object({
  serviceId: z.string().uuid(),
  label: trimmed(2, 120, 'Label'),
  paperSize: trimmed(1, 20, 'Paper size'),
  colorMode: z.enum(['bw', 'color']),
  sides: z.enum(['single', 'double']),
  unit: z.enum(['per_page', 'per_copy', 'per_item', 'per_sqm']),
  unitPrice: money,
  tier1Min: z.coerce.number().int().min(0).max(100000).optional().default(0),
  tier1Off: z.coerce.number().min(0).max(90).optional().default(0),
  tier2Min: z.coerce.number().int().min(0).max(100000).optional().default(0),
  tier2Off: z.coerce.number().min(0).max(90).optional().default(0),
  active: z.coerce.boolean().optional().default(false),
});

export const paymentSchema = z.object({
  orderId: z.string().uuid(),
  amount: z.coerce.number({ invalid_type_error: 'Enter an amount' }).positive('Amount must be more than zero').max(1_000_000),
  method: z.enum(['cash', 'mobile_money', 'card', 'bank_transfer', 'other']),
  reference: z.string().trim().max(120).optional().default(''),
});

export const orderStatusSchema = z.object({
  orderId: z.string().uuid(),
  status: z.enum(['submitted', 'confirmed', 'printing', 'ready', 'completed', 'cancelled']),
});

export const staffInviteSchema = z.object({
  email: emailSchema,
  fullName: trimmed(2, 120, 'Name'),
  role: z.enum(['manager', 'staff']),
});

export const pressSettingsSchema = z.object({
  name: trimmed(2, 120, 'Business name'),
  description: z.string().trim().max(2000).optional().default(''),
  brandColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'Use a hex colour like #0B5FD8'),
  email: z.union([emailSchema, z.literal('')]).optional().default(''),
  phone: z.union([phoneSchema, z.literal('')]).optional().default(''),
  whatsapp: z.union([phoneSchema, z.literal('')]).optional().default(''),
  address: z.string().trim().max(300).optional().default(''),
  city: z.string().trim().max(100).optional().default(''),
});

export const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'] as const;
export type DayKey = (typeof DAYS)[number];

export const publicOrderSchema = z.object({
  slug: slugSchema,
  website: z.string().max(0).optional().default(''), // honeypot: real users leave it empty
  customer: z.object({ name: trimmed(2, 120, 'Name'), phone: phoneSchema, email: z.union([emailSchema, z.literal('')]).optional().default('') }),
  notes: z.string().trim().max(2000).optional().default(''),
  items: z
    .array(
      z.object({
        ruleId: z.string().uuid(),
        pages: z.number().int().min(1).max(5000).optional(),
        copies: z.number().int().min(1).max(1000),
        areaSqm: z.number().positive().max(100).optional(),
      }),
    )
    .min(1, 'Add at least one item')
    .max(10),
  files: z
    .array(z.object({ name: z.string().min(1).max(255), size: z.number().int().positive(), type: z.string().max(150) }))
    .min(1, 'Add at least one file')
    .max(10),
});
