'use client';
import Link from 'next/link';
import { useMemo, useRef, useState } from 'react';
import { createBrowserSupabase } from '@/lib/supabase/browser';
import { formatMoney, quoteLine, PricingError, type LineQuote } from '@/lib/pricing/engine';
import { MAX_FILES_PER_ORDER, extensionOf, mimeForExtension, validateUploadMeta } from '@/lib/security/upload';
import type { CatalogService } from '../data';

type Line = { key: number; serviceId: string; ruleId: string; pages: number; copies: number; areaSqm: number };
type Phase = 'idle' | 'creating' | 'uploading' | 'finalizing' | 'done';

export function OrderForm({ slug, currency, services }: { slug: string; currency: string; services: CatalogService[] }) {
  const first = services[0]!;
  const nextKey = useRef(1);
  const [lines, setLines] = useState<Line[]>([{ key: 0, serviceId: first.id, ruleId: first.rules[0]!.id, pages: 10, copies: 1, areaSqm: 1 }]);
  const [files, setFiles] = useState<File[]>([]);
  const [cust, setCust] = useState({ name: '', phone: '', email: '', notes: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [phase, setPhase] = useState<Phase>('idle');
  const [progress, setProgress] = useState('');
  const [result, setResult] = useState<{ orderNumber: string; trackingCode: string } | null>(null);
  const [formError, setFormError] = useState('');
  const honeypot = useRef<HTMLInputElement>(null);

  const ruleOf = (l: Line) => services.find((s) => s.id === l.serviceId)?.rules.find((r) => r.id === l.ruleId);
  const quotes = useMemo(() => lines.map((l): LineQuote | null => {
    const r = ruleOf(l); if (!r) return null;
    try { return quoteLine({ unit: r.unit, unitPriceMinor: r.unitPriceMinor, tiers: r.tiers }, { pages: l.pages, copies: l.copies, areaSqm: l.areaSqm }); } catch (e) { if (e instanceof PricingError) return null; throw e; }
  }), [lines]); // eslint-disable-line react-hooks/exhaustive-deps
  const total = quotes.reduce((s, q) => s + (q?.totalMinor ?? 0), 0);
  const busy = phase !== 'idle';

  function updateLine(key: number, patch: Partial<Line>) {
    setLines((ls) => ls.map((l) => {
      if (l.key !== key) return l;
      const next = { ...l, ...patch };
      if (patch.serviceId) next.ruleId = services.find((s) => s.id === patch.serviceId)!.rules[0]!.id;
      return next;
    }));
  }

  function addFiles(list: FileList | null) {
    if (!list) return;
    const errs: string[] = []; const next = [...files];
    for (const f of Array.from(list)) {
      const type = f.type || mimeForExtension(extensionOf(f.name)) || '';
      const check = validateUploadMeta({ name: f.name, size: f.size, type });
      if (!check.ok) errs.push(check.error);
      else if (next.length >= MAX_FILES_PER_ORDER) errs.push(`You can add up to ${MAX_FILES_PER_ORDER} files per order.`);
      else next.push(f);
    }
    setFiles(next); setErrors((e) => ({ ...e, files: errs.join(' ') }));
  }

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (cust.name.trim().length < 2) e.name = 'Enter your name so we know who to hand the order to.';
    if (!/^\+?[0-9 ()-]{7,20}$/.test(cust.phone.trim())) e.phone = 'Enter a phone number with 7 to 20 digits.';
    if (cust.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(cust.email)) e.email = 'Enter a valid email address or leave it blank.';
    if (!files.length) e.files = 'Add at least one file to print.';
    if (quotes.some((q) => q === null)) e.lines = 'Check the quantities: pages 1 to 5000, copies 1 to 1000.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function submit() {
    setFormError('');
    if (!validate()) return;
    setPhase('creating'); setProgress('Preparing your order…');
    try {
      const meta = files.map((f) => ({ name: f.name, size: f.size, type: f.type || mimeForExtension(extensionOf(f.name)) || '' }));
      const res = await fetch('/api/public/orders', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug, website: honeypot.current?.value ?? '',
          customer: { name: cust.name.trim(), phone: cust.phone.trim(), email: cust.email.trim() }, notes: cust.notes.trim(),
          items: lines.map((l) => { const r = ruleOf(l)!; return { ruleId: l.ruleId, copies: l.copies, ...(r.unit === 'per_page' ? { pages: l.pages } : {}), ...(r.unit === 'per_sqm' ? { areaSqm: l.areaSqm } : {}) }; }),
          files: meta,
        }),
      });
      const created = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(created.error ?? 'We could not create your order. Please try again.');

      setPhase('uploading');
      const supabase = createBrowserSupabase();
      for (let i = 0; i < created.uploads.length; i++) {
        const u = created.uploads[i]; const f = files[u.index]!;
        setProgress(`Uploading file ${i + 1} of ${created.uploads.length}…`);
        const { error } = await supabase.storage.from('order-files').uploadToSignedUrl(u.path, u.token, f, { contentType: meta[u.index]!.type });
        if (error) throw new Error(`Could not upload ${f.name}. Check your connection and try again.`);
      }

      setPhase('finalizing'); setProgress('Checking your files…');
      const fin = await fetch(`/api/public/orders/${created.orderId}/finalize`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ trackingCode: created.trackingCode }),
      });
      const done = await fin.json().catch(() => ({}));
      if (!fin.ok) throw new Error(done.error ?? 'We could not confirm your files. Please try again.');
      setResult({ orderNumber: done.orderNumber, trackingCode: created.trackingCode });
      setPhase('done');
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
      setPhase('idle');
    }
  }

  if (phase === 'done' && result) {
    return (
      <div className="card mt-6 border-2 border-ink" role="status" aria-live="polite">
        <h2 className="text-2xl font-extrabold">Order placed</h2>
        <p className="mt-2">Your order number is <strong>{result.orderNumber}</strong>. Save this tracking code to check progress:</p>
        <p className="my-3 rounded-lg bg-paper p-3 font-display text-2xl font-extrabold tracking-wide">{result.trackingCode}</p>
        <p className="text-sm text-ink-soft">To track it you will need this code and the phone number you gave us.</p>
        <div className="mt-4 flex flex-wrap gap-3"><Link className="btn btn-primary" href={`/track?code=${result.trackingCode}`}>Track this order</Link><Link className="btn btn-ghost" href={`/p/${slug}`}>Back to the press</Link></div>
      </div>
    );
  }

  return (
    <div className="mt-6 grid gap-6">
      <section className="card grid gap-5" aria-labelledby="w">
        <h2 id="w" className="text-xl font-extrabold">What do you need?</h2>
        {lines.map((l, idx) => {
          const svc = services.find((s) => s.id === l.serviceId)!; const rule = ruleOf(l)!; const q = quotes[idx];
          return (
            <div key={l.key} className="grid gap-3 rounded-xl border border-line p-4">
              <div><label className="label" htmlFor={`svc-${l.key}`}>Service</label>
                <select id={`svc-${l.key}`} className="input" value={l.serviceId} disabled={busy} onChange={(e) => updateLine(l.key, { serviceId: e.target.value })}>{services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
              <fieldset className="grid gap-2"><legend className="label">Option</legend>
                {svc.rules.map((r) => (
                  <label key={r.id} className={`flex min-h-[44px] cursor-pointer items-center justify-between gap-3 rounded-lg border-[1.5px] px-3 py-2 text-sm ${r.id === l.ruleId ? 'border-brand bg-brand/10' : 'border-line'}`}>
                    <span className="flex items-center gap-2"><input type="radio" name={`rule-${l.key}`} checked={r.id === l.ruleId} disabled={busy} onChange={() => updateLine(l.key, { ruleId: r.id })} className="h-4 w-4 accent-brand" />{r.label}</span>
                    <span className="tabular-nums text-ink-soft">{formatMoney(r.unitPriceMinor, currency)} {r.unit === 'per_page' ? 'per page' : r.unit === 'per_sqm' ? 'per m²' : 'each'}</span>
                  </label>))}
              </fieldset>
              <div className="grid grid-cols-2 gap-3">
                {rule.unit === 'per_page' && <div><label className="label" htmlFor={`pg-${l.key}`}>Pages</label><input id={`pg-${l.key}`} className="input" type="number" inputMode="numeric" min={1} max={5000} value={l.pages} disabled={busy} onChange={(e) => updateLine(l.key, { pages: Number(e.target.value) })} /></div>}
                {rule.unit === 'per_sqm' && <div><label className="label" htmlFor={`ar-${l.key}`}>Area (m²)</label><input id={`ar-${l.key}`} className="input" type="number" inputMode="decimal" min={0.1} max={100} step={0.1} value={l.areaSqm} disabled={busy} onChange={(e) => updateLine(l.key, { areaSqm: Number(e.target.value) })} /></div>}
                <div><label className="label" htmlFor={`cp-${l.key}`}>Copies</label><input id={`cp-${l.key}`} className="input" type="number" inputMode="numeric" min={1} max={1000} value={l.copies} disabled={busy} onChange={(e) => updateLine(l.key, { copies: Number(e.target.value) })} /></div>
              </div>
              {q && (<div className="rounded-lg border border-dashed border-ink bg-paper p-3 text-sm tabular-nums">
                <div className="flex justify-between"><span>{q.quantity} × {formatMoney(q.unitPriceMinor, currency)}</span><span>{formatMoney(q.grossMinor, currency)}</span></div>
                {q.discountMinor > 0 && <div className="flex justify-between text-emerald-800"><span>Bulk discount ({q.discountPercent}%)</span><span>-{formatMoney(q.discountMinor, currency)}</span></div>}
                <div className="mt-1 flex justify-between border-t border-line pt-1 font-bold"><span>Item total</span><span>{formatMoney(q.totalMinor, currency)}</span></div>
                {q.nextTier && <p className="mt-1 text-emerald-800">Add {q.nextTier.moreNeeded} more to get {q.nextTier.percentOff}% off.</p>}
              </div>)}
              {lines.length > 1 && <button type="button" className="justify-self-start text-sm font-semibold text-red-700 underline" disabled={busy} onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))}>Remove this item</button>}
            </div>);
        })}
        {errors.lines && <p role="alert" className="field-error">{errors.lines}</p>}
        {lines.length < 10 && <button type="button" className="btn btn-ghost btn-sm justify-self-start" disabled={busy} onClick={() => setLines((ls) => [...ls, { key: nextKey.current++, serviceId: first.id, ruleId: first.rules[0]!.id, pages: 10, copies: 1, areaSqm: 1 }])}>Add another item</button>}
      </section>

      <section className="card grid gap-3" aria-labelledby="f">
        <h2 id="f" className="text-xl font-extrabold">Your files</h2>
        <label className="grid cursor-pointer gap-1 rounded-xl border-2 border-dashed border-line bg-paper p-5 text-center focus-within:outline focus-within:outline-[3px] focus-within:outline-brand hover:border-brand">
          <input type="file" multiple className="sr-only" disabled={busy} accept=".pdf,.doc,.docx,.pptx,.jpg,.jpeg,.png" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} aria-describedby="fh" />
          <strong>Choose files</strong><span id="fh" className="text-xs text-ink-soft">PDF, Word, PowerPoint, JPG or PNG. Up to 50 MB each, up to {MAX_FILES_PER_ORDER} files.</span>
        </label>
        {files.length > 0 && <ul className="grid gap-1 text-sm">{files.map((f, i) => (<li key={`${f.name}-${i}`} className="flex items-center justify-between gap-3 rounded-lg bg-paper px-3 py-2"><span className="min-w-0 truncate">{f.name} <span className="text-ink-soft">({(f.size / 1048576).toFixed(1)} MB)</span></span><button type="button" disabled={busy} className="font-semibold text-red-700 underline" aria-label={`Remove ${f.name}`} onClick={() => setFiles((fs) => fs.filter((_, j) => j !== i))}>Remove</button></li>))}</ul>}
        {errors.files && <p role="alert" className="field-error">{errors.files}</p>}
      </section>

      <section className="card grid gap-4" aria-labelledby="c">
        <h2 id="c" className="text-xl font-extrabold">Your details</h2>
        <div aria-hidden="true" className="absolute -left-[9999px]"><label>Website<input ref={honeypot} tabIndex={-1} autoComplete="off" /></label></div>
        <div><label className="label" htmlFor="cn">Name</label><input id="cn" className="input" autoComplete="name" maxLength={120} value={cust.name} disabled={busy} onChange={(e) => setCust({ ...cust, name: e.target.value })} aria-describedby={errors.name ? 'cn-e' : undefined} />{errors.name && <p id="cn-e" role="alert" className="field-error">{errors.name}</p>}</div>
        <div><label className="label" htmlFor="cph">Phone number</label><input id="cph" type="tel" inputMode="tel" className="input" autoComplete="tel" maxLength={20} value={cust.phone} disabled={busy} onChange={(e) => setCust({ ...cust, phone: e.target.value })} aria-describedby={errors.phone ? 'cph-e' : 'cph-h'} /><p id="cph-h" className="hint">We call or message this number when your order is ready.</p>{errors.phone && <p id="cph-e" role="alert" className="field-error">{errors.phone}</p>}</div>
        <div><label className="label" htmlFor="cem">Email (optional)</label><input id="cem" type="email" className="input" autoComplete="email" maxLength={200} value={cust.email} disabled={busy} onChange={(e) => setCust({ ...cust, email: e.target.value })} />{errors.email && <p role="alert" className="field-error">{errors.email}</p>}</div>
        <div><label className="label" htmlFor="cno">Notes for the press (optional)</label><textarea id="cno" className="input" rows={3} maxLength={2000} value={cust.notes} disabled={busy} onChange={(e) => setCust({ ...cust, notes: e.target.value })} placeholder="Paper type, binding, when you need it" /></div>
      </section>

      <div className="card flex flex-wrap items-center justify-between gap-4 border-2 border-ink">
        <div><p className="text-sm text-ink-soft">Order total</p><p className="font-display text-3xl font-extrabold tabular-nums">{formatMoney(total, currency)}</p><p className="text-xs text-ink-soft">You pay the press when you collect. The final price is confirmed by the press.</p></div>
        <button type="button" className="btn btn-primary" disabled={busy} aria-busy={busy} onClick={submit}>{busy ? progress : 'Place order'}</button>
      </div>
      {formError && <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{formError}</p>}
    </div>
  );
}
