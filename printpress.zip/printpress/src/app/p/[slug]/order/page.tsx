import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getStorefront } from '../data';
import { OrderForm } from './order-form';

export const revalidate = 60;
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const data = await getStorefront((await params).slug);
  return { title: data ? `Order from ${data.press.name}` : 'Press not found', robots: { index: false } };
}

export default async function OrderPage({ params }: Props) {
  const data = await getStorefront((await params).slug);
  if (!data) notFound();
  const { press, services } = data;
  return (
    <>
      <div className="h-2" style={{ background: press.brand_color }} />
      <main id="main" className="mx-auto w-[min(720px,100%-2rem)] py-8">
        <Link href={`/p/${press.slug}`} className="text-sm font-semibold text-brand underline">Back to {press.name}</Link>
        <h1 className="mt-3 text-3xl font-extrabold">Order from {press.name}</h1>
        <p className="mt-1 text-sm text-ink-soft">Choose what you need, add your files and we will start on it.</p>
        {services.length === 0
          ? <div className="card mt-6">This press has not published prices yet. Please contact them directly{press.phone ? ` on ${press.phone}` : ''}.</div>
          : <OrderForm slug={press.slug} currency={press.currency} services={services} />}
      </main>
    </>
  );
}
