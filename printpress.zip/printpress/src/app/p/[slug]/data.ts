import 'server-only';
import { cache } from 'react';
import { createPublicClient } from '@/lib/supabase/public';
import { publicEnv } from '@/lib/env';
import { normalizeTiers, toMinor, type Tier, type Unit } from '@/lib/pricing/engine';
import type { Hours } from '@/lib/hours';

export interface StorefrontPress {
  id: string; slug: string; name: string; description: string | null; logo_path: string | null; brand_color: string;
  email: string | null; phone: string | null; whatsapp: string | null; address: string | null; city: string | null;
  opening_hours: Hours; currency: string; timezone: string;
}
export interface CatalogRule { id: string; label: string; unit: Unit; unitPriceMinor: number; tiers: Tier[]; paperSize: string }
export interface CatalogService { id: string; name: string; description: string | null; rules: CatalogRule[] }

export const getStorefront = cache(async (slug: string) => {
  const db = createPublicClient();
  const { data: press } = await db.from('storefronts').select('*').eq('slug', slug).maybeSingle();
  if (!press) return null;
  const { data: rows } = await db.from('storefront_prices').select('*').eq('press_id', press.id).order('sort_order').order('unit_price');
  const map = new Map<string, CatalogService>();
  for (const r of rows ?? []) {
    const svc: CatalogService = map.get(r.service_id) ?? { id: r.service_id, name: r.service_name, description: r.service_description, rules: [] };
    svc.rules.push({ id: r.price_rule_id, label: r.label, unit: r.unit, unitPriceMinor: toMinor(r.unit_price), tiers: normalizeTiers(r.bulk_tiers), paperSize: r.paper_size });
    map.set(r.service_id, svc);
  }
  return { press: press as StorefrontPress, services: [...map.values()] };
});

export const logoUrl = (path: string | null) => (path ? `${publicEnv.supabaseUrl}/storage/v1/object/public/press-logos/${path}` : null);
