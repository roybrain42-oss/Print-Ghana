import Link from 'next/link';
import { notFound } from 'next/navigation';
import QRCode from 'qrcode';
import type { Metadata } from 'next';
import { publicEnv } from '@/lib/env';
import { openStatus } from '@/lib/hours';
import { formatMoney } from '@/lib/pricing/engine';
import { Logo } from '@/components/logo';
import { getStorefront, logoUrl } from './data';

export const revalidate = 60;
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const data = await getStorefront((await params).slug);
  return data ? { title: data.press.name, description: data.press.description ?? `Order prints online from ${data.press.name}.` } : { title: 'Press not found' };
}

const DAYS: [string, string][] = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];

export default async function Storefront({ params }: Props) {
  const data = await getStorefront((await params).slug);
  if (!data) notFound();
  const { press, services } = data;
  const orderPath = `/p/${press.slug}/order`;
  const qr = await QRCode.toString(`${publicEnv.appUrl}${orderPath}`, { type: 'svg', margin: 1, errorCorrectionLevel: 'M', color: { dark: '#0D1B2A', light: '#FFFFFF' } });
  const status = openStatus(press.opening_hours, press.timezone);
  const logo = logoUrl(press.logo_path);
  const unit = (u: string) => (u === 'per_page' ? 'per page' : u === 'per_sqm' ? 'per m²' : 'each');
  return (
    <>
      <div className="h-2" style={{ background: press.brand_color }} />
      <header className="border-b border-line bg-white">
        <div className="mx-auto flex w-[min(1120px,100%-2rem)] items-center justify-between gap-3 py-3">
          <div className="flex items-center gap-3 font-display text-lg font-extrabold">
            {logo ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={logo} alt="" width={40} height={40} className="h-10 w-10 rounded-lg object-contain" /> : <Logo size={40} />}
            {press.name}
          </div>
          <Link href={orderPath} className="btn btn-primary btn-sm">Order now</Link>
        </div>
      </header>
      <main id="main" className="mx-auto w-[min(1120px,100%-2rem)] py-10">
        <section className="grid items-center gap-8 md:grid-cols-[1.4fr_1fr]" aria-labelledby="h">
          <div>
            <h1 id="h" className="font-display text-5xl font-extrabold leading-[1.02] sm:text-6xl" style={{ textShadow: '-3px 2px 0 #00A3E0, 3px -2px 0 #E6007E' }}>{press.name}</h1>
            {press.description && <p className="mt-5 max-w-prose text-lg text-ink-soft">{press.description}</p>}
            <p className={`mt-5 inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1 text-sm font-semibold`} role="status"><span aria-hidden className={`h-2.5 w-2.5 rounded-full ${status.open ? 'bg-emerald-600' : 'bg-red-600'}`} />{status.label}</p>
            <div className="mt-6 flex flex-wrap gap-3"><Link href={orderPath} className="btn btn-primary">Start an order</Link><a href="#prices" className="btn btn-ghost">See prices</a></div>
          </div>
          <aside className="card w-full max-w-sm justify-self-start border-2 border-ink shadow-[8px_8px_0_#0D1B2A] md:justify-self-end" aria-labelledby="qr-h">
            <h2 id="qr-h" className="text-xl font-extrabold">Scan to order from your phone</h2>
            <div className="mt-3 w-48 rounded-lg border border-line bg-white p-2 [&_svg]:h-auto [&_svg]:w-full" role="img" aria-label={`QR code that opens the order page for ${press.name}`} dangerouslySetInnerHTML={{ __html: qr }} />
            <p className="mt-2 text-sm text-ink-soft">Opens this press's order page directly.</p>
          </aside>
        </section>

        <div className="mt-12 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <section id="prices" aria-labelledby="ph" className="card"><h2 id="ph" className="mb-4 text-2xl font-extrabold">Services and prices</h2>
            {services.length === 0 ? <p className="text-sm text-ink-soft">This press has not published prices yet. Contact them directly to order.</p> : services.map((s) => (
              <div key={s.id} className="border-t border-dashed border-line py-4 first:border-0 first:pt-0"><h3 className="text-lg font-bold">{s.name}</h3>{s.description && <p className="text-sm text-ink-soft">{s.description}</p>}
                <div className="table-wrap mt-2 border-0"><table className="table"><tbody>{s.rules.map((r) => (<tr key={r.id}><td className="whitespace-normal">{r.label}{r.tiers.length > 0 && <span className="block text-xs text-ink-soft">{r.tiers.map((t) => `${t.percent_off}% off from ${t.min_qty}`).join(', ')}</span>}</td><td className="text-right tabular-nums">{formatMoney(r.unitPriceMinor, press.currency)} {unit(r.unit)}</td></tr>))}</tbody></table></div></div>))}
          </section>
          <div className="grid content-start gap-6">
            <section className="card" aria-labelledby="ch"><h2 id="ch" className="mb-3 text-xl font-extrabold">Contact and location</h2>
              <dl className="grid grid-cols-[max-content_1fr] gap-x-5 gap-y-1 text-sm">
                {(press.address || press.city) && (<><dt className="text-ink-soft">Address</dt><dd>{[press.address, press.city].filter(Boolean).join(', ')}</dd></>)}
                {press.phone && (<><dt className="text-ink-soft">Phone</dt><dd><a className="text-brand underline" href={`tel:${press.phone}`}>{press.phone}</a></dd></>)}
                {press.whatsapp && (<><dt className="text-ink-soft">WhatsApp</dt><dd><a className="text-brand underline" href={`https://wa.me/${press.whatsapp.replace(/\D/g, '')}`} rel="noopener noreferrer">{press.whatsapp}</a></dd></>)}
                {press.email && (<><dt className="text-ink-soft">Email</dt><dd><a className="text-brand underline" href={`mailto:${press.email}`}>{press.email}</a></dd></>)}
              </dl></section>
            <section className="card" aria-labelledby="oh"><h2 id="oh" className="mb-3 text-xl font-extrabold">Opening hours</h2>
              <table className="w-full text-sm"><tbody>{DAYS.map(([k, label]) => { const h = press.opening_hours[k]; return (<tr key={k}><td className="py-1">{label}</td><td className="py-1 text-right tabular-nums">{h ? `${h.open} to ${h.close}` : 'Closed'}</td></tr>); })}</tbody></table></section>
          </div>
        </div>
      </main>
      <footer className="border-t border-line py-6 text-center text-sm text-ink-soft">Powered by PrintPress · <Link className="underline" href="/track">Track an order</Link></footer>
    </>
  );
}
