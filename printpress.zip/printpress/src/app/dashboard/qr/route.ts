import QRCode from 'qrcode';
import { requirePress } from '@/lib/auth/session';
import { publicEnv } from '@/lib/env';

export async function GET(req: Request) {
  const { press } = await requirePress('manager');
  const url = `${publicEnv.appUrl}/p/${press.slug}/order`;
  const format = new URL(req.url).searchParams.get('format') === 'svg' ? 'svg' : 'png';
  const opts = { margin: 2, errorCorrectionLevel: 'M' as const, color: { dark: '#0D1B2A', light: '#FFFFFF' } };
  if (format === 'svg') {
    const svg = await QRCode.toString(url, { ...opts, type: 'svg' });
    return new Response(svg, { headers: { 'Content-Type': 'image/svg+xml', 'Content-Disposition': `attachment; filename="${press.slug}-qr.svg"` } });
  }
  const png = await QRCode.toBuffer(url, { ...opts, width: 1024 });
  return new Response(new Uint8Array(png), { headers: { 'Content-Type': 'image/png', 'Content-Disposition': `attachment; filename="${press.slug}-qr.png"` } });
}
