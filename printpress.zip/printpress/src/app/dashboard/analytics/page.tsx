import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, PageHeader, StatCard } from '@/components/ui/bits';
import { BarsChart, RevenueChart } from '@/components/charts/charts';
import { money, pick } from '@/lib/utils';
import { METHOD_LABEL } from '@/lib/types';

export const metadata = { title: 'Analytics' };

export default async function AnalyticsPage({ searchParams }: { searchParams: Promise<{ days?: string }> }) {
  const sp = await searchParams;
  const { press } = await requirePress('manager');
  const days = Number(pick(sp.days, ['7', '30', '90'] as const, '30'));
  const supabase = await createClient();
  const [daily, methods, services, statuses] = await Promise.all([
    supabase.rpc('press_revenue_daily', { p_press: press.id, p_days: days }),
    supabase.rpc('press_revenue_by_method', { p_press: press.id, p_days: days }),
    supabase.rpc('press_top_services', { p_press: press.id, p_days: days }),
    supabase.rpc('press_order_status_counts', { p_press: press.id }),
  ]);
  const series = ((daily.data ?? []) as { day: string; revenue: number; payments: number }[]).map((d) => ({ day: d.day, revenue: Number(d.revenue), payments: Number(d.payments) }));
  const revenue = series.reduce((s, d) => s + d.revenue, 0);
  const payments = series.reduce((s, d) => s + d.payments, 0);
  const svc = ((services.data ?? []) as { service: string; quantity: number; revenue: number }[]).map((s) => ({ service: s.service, revenue: Number(s.revenue) }));
  const meth = (methods.data ?? []) as { method: string; revenue: number; payments: number }[];
  return (
    <>
      <PageHeader title="Analytics" sub={`Last ${days} days`} actions={[7, 30, 90].map((d) => (<a key={d} href={`?days=${d}`} aria-current={d === days ? 'true' : undefined} className={`btn btn-sm ${d === days ? '' : 'btn-ghost'}`}>{d} days</a>))} />
      <div className="grid gap-4 sm:grid-cols-3"><StatCard label="Revenue" value={money(revenue, press.currency)} /><StatCard label="Payments recorded" value={payments} /><StatCard label="Average payment" value={money(payments ? revenue / payments : 0, press.currency)} /></div>
      <section className="card mt-6" aria-labelledby="r"><h2 id="r" className="mb-2 text-lg font-bold">Revenue per day</h2>{revenue === 0 ? <EmptyState title="No revenue in this period" body="Payments you record on orders show up here." /> : <RevenueChart data={series} />}</section>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="card" aria-labelledby="s"><h2 id="s" className="mb-2 text-lg font-bold">Top services by sales</h2>{svc.length ? <BarsChart data={svc} xKey="service" yKey="revenue" label="Sales by service" /> : <p className="text-sm text-ink-soft">No orders in this period.</p>}</section>
        <section className="card" aria-labelledby="m"><h2 id="m" className="mb-3 text-lg font-bold">How customers paid</h2>
          {meth.length ? <table className="table"><thead><tr><th>Method</th><th className="text-right">Payments</th><th className="text-right">Amount</th></tr></thead><tbody>{meth.map((m) => (<tr key={m.method}><td>{METHOD_LABEL[m.method]}</td><td className="text-right">{m.payments}</td><td className="text-right tabular-nums">{money(m.revenue, press.currency)}</td></tr>))}</tbody></table> : <p className="text-sm text-ink-soft">No payments in this period.</p>}
          <h3 className="mb-2 mt-6 text-sm font-bold">Orders by status (all time)</h3>
          <ul className="flex flex-wrap gap-2 text-sm">{((statuses.data ?? []) as { status: string; orders: number }[]).map((s) => <li key={s.status} className="badge bg-paper capitalize">{s.status}: {s.orders}</li>)}</ul>
        </section>
      </div>
    </>
  );
}
