import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { PageHeader } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { formatDate } from '@/lib/utils';
import { inviteStaffAction, updateStaffAction } from '../actions';

export const metadata = { title: 'Staff' };
type Member = { id: string; user_id: string; role: 'owner' | 'manager' | 'staff'; is_active: boolean; created_at: string; profiles: { full_name: string; email: string | null } | { full_name: string; email: string | null }[] | null };

export default async function StaffPage() {
  const { press, role, user } = await requirePress('manager');
  const supabase = await createClient();
  const { data } = await supabase.from('press_members').select('id, user_id, role, is_active, created_at, profiles(full_name, email)').eq('press_id', press.id).order('created_at');
  const members = (data ?? []) as unknown as Member[];
  return (
    <>
      <PageHeader title="Staff" sub="People who can sign in to this press" actions={
        <Modal trigger="Invite staff" title="Invite a team member" description="They get an email to set a password. Staff can work on orders and payments. Managers can also edit prices, staff and settings.">
          <ActionForm action={inviteStaffAction}>
            <Field name="fullName" label="Name"><input id="fullName" name="fullName" required maxLength={120} className="input" /></Field>
            <Field name="email" label="Email"><input id="email" name="email" type="email" required className="input" /></Field>
            <Field name="role" label="Role"><select id="role" name="role" className="input"><option value="staff">Staff</option>{role === 'owner' && <option value="manager">Manager</option>}</select></Field>
            <SubmitButton pendingText="Sending…">Send invitation</SubmitButton>
          </ActionForm>
        </Modal>} />
      <div className="table-wrap"><table className="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Added</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
        {members.map((m) => { const p = Array.isArray(m.profiles) ? m.profiles[0] : m.profiles; const editable = m.role !== 'owner' && m.user_id !== user.id && (role === 'owner' || m.role === 'staff'); return (
          <tr key={m.id}><td className="font-semibold">{p?.full_name || 'Pending invite'}</td><td>{p?.email}</td><td className="capitalize">{m.role}</td><td>{m.is_active ? <span className="badge bg-emerald-100 text-emerald-800">Active</span> : <span className="badge bg-slate-200 text-slate-700">Disabled</span>}</td><td>{formatDate(m.created_at, false)}</td>
            <td>{editable && (
              <Modal className="text-xs font-semibold text-brand underline" trigger="Manage" title={`Manage ${p?.full_name ?? 'team member'}`}>
                <ActionForm action={updateStaffAction} resetOnSuccess={false}><input type="hidden" name="memberId" value={m.id} />
                  <Field name="role" label="Role"><select id="role" name="role" defaultValue={m.role} className="input"><option value="staff">Staff</option>{role === 'owner' && <option value="manager">Manager</option>}</select></Field>
                  <Field name="active" label="Access"><select id="active" name="active" defaultValue={String(m.is_active)} className="input"><option value="true">Active</option><option value="false">Disabled (cannot sign in to this press)</option></select></Field>
                  <SubmitButton>Save changes</SubmitButton></ActionForm></Modal>)}</td></tr>); })}
      </tbody></table></div>
    </>
  );
}
