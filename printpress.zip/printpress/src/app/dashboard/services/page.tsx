import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, PageHeader } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { money } from '@/lib/utils';
import { normalizeTiers } from '@/lib/pricing/engine';
import { deletePriceRuleAction, deleteServiceAction, savePriceRuleAction, saveServiceAction } from '../actions';

export const metadata = { title: 'Services & pricing' };
type Service = { id: string; name: string; description: string | null; category: string; active: boolean };
type Rule = { id: string; service_id: string; label: string; paper_size: string; color_mode: 'bw' | 'color'; sides: 'single' | 'double'; unit: string; unit_price: number; bulk_tiers: unknown; active: boolean };

function ServiceForm({ s }: { s?: Service }) {
  return (
    <ActionForm action={saveServiceAction}>
      {s && <input type="hidden" name="id" value={s.id} />}
      <Field name="name" label="Service name"><input id="name" name="name" defaultValue={s?.name} required maxLength={120} className="input" /></Field>
      <Field name="description" label="Description (shown to customers)"><textarea id="description" name="description" defaultValue={s?.description ?? ''} maxLength={1000} rows={3} className="input" /></Field>
      <Field name="category" label="Category"><input id="category" name="category" defaultValue={s?.category ?? 'printing'} maxLength={60} className="input" /></Field>
      <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" name="active" defaultChecked={s?.active ?? true} className="h-4 w-4" /> Show on my public page</label>
      <SubmitButton>{s ? 'Save service' : 'Add service'}</SubmitButton>
    </ActionForm>
  );
}

function RuleForm({ serviceId, r }: { serviceId: string; r?: Rule }) {
  const t = normalizeTiers(r?.bulk_tiers);
  return (
    <ActionForm action={savePriceRuleAction}>
      {r && <input type="hidden" name="id" value={r.id} />}
      <input type="hidden" name="serviceId" value={serviceId} />
      <Field name="label" label="Option name" hint="For example: A4 colour, double-sided"><input id="label" name="label" defaultValue={r?.label} required maxLength={120} className="input" /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field name="paperSize" label="Paper size"><input id="paperSize" name="paperSize" defaultValue={r?.paper_size ?? 'A4'} required maxLength={20} className="input" /></Field>
        <Field name="unitPrice" label="Price"><input id="unitPrice" name="unitPrice" type="number" step="0.01" min="0" defaultValue={r?.unit_price} required className="input" inputMode="decimal" /></Field>
        <Field name="colorMode" label="Colour"><select id="colorMode" name="colorMode" defaultValue={r?.color_mode ?? 'bw'} className="input"><option value="bw">Black and white</option><option value="color">Colour</option></select></Field>
        <Field name="sides" label="Sides"><select id="sides" name="sides" defaultValue={r?.sides ?? 'single'} className="input"><option value="single">Single-sided</option><option value="double">Double-sided</option></select></Field>
        <Field name="unit" label="Charged"><select id="unit" name="unit" defaultValue={r?.unit ?? 'per_page'} className="input"><option value="per_page">Per page</option><option value="per_item">Per item</option><option value="per_copy">Per copy</option><option value="per_sqm">Per square metre</option></select></Field>
      </div>
      <fieldset className="rounded-lg border border-line p-3"><legend className="px-1 text-sm font-semibold">Bulk discounts (optional)</legend>
        <div className="grid grid-cols-2 gap-3">
          <Field name="tier1Min" label="From quantity"><input id="tier1Min" name="tier1Min" type="number" min="0" defaultValue={t[0]?.min_qty ?? ''} className="input" /></Field>
          <Field name="tier1Off" label="Percent off"><input id="tier1Off" name="tier1Off" type="number" min="0" max="90" step="0.5" defaultValue={t[0]?.percent_off ?? ''} className="input" /></Field>
          <Field name="tier2Min" label="From quantity"><input id="tier2Min" name="tier2Min" type="number" min="0" defaultValue={t[1]?.min_qty ?? ''} className="input" /></Field>
          <Field name="tier2Off" label="Percent off"><input id="tier2Off" name="tier2Off" type="number" min="0" max="90" step="0.5" defaultValue={t[1]?.percent_off ?? ''} className="input" /></Field>
        </div></fieldset>
      <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" name="active" defaultChecked={r?.active ?? true} className="h-4 w-4" /> Available to customers</label>
      <SubmitButton>{r ? 'Save price' : 'Add price'}</SubmitButton>
    </ActionForm>
  );
}

function DeleteForm({ id, action, label }: { id: string; action: typeof deleteServiceAction; label: string }) {
  return (
    <Modal className="text-xs font-semibold text-red-700 underline" trigger="Delete" title={`Delete ${label}?`} description="This cannot be undone. Past orders keep their recorded prices.">
      <ActionForm action={action}><input type="hidden" name="id" value={id} /><SubmitButton className="btn btn-danger" pendingText="Deleting…">Delete</SubmitButton></ActionForm>
    </Modal>
  );
}

export default async function ServicesPage() {
  const { press } = await requirePress('manager');
  const supabase = await createClient();
  const [s, r] = await Promise.all([
    supabase.from('services').select('*').eq('press_id', press.id).order('sort_order').order('created_at'),
    supabase.from('price_rules').select('*').eq('press_id', press.id).order('unit_price'),
  ]);
  const services = (s.data ?? []) as Service[]; const rules = (r.data ?? []) as Rule[];
  return (
    <>
      <PageHeader title="Services & pricing" sub="What customers can order and what it costs" actions={<Modal trigger="Add service" title="Add service"><ServiceForm /></Modal>} />
      {services.length === 0 ? <EmptyState title="No services yet" body="Add your first service, then add prices to it. Customers can only order services that have prices." /> : (
        <div className="grid gap-6">{services.map((svc) => {
          const own = rules.filter((x) => x.service_id === svc.id);
          return (
            <section key={svc.id} className="card" aria-labelledby={`s-${svc.id}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h2 id={`s-${svc.id}`} className="text-xl font-bold">{svc.name} {!svc.active && <span className="badge bg-slate-200 text-slate-700">Hidden</span>}</h2>{svc.description && <p className="mt-1 max-w-prose text-sm text-ink-soft">{svc.description}</p>}</div>
                <div className="flex items-center gap-3"><Modal className="btn btn-ghost btn-sm" trigger="Edit" title="Edit service"><ServiceForm s={svc} /></Modal><DeleteForm id={svc.id} action={deleteServiceAction} label={svc.name} /></div>
              </div>
              <div className="table-wrap mt-4"><table className="table"><thead><tr><th>Option</th><th>Paper</th><th className="text-right">Price</th><th>Charged</th><th>Bulk discounts</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
                {own.length === 0 && <tr><td colSpan={6} className="text-ink-soft">No prices yet.</td></tr>}
                {own.map((x) => (<tr key={x.id}><td>{x.label} {!x.active && <span className="badge bg-slate-200 text-slate-700">Off</span>}</td><td>{x.paper_size}</td><td className="text-right tabular-nums">{money(x.unit_price, press.currency)}</td><td>{x.unit.replace('_', ' ')}</td><td>{normalizeTiers(x.bulk_tiers).map((t) => `${t.percent_off}% from ${t.min_qty}`).join(', ') || 'None'}</td>
                  <td><div className="flex items-center gap-3"><Modal className="text-xs font-semibold text-brand underline" trigger="Edit" title="Edit price"><RuleForm serviceId={svc.id} r={x} /></Modal><DeleteForm id={x.id} action={deletePriceRuleAction} label={x.label} /></div></td></tr>))}
              </tbody></table></div>
              <div className="mt-3"><Modal className="btn btn-ghost btn-sm" trigger="Add price" title={`Add price to ${svc.name}`}><RuleForm serviceId={svc.id} /></Modal></div>
            </section>);
        })}</div>)}
    </>
  );
}
