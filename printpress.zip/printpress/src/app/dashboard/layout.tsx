import { requirePress } from '@/lib/auth/session';
import { Shell, type NavItem } from '@/components/shell';
import { signOutAction } from '../(auth)/actions';

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { press, role, profile } = await requirePress('staff');
  const nav: NavItem[] = [
    { href: '/dashboard', label: 'Overview', icon: 'overview', exact: true },
    { href: '/dashboard/orders', label: 'Orders', icon: 'orders' },
    { href: '/dashboard/payments', label: 'Payments', icon: 'payments' },
    ...(role !== 'staff' ? [
      { href: '/dashboard/services', label: 'Services & pricing', icon: 'services' as const },
      { href: '/dashboard/analytics', label: 'Analytics', icon: 'analytics' as const },
      { href: '/dashboard/staff', label: 'Staff', icon: 'staff' as const },
      { href: '/dashboard/settings', label: 'Settings & QR', icon: 'settings' as const },
    ] : []),
  ];
  return (
    <Shell nav={nav} title={press.name} subtitle={`${role[0]!.toUpperCase()}${role.slice(1)}`} userName={profile.full_name || profile.email || ''} signOut={signOutAction}>
      {press.status === 'suspended' ? (
        <div className="card border-red-300 bg-red-50" role="alert">
          <h1 className="text-2xl font-extrabold">This press is suspended</h1>
          <p className="mt-2 text-sm">{press.suspended_reason || 'A platform administrator has suspended this account.'} Your public page is offline and the dashboard is read-only. Contact PrintPress support to resolve this.</p>
        </div>
      ) : (
        <>
          {press.status === 'pending' && (
            <div className="mb-6 rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm" role="status">
              <strong>Awaiting approval.</strong> Set up your services, prices and branding now. Your public page and QR code go live once a platform admin approves your press.
            </div>
          )}
          {children}
        </>
      )}
    </Shell>
  );
}
