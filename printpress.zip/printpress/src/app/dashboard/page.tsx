import Link from 'next/link';
import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, OrderBadge, PageHeader, PayBadge, StatCard } from '@/components/ui/bits';
import { RevenueChart } from '@/components/charts/charts';
import { formatDate, money } from '@/lib/utils';
import type { Order } from '@/lib/types';

export const metadata = { title: 'Overview' };

export default async function Overview() {
  const { press } = await requirePress('staff');
  const supabase = await createClient();
  const [daily, open, unpaid, recent] = await Promise.all([
    supabase.rpc('press_revenue_daily', { p_press: press.id, p_days: 30 }),
    supabase.from('orders').select('id', { count: 'exact', head: true }).eq('press_id', press.id).in('status', ['submitted', 'confirmed', 'printing', 'ready']),
    supabase.from('orders').select('total, amount_paid').eq('press_id', press.id).neq('payment_status', 'paid').neq('status', 'cancelled').limit(2000),
    supabase.from('orders').select('id, order_number, customer_name, status, payment_status, total, created_at').eq('press_id', press.id).order('created_at', { ascending: false }).limit(8),
  ]);
  const series = ((daily.data ?? []) as { day: string; revenue: number }[]).map((d) => ({ day: d.day, revenue: Number(d.revenue) }));
  const today = series.at(-1)?.revenue ?? 0;
  const total30 = series.reduce((s, d) => s + d.revenue, 0);
  const owed = ((unpaid.data ?? []) as { total: number; amount_paid: number }[]).reduce((s, o) => s + (Number(o.total) - Number(o.amount_paid)), 0);
  const orders = (recent.data ?? []) as Order[];

  return (
    <>
      <PageHeader title="Overview" sub={`How ${press.name} is doing`} actions={<Link href="/dashboard/orders" className="btn btn-ghost btn-sm">All orders</Link>} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Revenue today" value={money(today, press.currency)} />
        <StatCard label="Revenue, last 30 days" value={money(total30, press.currency)} />
        <StatCard label="Orders in progress" value={open.count ?? 0} />
        <StatCard label="Waiting to be paid" value={money(owed, press.currency)} />
      </div>
      <section className="card mt-6" aria-labelledby="rev"><h2 id="rev" className="mb-2 text-lg font-bold">Revenue, last 30 days</h2><RevenueChart data={series} /></section>
      <section className="mt-6" aria-labelledby="rec">
        <h2 id="rec" className="mb-3 text-lg font-bold">Recent orders</h2>
        {orders.length === 0 ? <EmptyState title="No orders yet" body="Share your QR code or page link so customers can send their first order." action={<Link className="btn btn-primary btn-sm" href="/dashboard/settings">Get your QR code</Link>} /> : (
          <div className="table-wrap"><table className="table"><thead><tr><th>Order</th><th>Customer</th><th>Status</th><th>Payment</th><th className="text-right">Total</th><th>Placed</th></tr></thead>
            <tbody>{orders.map((o) => (
              <tr key={o.id}><td><Link className="font-semibold text-brand underline" href={`/dashboard/orders/${o.id}`}>{o.order_number}</Link></td><td>{o.customer_name}</td><td><OrderBadge status={o.status} /></td><td><PayBadge status={o.payment_status} /></td><td className="text-right tabular-nums">{money(o.total, press.currency)}</td><td>{formatDate(o.created_at)}</td></tr>
            ))}</tbody></table></div>
        )}
      </section>
    </>
  );
}
