'use server';
import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { failState, fromZod, okState, type ActionState } from '@/lib/action';
import { tryPress } from '@/lib/auth/session';
import { audit } from '@/lib/audit';
import { rateLimit } from '@/lib/security/http';
import { publicEnv } from '@/lib/env';
import { DAYS, orderStatusSchema, paymentSchema, priceRuleSchema, pressSettingsSchema, serviceSchema, staffInviteSchema } from '@/lib/validation';
import { sniffFamily } from '@/lib/security/upload';

const DENIED = failState('You do not have permission to do that.');

const TRANSITIONS: Record<string, string[]> = {
  submitted: ['confirmed', 'printing', 'cancelled'],
  confirmed: ['printing', 'ready', 'cancelled'],
  printing: ['ready', 'cancelled'],
  ready: ['completed', 'printing'],
  completed: [],
  cancelled: [],
};

// ---------- Orders & payments ----------
export async function updateOrderStatusAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('staff'); if (!ctx) return DENIED;
  const parsed = orderStatusSchema.safeParse({ orderId: fd.get('orderId'), status: fd.get('status') });
  if (!parsed.success) return fromZod(parsed.error);
  const supabase = await createClient();
  const { data: order } = await supabase.from('orders').select('id, status').eq('id', parsed.data.orderId).eq('press_id', ctx.press.id).maybeSingle();
  if (!order) return failState('Order not found.');
  if (order.status === parsed.data.status) return okState('Status unchanged.');
  if (!TRANSITIONS[order.status]?.includes(parsed.data.status)) return failState(`An order that is ${order.status} cannot move to ${parsed.data.status}.`);
  const { error } = await supabase.from('orders').update({ status: parsed.data.status }).eq('id', order.id).eq('press_id', ctx.press.id);
  if (error) return failState('Could not update the order.');
  revalidatePath('/dashboard', 'layout');
  return okState(`Order marked ${parsed.data.status}.`);
}

export async function recordPaymentAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('staff'); if (!ctx) return DENIED;
  const parsed = paymentSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  const supabase = await createClient();
  const { data: order } = await supabase.from('orders').select('id, total, amount_paid, status').eq('id', parsed.data.orderId).eq('press_id', ctx.press.id).maybeSingle();
  if (!order) return failState('Order not found.');
  if (order.status === 'cancelled') return failState('This order is cancelled.');
  const balance = Math.round((Number(order.total) - Number(order.amount_paid)) * 100);
  const amountMinor = Math.round(parsed.data.amount * 100);
  if (amountMinor > balance) return failState('Please fix the highlighted fields.', { amount: `That is more than the balance due (${(balance / 100).toFixed(2)}).` });
  const { error } = await supabase.from('payments').insert({
    press_id: ctx.press.id, order_id: order.id, amount: amountMinor / 100, method: parsed.data.method,
    reference: parsed.data.reference || null, recorded_by: ctx.user.id,
  });
  if (error) return failState('Could not record the payment.');
  revalidatePath('/dashboard', 'layout');
  return okState('Payment recorded.');
}

export async function voidPaymentAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const id = String(fd.get('paymentId') ?? ''); const reason = String(fd.get('reason') ?? '').trim().slice(0, 200);
  if (!/^[0-9a-f-]{36}$/i.test(id)) return failState('Payment not found.');
  if (reason.length < 3) return failState('Please fix the highlighted fields.', { reason: 'Give a reason for voiding this payment.' });
  const supabase = await createClient();
  const { error } = await supabase.from('payments').update({ voided_at: new Date().toISOString(), void_reason: reason }).eq('id', id).eq('press_id', ctx.press.id).is('voided_at', null);
  if (error) return failState('Could not void the payment.');
  revalidatePath('/dashboard', 'layout');
  return okState('Payment voided.');
}

// ---------- Services & prices ----------
export async function saveServiceAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const parsed = serviceSchema.safeParse({ name: fd.get('name'), description: fd.get('description') ?? '', category: fd.get('category') ?? 'printing', active: fd.get('active') === 'on' });
  if (!parsed.success) return fromZod(parsed.error);
  const supabase = await createClient();
  const id = String(fd.get('id') ?? '');
  const row = { name: parsed.data.name, description: parsed.data.description || null, category: parsed.data.category, active: parsed.data.active };
  const { error } = id
    ? await supabase.from('services').update(row).eq('id', id).eq('press_id', ctx.press.id)
    : await supabase.from('services').insert({ ...row, press_id: ctx.press.id });
  if (error) return failState('Could not save the service.');
  revalidatePath('/dashboard/services'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState(id ? 'Service updated.' : 'Service added.');
}

export async function deleteServiceAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const supabase = await createClient();
  const { error } = await supabase.from('services').delete().eq('id', String(fd.get('id') ?? '')).eq('press_id', ctx.press.id);
  if (error) return failState('Could not delete the service.');
  revalidatePath('/dashboard/services'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState('Service deleted.');
}

export async function savePriceRuleAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const parsed = priceRuleSchema.safeParse({ ...Object.fromEntries(fd), active: fd.get('active') === 'on' });
  if (!parsed.success) return fromZod(parsed.error);
  const d = parsed.data;
  const tiers = [
    ...(d.tier1Min > 0 && d.tier1Off > 0 ? [{ min_qty: d.tier1Min, percent_off: d.tier1Off }] : []),
    ...(d.tier2Min > 0 && d.tier2Off > 0 ? [{ min_qty: d.tier2Min, percent_off: d.tier2Off }] : []),
  ];
  const supabase = await createClient();
  const { data: svc } = await supabase.from('services').select('id').eq('id', d.serviceId).eq('press_id', ctx.press.id).maybeSingle();
  if (!svc) return failState('Service not found.');
  const row = { label: d.label, paper_size: d.paperSize, color_mode: d.colorMode, sides: d.sides, unit: d.unit, unit_price: d.unitPrice, bulk_tiers: tiers, active: d.active };
  const id = String(fd.get('id') ?? '');
  const { error } = id
    ? await supabase.from('price_rules').update(row).eq('id', id).eq('press_id', ctx.press.id)
    : await supabase.from('price_rules').insert({ ...row, press_id: ctx.press.id, service_id: d.serviceId });
  if (error) return failState('Could not save the price.');
  revalidatePath('/dashboard/services'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState(id ? 'Price updated.' : 'Price added.');
}

export async function deletePriceRuleAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const supabase = await createClient();
  const { error } = await supabase.from('price_rules').delete().eq('id', String(fd.get('id') ?? '')).eq('press_id', ctx.press.id);
  if (error) return failState('Could not delete the price.');
  revalidatePath('/dashboard/services'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState('Price deleted.');
}

// ---------- Staff ----------
export async function inviteStaffAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const parsed = staffInviteSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  if (ctx.role === 'manager' && parsed.data.role !== 'staff') return failState('Only the owner can add managers.');
  if (!(await rateLimit(`invite:press:${ctx.press.id}`, 3600, 20))) return failState('Too many invitations. Try again later.');

  const admin = createAdminClient();
  const { data: existing } = await admin.from('profiles').select('id').eq('email', parsed.data.email).maybeSingle();
  let userId = existing?.id as string | undefined;
  if (userId) {
    const { count } = await admin.from('press_members').select('id', { count: 'exact', head: true }).eq('user_id', userId);
    if ((count ?? 0) > 0) return failState('Please fix the highlighted fields.', { email: 'This person already works at a press.' });
  } else {
    const { data, error } = await admin.auth.admin.inviteUserByEmail(parsed.data.email, {
      data: { full_name: parsed.data.fullName }, redirectTo: `${publicEnv.appUrl}/auth/callback?next=/set-password`,
    });
    if (error || !data.user) return failState('We could not send the invitation. Check the email address.');
    userId = data.user.id;
  }
  const { error: mErr } = await admin.from('press_members').insert({ press_id: ctx.press.id, user_id: userId, role: parsed.data.role });
  if (mErr) return failState('Could not add this person to your team.');
  await audit({ action: 'staff.invite', entityType: 'press_member', entityId: userId, pressId: ctx.press.id, actorId: ctx.user.id, metadata: { email: parsed.data.email, role: parsed.data.role } });
  revalidatePath('/dashboard/staff');
  return okState(existing ? 'Added to your team.' : 'Invitation sent.');
}

export async function updateStaffAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const memberId = String(fd.get('memberId') ?? '');
  const role = String(fd.get('role') ?? '');
  const active = fd.get('active') === 'true';
  if (!['manager', 'staff'].includes(role)) return failState('Invalid role.');
  const supabase = await createClient(); // RLS: owners manage all, managers manage staff only
  const { data: target } = await supabase.from('press_members').select('id, user_id, role').eq('id', memberId).eq('press_id', ctx.press.id).maybeSingle();
  if (!target) return failState('Team member not found.');
  if (target.role === 'owner') return failState('The owner cannot be changed here.');
  if (target.user_id === ctx.user.id) return failState('You cannot change your own access.');
  const { data: updated, error } = await supabase.from('press_members').update({ role, is_active: active }).eq('id', memberId).eq('press_id', ctx.press.id).select('id');
  if (error || !updated?.length) return failState('You do not have permission to change this person.');
  revalidatePath('/dashboard/staff');
  return okState('Team member updated.');
}

// ---------- Settings & logo ----------
export async function saveSettingsAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const parsed = pressSettingsSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  const hours: Record<string, { open: string; close: string } | null> = {};
  for (const d of DAYS) {
    const open = String(fd.get(`${d}_open`) ?? ''); const close = String(fd.get(`${d}_close`) ?? '');
    const closed = fd.get(`${d}_closed`) === 'on';
    const ok = /^([01]\d|2[0-3]):[0-5]\d$/;
    hours[d] = closed || !ok.test(open) || !ok.test(close) || open >= close ? null : { open, close };
  }
  const p = parsed.data;
  const supabase = await createClient();
  const { error } = await supabase.from('presses').update({
    name: p.name, description: p.description || null, brand_color: p.brandColor, email: p.email || null,
    phone: p.phone || null, whatsapp: p.whatsapp || null, address: p.address || null, city: p.city || null, opening_hours: hours,
  }).eq('id', ctx.press.id);
  if (error) return failState('Could not save your settings.');
  revalidatePath('/dashboard', 'layout'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState('Settings saved.');
}

export async function uploadLogoAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const ctx = await tryPress('manager'); if (!ctx) return DENIED;
  const file = fd.get('logo');
  if (!(file instanceof File) || file.size === 0) return failState('Choose an image to upload.');
  if (file.size > 2 * 1024 * 1024) return failState('Logos must be 2 MB or smaller.');
  const bytes = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const fam = sniffFamily(bytes);
  const isWebp = bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 && bytes[8] === 0x57 && bytes[9] === 0x45;
  const ext = fam === 'png' ? 'png' : fam === 'jpeg' ? 'jpg' : isWebp ? 'webp' : null;
  if (!ext) return failState('Use a PNG, JPG or WebP image.');
  const contentType = ext === 'png' ? 'image/png' : ext === 'jpg' ? 'image/jpeg' : 'image/webp';
  const path = `${ctx.press.id}/logo-${Date.now()}.${ext}`;
  const supabase = await createClient(); // storage policy: only owner/manager of this press folder
  const { error } = await supabase.storage.from('press-logos').upload(path, file, { contentType, upsert: false });
  if (error) return failState('Could not upload the logo.');
  const { error: uErr } = await supabase.from('presses').update({ logo_path: path }).eq('id', ctx.press.id);
  if (uErr) return failState('Logo uploaded but could not be attached.');
  if (ctx.press.logo_path) await supabase.storage.from('press-logos').remove([ctx.press.logo_path]);
  revalidatePath('/dashboard', 'layout'); revalidatePath(`/p/${ctx.press.slug}`);
  return okState('Logo updated.');
}
