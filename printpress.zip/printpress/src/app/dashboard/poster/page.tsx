import QRCode from 'qrcode';
import { requirePress } from '@/lib/auth/session';
import { publicEnv } from '@/lib/env';
import { PrintButton } from './print-button';

export const metadata = { title: 'Order poster' };

export default async function PosterPage() {
  const { press } = await requirePress('manager');
  const url = `${publicEnv.appUrl}/p/${press.slug}/order`;
  const svg = await QRCode.toString(url, { type: 'svg', margin: 1, errorCorrectionLevel: 'M', color: { dark: '#0D1B2A', light: '#FFFFFF' } });
  return (
    <div className="mx-auto max-w-[210mm] bg-white p-10 text-center print:p-0">
      <div className="mb-6 print:hidden"><PrintButton /></div>
      <div className="colorbar h-4" />
      <h1 className="mt-10 text-6xl font-extrabold" style={{ textShadow: '-3px 2px 0 #00A3E0, 3px -2px 0 #E6007E' }}>{press.name}</h1>
      <p className="mt-6 text-3xl font-bold">Scan to order</p>
      <p className="mt-1 text-xl text-ink-soft">Upload your files, see the price, and we start printing.</p>
      <div className="mx-auto my-8 w-[420px] max-w-full [&_svg]:h-auto [&_svg]:w-full" dangerouslySetInnerHTML={{ __html: svg }} />
      <p className="text-lg">{[press.address, press.city].filter(Boolean).join(', ')}</p>
      <p className="text-lg">{press.phone}</p>
      <div className="colorbar mt-10 h-4" />
    </div>
  );
}
