import Link from 'next/link';
import QRCode from 'qrcode';
import { requirePress } from '@/lib/auth/session';
import { PageHeader } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { publicEnv } from '@/lib/env';
import { DAYS } from '@/lib/validation';
import { saveSettingsAction, uploadLogoAction } from '../actions';

export const metadata = { title: 'Settings & QR' };
const LABEL: Record<string, string> = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };

export default async function SettingsPage() {
  const { press } = await requirePress('manager');
  const orderUrl = `${publicEnv.appUrl}/p/${press.slug}/order`;
  const svg = await QRCode.toString(orderUrl, { type: 'svg', margin: 2, errorCorrectionLevel: 'M', color: { dark: '#0D1B2A', light: '#FFFFFF' } });
  const logoUrl = press.logo_path ? `${publicEnv.supabaseUrl}/storage/v1/object/public/press-logos/${press.logo_path}` : null;
  return (
    <>
      <PageHeader title="Settings & QR code" sub="Your public page and how customers reach it" actions={press.status === 'approved' ? <Link className="btn btn-ghost btn-sm" href={`/p/${press.slug}`} target="_blank">View public page</Link> : undefined} />
      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="grid content-start gap-6">
          <section className="card" aria-labelledby="d"><h2 id="d" className="mb-3 text-lg font-bold">Business details</h2>
            <ActionForm action={saveSettingsAction} resetOnSuccess={false}>
              <Field name="name" label="Business name"><input id="name" name="name" defaultValue={press.name} required maxLength={120} className="input" /></Field>
              <Field name="description" label="About your press"><textarea id="description" name="description" defaultValue={press.description ?? ''} rows={3} maxLength={2000} className="input" /></Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field name="phone" label="Phone"><input id="phone" name="phone" type="tel" defaultValue={press.phone ?? ''} className="input" /></Field>
                <Field name="whatsapp" label="WhatsApp number"><input id="whatsapp" name="whatsapp" type="tel" defaultValue={press.whatsapp ?? ''} className="input" /></Field>
                <Field name="email" label="Email"><input id="email" name="email" type="email" defaultValue={press.email ?? ''} className="input" /></Field>
                <Field name="brandColor" label="Brand colour"><input id="brandColor" name="brandColor" type="color" defaultValue={press.brand_color} className="input h-11 p-1" /></Field>
                <Field name="address" label="Address"><input id="address" name="address" defaultValue={press.address ?? ''} className="input" /></Field>
                <Field name="city" label="City"><input id="city" name="city" defaultValue={press.city ?? ''} className="input" /></Field>
              </div>
              <fieldset className="rounded-lg border border-line p-3"><legend className="px-1 text-sm font-semibold">Opening hours</legend>
                <div className="grid gap-2">{DAYS.map((d) => { const h = press.opening_hours?.[d]; return (
                  <div key={d} className="grid grid-cols-[90px_1fr_1fr_auto] items-center gap-2 text-sm">
                    <span>{LABEL[d]}</span>
                    <input aria-label={`${LABEL[d]} opens`} name={`${d}_open`} type="time" defaultValue={h?.open ?? '08:00'} className="input" />
                    <input aria-label={`${LABEL[d]} closes`} name={`${d}_close`} type="time" defaultValue={h?.close ?? '18:00'} className="input" />
                    <label className="flex items-center gap-1"><input type="checkbox" name={`${d}_closed`} defaultChecked={!h} /> Closed</label>
                  </div>); })}</div></fieldset>
              <SubmitButton>Save settings</SubmitButton>
            </ActionForm>
          </section>
          <section className="card" aria-labelledby="l"><h2 id="l" className="mb-3 text-lg font-bold">Logo</h2>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {logoUrl && <img src={logoUrl} alt={`${press.name} logo`} className="mb-3 h-20 w-20 rounded-lg border border-line object-contain" />}
            <ActionForm action={uploadLogoAction}><Field name="logo" label="Upload a logo" hint="PNG, JPG or WebP, up to 2 MB."><input id="logo" name="logo" type="file" accept="image/png,image/jpeg,image/webp" required className="input" /></Field><SubmitButton pendingText="Uploading…">Upload logo</SubmitButton></ActionForm>
          </section>
        </div>
        <aside className="card content-start self-start" aria-labelledby="q"><h2 id="q" className="mb-1 text-lg font-bold">Your QR code</h2>
          <p className="mb-3 text-sm text-ink-soft">Customers who scan this land directly on your order form.</p>
          <div className="w-full max-w-[260px] rounded-lg border border-line bg-white p-2 [&_svg]:h-auto [&_svg]:w-full" role="img" aria-label="QR code for your order page" dangerouslySetInnerHTML={{ __html: svg }} />
          <p className="mt-2 break-all text-xs text-ink-soft">{orderUrl}</p>
          <div className="mt-4 flex flex-wrap gap-2"><a className="btn btn-ghost btn-sm" href="/dashboard/qr?format=png" download>Download PNG</a><a className="btn btn-ghost btn-sm" href="/dashboard/qr?format=svg" download>Download SVG</a><Link className="btn btn-primary btn-sm" href="/dashboard/poster" target="_blank">Print poster</Link></div>
          {press.status !== 'approved' && <p className="mt-3 rounded bg-amber-50 p-2 text-xs">The link works once your press is approved.</p>}
        </aside>
      </div>
    </>
  );
}
