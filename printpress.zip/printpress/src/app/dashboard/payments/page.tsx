import Link from 'next/link';
import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, FilterBar, PageHeader, Pagination } from '@/components/ui/bits';
import { formatDate, money, pick, sanitizeSearch, toInt } from '@/lib/utils';
import { METHOD_LABEL, PAYMENT_METHODS } from '@/lib/types';

export const metadata = { title: 'Payments' };
const PAGE = 20;

export default async function PaymentsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { press } = await requirePress('staff');
  const q = sanitizeSearch(sp.q);
  const method = pick(sp.method, ['', ...PAYMENT_METHODS] as const, '');
  const page = toInt(sp.page, 1);
  const supabase = await createClient();
  let query = supabase.from('payments').select('id, amount, method, reference, paid_at, voided_at, order_id, orders(order_number, customer_name)', { count: 'exact' }).eq('press_id', press.id);
  if (method) query = query.eq('method', method);
  if (q) query = query.ilike('reference', `%${q}%`);
  const { data, count } = await query.order('paid_at', { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1);
  type Row = { id: string; amount: number; method: string; reference: string | null; paid_at: string; voided_at: string | null; order_id: string; orders: { order_number: string; customer_name: string } | { order_number: string; customer_name: string }[] | null };
  const rows = (data ?? []) as unknown as Row[];
  return (
    <>
      <PageHeader title="Payments" sub="Every payment recorded against an order" />
      <FilterBar action="/dashboard/payments" q={q}>
        <div><label htmlFor="method" className="label">Method</label><select id="method" name="method" defaultValue={method} className="input"><option value="">All</option>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{METHOD_LABEL[m]}</option>)}</select></div>
      </FilterBar>
      {rows.length === 0 ? <EmptyState title="No payments yet" body="Record a payment from an order and it appears here." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>Date</th><th>Order</th><th>Customer</th><th>Method</th><th>Reference</th><th className="text-right">Amount</th></tr></thead><tbody>
          {rows.map((r) => { const o = Array.isArray(r.orders) ? r.orders[0] : r.orders; return (
            <tr key={r.id} className={r.voided_at ? 'text-ink-soft line-through' : ''}><td>{formatDate(r.paid_at)}</td><td><Link className="text-brand underline" href={`/dashboard/orders/${r.order_id}`}>{o?.order_number}</Link></td><td>{o?.customer_name}</td><td>{METHOD_LABEL[r.method]}</td><td>{r.reference}</td><td className="text-right tabular-nums">{money(r.amount, press.currency)}{r.voided_at ? ' (void)' : ''}</td></tr>); })}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((count ?? 0) / PAGE)} basePath="/dashboard/payments" params={{ q, method }} />
    </>
  );
}
