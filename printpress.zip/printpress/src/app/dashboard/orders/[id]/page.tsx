import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { OrderBadge, PageHeader, PayBadge } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { formatDate, money } from '@/lib/utils';
import { METHOD_LABEL, ORDER_STATUSES, PAYMENT_METHODS, type Order } from '@/lib/types';
import { recordPaymentAction, updateOrderStatusAction, voidPaymentAction } from '../../actions';

export const metadata = { title: 'Order' };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID.test(id)) notFound();
  const { press, role } = await requirePress('staff');
  const supabase = await createClient();
  const { data: order } = await supabase.from('orders').select('*').eq('id', id).eq('press_id', press.id).maybeSingle();
  if (!order) notFound();
  const o = order as Order;
  const [items, files, payments] = await Promise.all([
    supabase.from('order_items').select('id, description, quantity, unit_price, line_total').eq('order_id', id),
    supabase.from('order_files').select('id, original_name, size_bytes, mime_type').eq('order_id', id),
    supabase.from('payments').select('id, amount, method, reference, paid_at, voided_at, void_reason').eq('order_id', id).order('paid_at', { ascending: false }),
  ]);
  const balance = Number(o.total) - Number(o.amount_paid);
  const cur = press.currency;

  return (
    <>
      <PageHeader title={o.order_number ?? 'Order'} sub={`Placed ${formatDate(o.created_at)}`} actions={<Link href="/dashboard/orders" className="btn btn-ghost btn-sm">Back to orders</Link>} />
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="grid content-start gap-6">
          <section className="card" aria-labelledby="cust"><h2 id="cust" className="mb-3 text-lg font-bold">Customer</h2>
            <dl className="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-1 text-sm"><dt className="text-ink-soft">Name</dt><dd>{o.customer_name}</dd><dt className="text-ink-soft">Phone</dt><dd><a className="text-brand underline" href={`tel:${o.customer_phone}`}>{o.customer_phone}</a></dd>{o.customer_email && (<><dt className="text-ink-soft">Email</dt><dd>{o.customer_email}</dd></>)}{o.notes && (<><dt className="text-ink-soft">Notes</dt><dd className="whitespace-pre-wrap">{o.notes}</dd></>)}</dl>
          </section>
          <section aria-labelledby="its"><h2 id="its" className="mb-3 text-lg font-bold">Items</h2>
            <div className="table-wrap"><table className="table"><thead><tr><th>Description</th><th className="text-right">Qty</th><th className="text-right">Unit</th><th className="text-right">Line total</th></tr></thead><tbody>
              {(items.data ?? []).map((i) => (<tr key={i.id}><td className="whitespace-normal">{i.description}</td><td className="text-right tabular-nums">{i.quantity}</td><td className="text-right tabular-nums">{money(i.unit_price, cur)}</td><td className="text-right tabular-nums">{money(i.line_total, cur)}</td></tr>))}
            </tbody></table></div>
          </section>
          <section aria-labelledby="fl"><h2 id="fl" className="mb-3 text-lg font-bold">Files</h2>
            {(files.data ?? []).length === 0 ? <p className="text-sm text-ink-soft">No files attached.</p> : (
              <ul className="grid gap-2">{(files.data ?? []).map((f) => (
                <li key={f.id} className="card flex items-center justify-between gap-3 py-3"><span className="min-w-0 truncate text-sm font-semibold">{f.original_name} <span className="font-normal text-ink-soft">({(f.size_bytes / 1048576).toFixed(1)} MB)</span></span>
                  {/* Opens a 60-second signed URL after a server-side access check; the raw storage path is never exposed. */}
                  <a className="btn btn-ghost btn-sm" href={`/api/files/${f.id}`} rel="nofollow">Download</a></li>))}</ul>)}
          </section>
        </div>
        <aside className="grid content-start gap-6">
          <section className="card" aria-labelledby="st"><h2 id="st" className="mb-3 text-lg font-bold">Status</h2>
            <div className="mb-3 flex gap-2"><OrderBadge status={o.status} /><PayBadge status={o.payment_status} /></div>
            <ActionForm action={updateOrderStatusAction} className="grid gap-3" resetOnSuccess={false}>
              <input type="hidden" name="orderId" value={o.id} />
              <Field name="status" label="Move to"><select id="status" name="status" className="input" defaultValue={o.status}>{ORDER_STATUSES.map((s) => <option key={s} value={s}>{s[0]!.toUpperCase() + s.slice(1)}</option>)}</select></Field>
              <SubmitButton>Update status</SubmitButton>
            </ActionForm>
          </section>
          <section className="card" aria-labelledby="pay"><h2 id="pay" className="mb-3 text-lg font-bold">Payment</h2>
            <dl className="grid grid-cols-[1fr_auto] gap-y-1 text-sm tabular-nums"><dt>Subtotal</dt><dd>{money(o.subtotal, cur)}</dd>{Number(o.discount) > 0 && (<><dt>Discount</dt><dd>-{money(o.discount, cur)}</dd></>)}<dt className="font-bold">Total</dt><dd className="font-bold">{money(o.total, cur)}</dd><dt>Paid</dt><dd>{money(o.amount_paid, cur)}</dd><dt className="font-bold">Balance</dt><dd className="font-bold">{money(balance, cur)}</dd></dl>
            {balance > 0 && o.status !== 'cancelled' && (
              <div className="mt-4"><Modal trigger="Record payment" title="Record payment" description={`Balance due: ${money(balance, cur)}`}>
                <ActionForm action={recordPaymentAction}>
                  <input type="hidden" name="orderId" value={o.id} />
                  <Field name="amount" label="Amount received"><input id="amount" name="amount" type="number" step="0.01" min="0.01" max={balance} defaultValue={balance.toFixed(2)} required className="input" inputMode="decimal" /></Field>
                  <Field name="method" label="Method"><select id="method" name="method" className="input">{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{METHOD_LABEL[m]}</option>)}</select></Field>
                  <Field name="reference" label="Reference (optional)" hint="Mobile money transaction ID, receipt number, etc."><input id="reference" name="reference" maxLength={120} className="input" /></Field>
                  <SubmitButton>Save payment</SubmitButton>
                </ActionForm></Modal></div>)}
            {(payments.data ?? []).length > 0 && (
              <ul className="mt-4 grid gap-2 text-sm">{(payments.data ?? []).map((p) => (
                <li key={p.id} className="rounded-lg border border-line p-3"><div className="flex justify-between gap-2"><span className={p.voided_at ? 'line-through text-ink-soft' : 'font-semibold'}>{money(p.amount, cur)} · {METHOD_LABEL[p.method]}</span><span className="text-xs text-ink-soft">{formatDate(p.paid_at)}</span></div>
                  {p.reference && <p className="text-xs text-ink-soft">Ref: {p.reference}</p>}
                  {p.voided_at ? <p className="text-xs text-red-700">Voided: {p.void_reason}</p> : role !== 'staff' && (
                    <div className="mt-2"><Modal className="text-xs font-semibold text-red-700 underline" trigger="Void" title="Void this payment" description="Voided payments stay in the audit trail but no longer count toward revenue.">
                      <ActionForm action={voidPaymentAction}><input type="hidden" name="paymentId" value={p.id} />
                        <Field name="reason" label="Reason"><input id="reason" name="reason" required maxLength={200} className="input" /></Field><SubmitButton className="btn btn-danger">Void payment</SubmitButton></ActionForm></Modal></div>)}
                </li>))}</ul>)}
          </section>
        </aside>
      </div>
    </>
  );
}
