import Link from 'next/link';
import { requirePress } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, FilterBar, OrderBadge, PageHeader, PayBadge, Pagination } from '@/components/ui/bits';
import { formatDate, money, pick, sanitizeSearch, toInt } from '@/lib/utils';
import { ORDER_STATUSES, type Order } from '@/lib/types';

export const metadata = { title: 'Orders' };
const PAGE = 15;
const SORTS = { newest: ['created_at', false], oldest: ['created_at', true], total_desc: ['total', false], total_asc: ['total', true] } as const;

export default async function OrdersPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { press } = await requirePress('staff');
  const q = sanitizeSearch(sp.q);
  const status = pick(sp.status, ['', ...ORDER_STATUSES] as const, '');
  const pay = pick(sp.pay, ['', 'unpaid', 'partial', 'paid'] as const, '');
  const sort = pick(sp.sort, Object.keys(SORTS) as (keyof typeof SORTS)[], 'newest');
  const page = toInt(sp.page, 1);

  const supabase = await createClient();
  let query = supabase.from('orders')
    .select('id, order_number, customer_name, customer_phone, status, payment_status, total, amount_paid, created_at', { count: 'exact' })
    .eq('press_id', press.id);
  if (status) query = query.eq('status', status);
  if (pay) query = query.eq('payment_status', pay);
  if (q) query = query.or(`customer_name.ilike.%${q}%,customer_phone.ilike.%${q}%,order_number.ilike.%${q}%`);
  const [col, asc] = SORTS[sort];
  const { data, count, error } = await query.order(col, { ascending: asc }).range((page - 1) * PAGE, page * PAGE - 1);
  const rows = (data ?? []) as Order[];

  return (
    <>
      <PageHeader title="Orders" sub={`${count ?? 0} orders`} />
      <FilterBar action="/dashboard/orders" q={q}>
        <div><label htmlFor="status" className="label">Status</label><select id="status" name="status" defaultValue={status} className="input"><option value="">All</option>{ORDER_STATUSES.map((s) => <option key={s} value={s} className="capitalize">{s}</option>)}</select></div>
        <div><label htmlFor="pay" className="label">Payment</label><select id="pay" name="pay" defaultValue={pay} className="input"><option value="">All</option><option value="unpaid">Unpaid</option><option value="partial">Partial</option><option value="paid">Paid</option></select></div>
        <div><label htmlFor="sort" className="label">Sort</label><select id="sort" name="sort" defaultValue={sort} className="input"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="total_desc">Highest total</option><option value="total_asc">Lowest total</option></select></div>
      </FilterBar>
      {error ? <div role="alert" className="card border-red-300 bg-red-50 text-sm">We could not load orders. Refresh the page to try again.</div>
        : rows.length === 0 ? <EmptyState title="No orders match" body={q || status || pay ? 'Try clearing the filters.' : 'New orders from your page and QR code appear here.'} />
        : (<div className="table-wrap"><table className="table"><thead><tr><th>Order</th><th>Customer</th><th>Phone</th><th>Status</th><th>Payment</th><th className="text-right">Total</th><th className="text-right">Paid</th><th>Placed</th></tr></thead><tbody>
          {rows.map((o) => (<tr key={o.id}><td><Link className="font-semibold text-brand underline" href={`/dashboard/orders/${o.id}`}>{o.order_number}</Link></td><td>{o.customer_name}</td><td>{o.customer_phone}</td><td><OrderBadge status={o.status} /></td><td><PayBadge status={o.payment_status} /></td><td className="text-right tabular-nums">{money(o.total, press.currency)}</td><td className="text-right tabular-nums">{money(o.amount_paid, press.currency)}</td><td>{formatDate(o.created_at)}</td></tr>))}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((count ?? 0) / PAGE)} basePath="/dashboard/orders" params={{ q, status, pay, sort }} />
    </>
  );
}
