import { redirect } from 'next/navigation';
import { requireUser } from '@/lib/auth/session';
import { createAdminClient } from '@/lib/supabase/admin';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Logo } from '@/components/logo';
import { onboardingAction } from '../(auth)/actions';

export const metadata = { title: 'Set up your press' };

export default async function OnboardingPage() {
  const { user, profile } = await requireUser();
  const { count } = await createAdminClient().from('press_members').select('id', { count: 'exact', head: true }).eq('user_id', user.id);
  if ((count ?? 0) > 0) redirect('/dashboard');
  return (
    <div className="min-h-screen">
      <div className="colorbar h-2" />
      <main id="main" className="mx-auto grid w-[min(480px,100%-2rem)] gap-6 py-12">
        <div className="flex items-center gap-2 font-display text-xl font-extrabold"><Logo /> PrintPress</div>
        <div className="card p-6">
          <h1 className="text-2xl font-extrabold">Set up your press</h1>
          <p className="mt-1 text-sm text-ink-soft">Welcome{profile.full_name ? `, ${profile.full_name}` : ''}. Choose your business name and public address. Your press goes live after a platform admin approves it.</p>
          <ActionForm action={onboardingAction} className="mt-4 grid gap-4" resetOnSuccess={false}>
            <Field name="name" label="Business name"><input id="name" name="name" required maxLength={120} className="input" /></Field>
            <Field name="slug" label="Public address" hint="Customers will order at /p/your-address. Lowercase letters, numbers and hyphens.">
              <input id="slug" name="slug" required minLength={3} maxLength={60} pattern="[a-z0-9]+(-[a-z0-9]+)*" className="input" />
            </Field>
            <SubmitButton pendingText="Creating…">Create press</SubmitButton>
          </ActionForm>
        </div>
      </main>
    </div>
  );
}
