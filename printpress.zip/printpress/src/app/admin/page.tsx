import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, PageHeader, PressBadge, StatCard } from '@/components/ui/bits';
import { RevenueChart, BarsChart } from '@/components/charts/charts';
import { formatDate, money } from '@/lib/utils';
import type { Press } from '@/lib/types';

export const metadata = { title: 'Admin overview' };

export default async function AdminOverview() {
  const supabase = await createClient();
  const [stats, daily, pending] = await Promise.all([
    supabase.rpc('platform_stats'), supabase.rpc('platform_daily', { p_days: 30 }),
    supabase.from('presses').select('*').eq('status', 'pending').order('created_at').limit(10),
  ]);
  const s = (stats.data ?? {}) as Record<string, number>;
  const series = ((daily.data ?? []) as { day: string; orders: number; revenue: number }[]).map((d) => ({ day: d.day, revenue: Number(d.revenue), orders: Number(d.orders) }));
  return (
    <>
      <PageHeader title="Platform overview" sub="Everything across all presses" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Presses" value={s.presses_total ?? 0} sub={`${s.presses_approved ?? 0} live · ${s.presses_pending ?? 0} pending · ${s.presses_suspended ?? 0} suspended`} />
        <StatCard label="Users" value={s.users_total ?? 0} />
        <StatCard label="Orders" value={s.orders_total ?? 0} sub={`${s.orders_30d ?? 0} in the last 30 days`} />
        <StatCard label="Payments recorded" value={money(s.revenue_total ?? 0)} sub={`${money(s.revenue_30d ?? 0)} in the last 30 days`} />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="card" aria-labelledby="a"><h2 id="a" className="mb-2 text-lg font-bold">Payments per day</h2><RevenueChart data={series} /></section>
        <section className="card" aria-labelledby="b"><h2 id="b" className="mb-2 text-lg font-bold">Orders per day</h2><BarsChart data={series} xKey="day" yKey="orders" label="Orders per day" color="#00A3E0" /></section>
      </div>
      <section className="mt-6" aria-labelledby="p"><h2 id="p" className="mb-3 text-lg font-bold">Waiting for approval</h2>
        {(pending.data ?? []).length === 0 ? <EmptyState title="Nothing waiting" body="New presses that register will appear here for review." /> : (
          <div className="table-wrap"><table className="table"><thead><tr><th>Press</th><th>Address</th><th>Status</th><th>Registered</th><th><span className="sr-only">Review</span></th></tr></thead><tbody>
            {((pending.data ?? []) as Press[]).map((p) => (<tr key={p.id}><td className="font-semibold">{p.name}</td><td>/p/{p.slug}</td><td><PressBadge status={p.status} /></td><td>{formatDate(p.created_at, false)}</td><td><Link className="text-brand underline" href={`/admin/presses?q=${encodeURIComponent(p.slug)}`}>Review</Link></td></tr>))}
          </tbody></table></div>)}
      </section>
    </>
  );
}
