import { createClient } from '@/lib/supabase/server';
import { EmptyState, FilterBar, PageHeader, Pagination } from '@/components/ui/bits';
import { formatDate, sanitizeSearch, toInt } from '@/lib/utils';

export const metadata = { title: 'Activity log' };
const PAGE = 30;
type Row = { id: number; created_at: string; action: string; entity_type: string; entity_id: string | null; actor_id: string | null; ip: string | null; metadata: Record<string, unknown>; presses: { name: string } | { name: string }[] | null };

export default async function LogsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = sanitizeSearch(sp.q);
  const page = toInt(sp.page, 1);
  const supabase = await createClient();
  let query = supabase.from('audit_logs').select('id, created_at, action, entity_type, entity_id, actor_id, ip, metadata, presses(name)', { count: 'exact' });
  if (q) query = query.ilike('action', `%${q}%`);
  const { data, count } = await query.order('created_at', { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1);
  const rows = (data ?? []) as unknown as Row[];
  const actorIds = [...new Set(rows.map((r) => r.actor_id).filter(Boolean))] as string[];
  const { data: actors } = actorIds.length ? await supabase.from('profiles').select('id, full_name, email').in('id', actorIds) : { data: [] as { id: string; full_name: string; email: string | null }[] };
  const who = new Map((actors ?? []).map((a) => [a.id, a.full_name || a.email || a.id]));
  return (
    <>
      <PageHeader title="Activity log" sub="Append-only record of sign-ins, approvals, payments, file downloads and changes" />
      <FilterBar action="/admin/logs" q={q} />
      {rows.length === 0 ? <EmptyState title="No activity found" body="Try a different search, such as press.approve or files.download." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>When</th><th>Action</th><th>Who</th><th>Press</th><th>Entity</th><th>IP</th><th>Details</th></tr></thead><tbody>
          {rows.map((r) => { const p = Array.isArray(r.presses) ? r.presses[0] : r.presses; const detail = JSON.stringify(r.metadata); return (
            <tr key={r.id}><td>{formatDate(r.created_at)}</td><td className="font-mono text-xs">{r.action}</td><td>{r.actor_id ? who.get(r.actor_id) ?? r.actor_id.slice(0, 8) : 'System'}</td><td>{p?.name ?? '—'}</td><td className="text-xs">{r.entity_type}{r.entity_id ? ` ${r.entity_id.slice(0, 8)}` : ''}</td><td className="text-xs">{r.ip ?? ''}</td><td className="max-w-[280px] truncate text-xs text-ink-soft" title={detail}>{detail}</td></tr>); })}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((count ?? 0) / PAGE)} basePath="/admin/logs" params={{ q }} />
    </>
  );
}
