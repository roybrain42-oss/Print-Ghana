import { createClient } from '@/lib/supabase/server';
import { requireSuperAdmin } from '@/lib/auth/session';
import { EmptyState, FilterBar, PageHeader, Pagination } from '@/components/ui/bits';
import { ActionForm, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { formatDate, pick, sanitizeSearch, toInt } from '@/lib/utils';
import { setPlatformRoleAction, setUserActiveAction } from '../actions';

export const metadata = { title: 'Users' };
const PAGE = 20;
type Row = { id: string; full_name: string; email: string | null; platform_role: string; is_active: boolean; created_at: string; press_members: { role: string; presses: { name: string } | { name: string }[] | null }[] };

export default async function UsersPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { user } = await requireSuperAdmin();
  const q = sanitizeSearch(sp.q);
  const state = pick(sp.state, ['', 'active', 'inactive', 'admins'] as const, '');
  const page = toInt(sp.page, 1);
  const supabase = await createClient();
  let query = supabase.from('profiles').select('*, press_members(role, presses(name))', { count: 'exact' });
  if (state === 'active') query = query.eq('is_active', true);
  if (state === 'inactive') query = query.eq('is_active', false);
  if (state === 'admins') query = query.eq('platform_role', 'super_admin');
  if (q) query = query.or(`full_name.ilike.%${q}%,email.ilike.%${q}%`);
  const { data, count } = await query.order('created_at', { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1);
  const rows = (data ?? []) as unknown as Row[];
  return (
    <>
      <PageHeader title="Users" sub={`${count ?? 0} accounts`} />
      <FilterBar action="/admin/users" q={q}><div><label htmlFor="state" className="label">Show</label><select id="state" name="state" defaultValue={state} className="input"><option value="">Everyone</option><option value="active">Active</option><option value="inactive">Deactivated</option><option value="admins">Platform admins</option></select></div></FilterBar>
      {rows.length === 0 ? <EmptyState title="No users found" body="Try clearing the filters." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>Name</th><th>Email</th><th>Press</th><th>Platform role</th><th>Status</th><th>Joined</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
          {rows.map((u) => { const m = u.press_members?.[0]; const pr = m ? (Array.isArray(m.presses) ? m.presses[0] : m.presses) : null; const self = u.id === user.id; return (
            <tr key={u.id}><td className="font-semibold">{u.full_name || '—'}</td><td>{u.email}</td><td>{pr ? `${pr.name} (${m!.role})` : '—'}</td><td>{u.platform_role === 'super_admin' ? <span className="badge bg-indigo-100 text-indigo-800">Platform admin</span> : 'User'}</td><td>{u.is_active ? <span className="badge bg-emerald-100 text-emerald-800">Active</span> : <span className="badge bg-red-100 text-red-800">Deactivated</span>}</td><td>{formatDate(u.created_at, false)}</td>
              <td>{!self && (<div className="flex items-center gap-3">
                <Modal className="text-xs font-semibold text-brand underline" trigger={u.is_active ? 'Deactivate' : 'Reactivate'} title={`${u.is_active ? 'Deactivate' : 'Reactivate'} ${u.full_name || u.email}?`} description={u.is_active ? 'They are signed out and cannot sign in until reactivated.' : 'They can sign in again.'}><ActionForm action={setUserActiveAction} resetOnSuccess={false}><input type="hidden" name="userId" value={u.id} /><input type="hidden" name="active" value={String(!u.is_active)} /><SubmitButton className={u.is_active ? 'btn btn-danger' : 'btn btn-primary'}>{u.is_active ? 'Deactivate user' : 'Reactivate user'}</SubmitButton></ActionForm></Modal>
                <Modal className="text-xs font-semibold text-brand underline" trigger={u.platform_role === 'super_admin' ? 'Remove admin' : 'Make admin'} title="Change platform role" description="Platform admins can approve presses, manage users and read all activity. They still cannot open customer files."><ActionForm action={setPlatformRoleAction} resetOnSuccess={false}><input type="hidden" name="userId" value={u.id} /><input type="hidden" name="role" value={u.platform_role === 'super_admin' ? 'user' : 'super_admin'} /><SubmitButton>{u.platform_role === 'super_admin' ? 'Remove admin access' : 'Grant admin access'}</SubmitButton></ActionForm></Modal></div>)}</td></tr>); })}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((count ?? 0) / PAGE)} basePath="/admin/users" params={{ q, state }} />
    </>
  );
}
