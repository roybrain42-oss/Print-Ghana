import { createClient } from '@/lib/supabase/server';
import { EmptyState, FilterBar, OrderBadge, PageHeader, PayBadge, Pagination } from '@/components/ui/bits';
import { formatDate, money, pick, sanitizeSearch, toInt } from '@/lib/utils';
import { ORDER_STATUSES, type Order } from '@/lib/types';

export const metadata = { title: 'All orders' };
const PAGE = 20;

export default async function AdminOrders({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = sanitizeSearch(sp.q);
  const status = pick(sp.status, ['', ...ORDER_STATUSES] as const, '');
  const page = toInt(sp.page, 1);
  const supabase = await createClient();
  let query = supabase.from('orders').select('id, order_number, customer_name, status, payment_status, total, created_at, presses(name, currency)', { count: 'exact' });
  if (status) query = query.eq('status', status);
  if (q) query = query.or(`customer_name.ilike.%${q}%,order_number.ilike.%${q}%`);
  const { data, count } = await query.order('created_at', { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1);
  type Row = Order & { presses: { name: string; currency: string } | { name: string; currency: string }[] | null };
  const rows = (data ?? []) as unknown as Row[];
  return (
    <>
      <PageHeader title="Orders across all presses" sub="Read-only monitoring. Customer files are only visible to the press that owns them." />
      <FilterBar action="/admin/orders" q={q}><div><label htmlFor="status" className="label">Status</label><select id="status" name="status" defaultValue={status} className="input"><option value="">All</option>{ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</select></div></FilterBar>
      {rows.length === 0 ? <EmptyState title="No orders found" body="Try clearing the filters." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>Order</th><th>Press</th><th>Customer</th><th>Status</th><th>Payment</th><th className="text-right">Total</th><th>Placed</th></tr></thead><tbody>
          {rows.map((o) => { const p = Array.isArray(o.presses) ? o.presses[0] : o.presses; return (<tr key={o.id}><td className="font-semibold">{o.order_number}</td><td>{p?.name}</td><td>{o.customer_name}</td><td><OrderBadge status={o.status} /></td><td><PayBadge status={o.payment_status} /></td><td className="text-right tabular-nums">{money(o.total, p?.currency)}</td><td>{formatDate(o.created_at)}</td></tr>); })}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((count ?? 0) / PAGE)} basePath="/admin/orders" params={{ q, status }} />
    </>
  );
}
