import { createClient } from '@/lib/supabase/server';
import { EmptyState, PageHeader } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { money } from '@/lib/utils';
import { savePlanAction } from '../actions';

export const metadata = { title: 'Plans' };
type Plan = { id: string; code: string; name: string; monthly_price: number; limits: { staff?: number; orders_per_month?: number } };

function PlanForm({ p }: { p?: Plan }) {
  return (
    <ActionForm action={savePlanAction}>
      {p && <input type="hidden" name="id" value={p.id} />}
      <div className="grid grid-cols-2 gap-3">
        <Field name="name" label="Name"><input id="name" name="name" defaultValue={p?.name} required className="input" /></Field>
        <Field name="code" label="Code"><input id="code" name="code" defaultValue={p?.code} required className="input" /></Field>
        <Field name="monthlyPrice" label="Monthly price"><input id="monthlyPrice" name="monthlyPrice" type="number" step="0.01" min="0" defaultValue={p?.monthly_price ?? 0} required className="input" /></Field>
        <Field name="staff" label="Staff limit"><input id="staff" name="staff" type="number" min="1" defaultValue={p?.limits?.staff ?? 5} required className="input" /></Field>
        <Field name="ordersPerMonth" label="Orders per month"><input id="ordersPerMonth" name="ordersPerMonth" type="number" min="1" defaultValue={p?.limits?.orders_per_month ?? 500} required className="input" /></Field>
      </div>
      <SubmitButton>{p ? 'Save plan' : 'Add plan'}</SubmitButton>
    </ActionForm>
  );
}

export default async function PlansPage() {
  const { data } = await (await createClient()).from('plans').select('*').order('monthly_price');
  const plans = (data ?? []) as Plan[];
  return (
    <>
      <PageHeader title="Plans" sub="Structure for subscriptions. Limits are recorded now; billing and enforcement can be added later." actions={<Modal trigger="Add plan" title="Add plan"><PlanForm /></Modal>} />
      {plans.length === 0 ? <EmptyState title="No plans yet" body="Add a plan to start grouping presses by tier." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>Plan</th><th>Code</th><th className="text-right">Monthly price</th><th className="text-right">Staff</th><th className="text-right">Orders / month</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
          {plans.map((p) => (<tr key={p.id}><td className="font-semibold">{p.name}</td><td className="font-mono text-xs">{p.code}</td><td className="text-right tabular-nums">{money(p.monthly_price)}</td><td className="text-right">{p.limits?.staff}</td><td className="text-right">{p.limits?.orders_per_month}</td><td><Modal className="text-xs font-semibold text-brand underline" trigger="Edit" title={`Edit ${p.name}`}><PlanForm p={p} /></Modal></td></tr>))}
        </tbody></table></div>)}
    </>
  );
}
