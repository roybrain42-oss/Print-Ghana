import { PageHeader } from '@/components/ui/bits';
import { ActionForm, SubmitButton } from '@/components/ui/action-form';
import { getPlatformSettings } from '@/lib/settings';
import { saveSettingAction } from '../actions';

export const metadata = { title: 'System settings' };

export default async function SettingsPage() {
  const s = await getPlatformSettings();
  return (
    <>
      <PageHeader title="System settings" sub="Rules that apply to the whole platform" />
      <section className="card max-w-xl">
        <ActionForm action={saveSettingAction} resetOnSuccess={false}>
          <label className="flex items-start gap-3"><input type="checkbox" name="registration_open" defaultChecked={s.registration_open} className="mt-1 h-4 w-4" /><span><span className="block font-semibold">Allow new registrations</span><span className="text-sm text-ink-soft">Turn off to stop new accounts from signing up. Existing users are not affected.</span></span></label>
          <label className="flex items-start gap-3"><input type="checkbox" name="require_press_approval" defaultChecked={s.require_press_approval} className="mt-1 h-4 w-4" /><span><span className="block font-semibold">Review new presses before they go live</span><span className="text-sm text-ink-soft">When on, a new press stays offline until a platform admin approves it.</span></span></label>
          <SubmitButton>Save settings</SubmitButton>
        </ActionForm>
      </section>
    </>
  );
}
