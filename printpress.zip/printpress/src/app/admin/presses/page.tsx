import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { EmptyState, FilterBar, PageHeader, Pagination, PressBadge } from '@/components/ui/bits';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Modal } from '@/components/ui/modal';
import { formatDate, money, pick, sanitizeSearch, toInt } from '@/lib/utils';
import type { Press } from '@/lib/types';
import { setPressPlanAction, setPressStatusAction } from '../actions';

export const metadata = { title: 'Printing presses' };
const PAGE = 15;
type Row = Press & { plan_id: string | null; press_members: { role: string; profiles: { full_name: string; email: string | null } | { full_name: string; email: string | null }[] | null }[] };

export default async function PressesPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = sanitizeSearch(sp.q);
  const status = pick(sp.status, ['', 'pending', 'approved', 'suspended'] as const, '');
  const page = toInt(sp.page, 1);
  const supabase = await createClient();
  let query = supabase.from('presses').select('*, press_members(role, profiles(full_name, email))', { count: 'exact' });
  if (status) query = query.eq('status', status);
  if (q) query = query.or(`name.ilike.%${q}%,slug.ilike.%${q}%`);
  const [list, rollup, plans] = await Promise.all([
    query.order('created_at', { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1),
    supabase.rpc('platform_press_rollup'), supabase.from('plans').select('id, name').order('monthly_price'),
  ]);
  const roll = new Map(((rollup.data ?? []) as { press_id: string; orders: number; revenue: number; staff: number }[]).map((r) => [r.press_id, r]));
  const rows = (list.data ?? []) as unknown as Row[];
  return (
    <>
      <PageHeader title="Printing presses" sub={`${list.count ?? 0} registered`} />
      <FilterBar action="/admin/presses" q={q}>
        <div><label htmlFor="status" className="label">Status</label><select id="status" name="status" defaultValue={status} className="input"><option value="">All</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="suspended">Suspended</option></select></div>
      </FilterBar>
      {rows.length === 0 ? <EmptyState title="No presses found" body="Try clearing the filters." /> : (
        <div className="table-wrap"><table className="table"><thead><tr><th>Press</th><th>Owner</th><th>Status</th><th className="text-right">Orders</th><th className="text-right">Payments</th><th className="text-right">Staff</th><th>Registered</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
          {rows.map((p) => { const m = p.press_members?.find((x) => x.role === 'owner'); const o = m ? (Array.isArray(m.profiles) ? m.profiles[0] : m.profiles) : null; const r = roll.get(p.id); return (
            <tr key={p.id}><td><span className="font-semibold">{p.name}</span><span className="block text-xs text-ink-soft">{p.status === 'approved' ? <Link className="underline" href={`/p/${p.slug}`} target="_blank">/p/{p.slug}</Link> : `/p/${p.slug}`}</span></td>
              <td>{o?.full_name}<span className="block text-xs text-ink-soft">{o?.email}</span></td><td><PressBadge status={p.status} />{p.suspended_reason && <span className="block max-w-[220px] truncate text-xs text-ink-soft" title={p.suspended_reason}>{p.suspended_reason}</span>}</td>
              <td className="text-right tabular-nums">{r?.orders ?? 0}</td><td className="text-right tabular-nums">{money(r?.revenue ?? 0, p.currency)}</td><td className="text-right tabular-nums">{r?.staff ?? 0}</td><td>{formatDate(p.created_at, false)}</td>
              <td><div className="flex items-center gap-3">
                {p.status !== 'approved' && (<Modal className="btn btn-primary btn-sm" trigger="Approve" title={`Approve ${p.name}?`} description="The public page and QR ordering go live immediately."><ActionForm action={setPressStatusAction} resetOnSuccess={false}><input type="hidden" name="pressId" value={p.id} /><input type="hidden" name="status" value="approved" /><SubmitButton>Approve press</SubmitButton></ActionForm></Modal>)}
                {p.status !== 'suspended' && (<Modal className="btn btn-ghost btn-sm" trigger="Suspend" title={`Suspend ${p.name}?`} description="The public page goes offline and staff lose access until you approve it again."><ActionForm action={setPressStatusAction} resetOnSuccess={false}><input type="hidden" name="pressId" value={p.id} /><input type="hidden" name="status" value="suspended" /><Field name="reason" label="Reason shown to the owner"><input id="reason" name="reason" required maxLength={300} className="input" /></Field><SubmitButton className="btn btn-danger">Suspend press</SubmitButton></ActionForm></Modal>)}
                <Modal className="text-xs font-semibold text-brand underline" trigger="Plan" title={`Plan for ${p.name}`}><ActionForm action={setPressPlanAction} resetOnSuccess={false}><input type="hidden" name="pressId" value={p.id} /><Field name="planId" label="Plan"><select id="planId" name="planId" defaultValue={p.plan_id ?? ''} className="input"><option value="">No plan</option>{(plans.data ?? []).map((pl) => <option key={pl.id} value={pl.id}>{pl.name}</option>)}</select></Field><SubmitButton>Save plan</SubmitButton></ActionForm></Modal>
              </div></td></tr>); })}
        </tbody></table></div>)}
      <Pagination page={page} pages={Math.ceil((list.count ?? 0) / PAGE)} basePath="/admin/presses" params={{ q, status }} />
    </>
  );
}
