'use server';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { failState, fromZod, okState, type ActionState } from '@/lib/action';
import { getCurrentUser } from '@/lib/auth/session';
import { audit } from '@/lib/audit';

const uuid = z.string().uuid();

async function admin() {
  const s = await getCurrentUser();
  return s && s.profile.platform_role === 'super_admin' ? s : null;
}
const DENIED = failState('You do not have permission to do that.');

export async function setPressStatusAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const parsed = z.object({ pressId: uuid, status: z.enum(['approved', 'suspended', 'pending']), reason: z.string().trim().max(300).optional().default('') }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  const { pressId, status, reason } = parsed.data;
  if (status === 'suspended' && reason.length < 3) return failState('Please fix the highlighted fields.', { reason: 'Give a reason. The press owner will see it.' });
  const supabase = await createClient();
  const { error } = await supabase.from('presses').update({
    status, suspended_reason: status === 'suspended' ? reason : null,
    approved_at: status === 'approved' ? new Date().toISOString() : null, approved_by: status === 'approved' ? me.user.id : null,
  }).eq('id', pressId);
  if (error) return failState('Could not update the press.');
  await audit({ action: `press.${status === 'approved' ? 'approve' : status === 'suspended' ? 'suspend' : 'reset'}`, entityType: 'press', entityId: pressId, pressId, actorId: me.user.id, metadata: { reason } });
  revalidatePath('/admin', 'layout'); revalidatePath('/p', 'layout');
  return okState(status === 'approved' ? 'Press approved.' : status === 'suspended' ? 'Press suspended.' : 'Press set back to pending.');
}

export async function setPressPlanAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const parsed = z.object({ pressId: uuid, planId: z.union([uuid, z.literal('')]) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  const { error } = await (await createClient()).from('presses').update({ plan_id: parsed.data.planId || null }).eq('id', parsed.data.pressId);
  if (error) return failState('Could not change the plan.');
  revalidatePath('/admin/presses');
  return okState('Plan updated.');
}

export async function setUserActiveAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const parsed = z.object({ userId: uuid, active: z.enum(['true', 'false']) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  if (parsed.data.userId === me.user.id) return failState('You cannot deactivate your own account.');
  const active = parsed.data.active === 'true';
  const { error } = await (await createClient()).from('profiles').update({ is_active: active }).eq('id', parsed.data.userId);
  if (error) return failState('Could not update the user.');
  // Also block sign-in at the Auth layer and end the disabled user's existing sessions.
  await createAdminClient().auth.admin.updateUserById(parsed.data.userId, { ban_duration: active ? 'none' : '876000h' });
  await audit({ action: active ? 'user.activate' : 'user.deactivate', entityType: 'user', entityId: parsed.data.userId, actorId: me.user.id });
  revalidatePath('/admin/users');
  return okState(active ? 'User reactivated.' : 'User deactivated and signed out.');
}

export async function setPlatformRoleAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const parsed = z.object({ userId: uuid, role: z.enum(['user', 'super_admin']) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  if (parsed.data.userId === me.user.id) return failState('You cannot change your own platform role.');
  const { error } = await (await createClient()).from('profiles').update({ platform_role: parsed.data.role }).eq('id', parsed.data.userId);
  if (error) return failState('Could not change the role.');
  await audit({ action: 'user.platform_role', entityType: 'user', entityId: parsed.data.userId, actorId: me.user.id, metadata: { role: parsed.data.role } });
  revalidatePath('/admin/users');
  return okState('Platform role updated.');
}

export async function saveSettingAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const rows = ['registration_open', 'require_press_approval'].map((key) => ({ key, value: fd.get(key) === 'on', updated_by: me.user.id, updated_at: new Date().toISOString() }));
  const { error } = await (await createClient()).from('platform_settings').upsert(rows);
  if (error) return failState('Could not save settings.');
  await audit({ action: 'settings.update', entityType: 'platform_settings', actorId: me.user.id, metadata: Object.fromEntries(rows.map((r) => [r.key, r.value])) });
  revalidatePath('/admin/settings');
  return okState('Settings saved.');
}

export async function savePlanAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const me = await admin(); if (!me) return DENIED;
  const parsed = z.object({
    id: z.union([uuid, z.literal('')]).optional().default(''),
    code: z.string().trim().toLowerCase().regex(/^[a-z0-9_-]{2,30}$/, 'Use 2 to 30 lowercase letters, numbers, - or _'),
    name: z.string().trim().min(2, 'Name is required').max(60),
    monthlyPrice: z.coerce.number().min(0, 'Price cannot be negative').max(100000),
    staff: z.coerce.number().int().min(1).max(1000), ordersPerMonth: z.coerce.number().int().min(1).max(1000000),
  }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return fromZod(parsed.error);
  const d = parsed.data;
  const row = { code: d.code, name: d.name, monthly_price: d.monthlyPrice, limits: { staff: d.staff, orders_per_month: d.ordersPerMonth } };
  const supabase = await createClient();
  const { error } = d.id ? await supabase.from('plans').update(row).eq('id', d.id) : await supabase.from('plans').insert(row);
  if (error) return failState(error.code === '23505' ? 'That plan code already exists.' : 'Could not save the plan.');
  await audit({ action: d.id ? 'plan.update' : 'plan.create', entityType: 'plan', entityId: d.id || d.code, actorId: me.user.id });
  revalidatePath('/admin/plans');
  return okState('Plan saved.');
}
