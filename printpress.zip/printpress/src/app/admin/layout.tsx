import { requireSuperAdmin } from '@/lib/auth/session';
import { Shell, type NavItem } from '@/components/shell';
import { signOutAction } from '../(auth)/actions';

const NAV: NavItem[] = [
  { href: '/admin', label: 'Overview', icon: 'overview', exact: true },
  { href: '/admin/presses', label: 'Printing presses', icon: 'presses' },
  { href: '/admin/users', label: 'Users', icon: 'users' },
  { href: '/admin/orders', label: 'Orders', icon: 'orders' },
  { href: '/admin/logs', label: 'Activity log', icon: 'logs' },
  { href: '/admin/plans', label: 'Plans', icon: 'payments' },
  { href: '/admin/settings', label: 'System settings', icon: 'settings' },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { profile } = await requireSuperAdmin();
  return <Shell nav={NAV} title="PrintPress Admin" subtitle="Super admin" userName={profile.full_name || profile.email || ''} signOut={signOutAction}>{children}</Shell>;
}
