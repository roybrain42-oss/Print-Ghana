import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { getCurrentUser } from '@/lib/auth/session';
import { audit } from '@/lib/audit';
import { rateLimit } from '@/lib/security/http';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Private document download. Only members of the file's own press are served,
 * and only via a 60 second signed URL. Not even super admins can open customer documents.
 */
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getCurrentUser();
  if (!session) return new NextResponse('Unauthorized', { status: 401 });
  if (!UUID.test(id)) return new NextResponse('Not found', { status: 404 });
  if (!(await rateLimit(`download:${session.user.id}`, 60, 60))) return new NextResponse('Too many requests', { status: 429 });

  const supabase = await createClient();
  const { data: file } = await supabase.from('order_files').select('id, press_id, order_id, storage_path, original_name').eq('id', id).maybeSingle(); // RLS
  if (!file) return new NextResponse('Not found', { status: 404 });
  const { data: member } = await supabase.rpc('is_press_member', { p_press: file.press_id });
  if (member !== true) return new NextResponse('Not found', { status: 404 });

  const admin = createAdminClient();
  const { data, error } = await admin.storage.from('order-files').createSignedUrl(file.storage_path, 60, { download: file.original_name });
  if (error || !data?.signedUrl) return new NextResponse('File unavailable', { status: 404 });
  await audit({ action: 'files.download', entityType: 'order_file', entityId: file.id, pressId: file.press_id, actorId: session.user.id, metadata: { orderId: file.order_id } });
  const res = NextResponse.redirect(data.signedUrl, 302);
  res.headers.set('Cache-Control', 'no-store');
  return res;
}
