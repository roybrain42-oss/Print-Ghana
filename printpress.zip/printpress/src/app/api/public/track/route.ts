import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { isSameOrigin, ipFromHeaders, rateLimit } from '@/lib/security/http';
import { normalizePhone } from '@/lib/utils';

const json = (body: unknown, status = 200) => NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
const schema = z.object({ code: z.string().trim().toLowerCase().regex(/^[0-9a-f]{18}$/), phone: z.string().trim().min(7).max(20) });

/** Customers look up an order with tracking code AND phone. Same error for every failure to prevent probing. */
export async function POST(req: Request) {
  if (!isSameOrigin(req)) return json({ error: 'Request blocked.' }, 403);
  if (!(await rateLimit(`track:ip:${ipFromHeaders(req.headers)}`, 600, 20))) return json({ error: 'Too many lookups. Please wait a few minutes.' }, 429);
  const parsed = schema.safeParse(await req.json().catch(() => null));
  const NOT_FOUND = json({ error: 'We could not find an order with those details.' }, 404);
  if (!parsed.success) return NOT_FOUND;

  const admin = createAdminClient();
  const { data: o } = await admin.from('orders')
    .select('order_number, status, payment_status, total, amount_paid, created_at, customer_phone, presses(name, currency)')
    .eq('tracking_code', parsed.data.code).neq('status', 'draft').maybeSingle();
  if (!o || normalizePhone(o.customer_phone) !== normalizePhone(parsed.data.phone)) return NOT_FOUND;
  const press = Array.isArray(o.presses) ? o.presses[0] : o.presses;
  return json({ orderNumber: o.order_number, status: o.status, paymentStatus: o.payment_status, total: o.total, amountPaid: o.amount_paid, placedAt: o.created_at, press: press?.name, currency: press?.currency ?? 'GHS' });
}
