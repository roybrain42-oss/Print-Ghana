import { randomUUID } from 'node:crypto';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { isSameOrigin, ipFromHeaders, rateLimit } from '@/lib/security/http';
import { publicOrderSchema } from '@/lib/validation';
import { normalizeTiers, PricingError, quoteLine, toMinor } from '@/lib/pricing/engine';
import { validateUploadMeta } from '@/lib/security/upload';
import { audit } from '@/lib/audit';

const json = (body: unknown, status = 200) => NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store' } });

/**
 * Step 1 of a customer order. Anonymous, so every defence is server-side:
 * origin check, IP + phone rate limits, honeypot, schema validation, price recomputed
 * from the database (client prices are never trusted), file metadata validation.
 * Creates a DRAFT order (invisible to staff) and returns one-time signed upload URLs.
 */
export async function POST(req: Request) {
  if (!isSameOrigin(req)) return json({ error: 'Request blocked.' }, 403);
  const ip = ipFromHeaders(req.headers);
  if (!(await rateLimit(`order:ip:${ip}`, 3600, 15))) return json({ error: 'Too many orders from your network. Please try again later.' }, 429);

  let body: unknown;
  try { body = await req.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
  const parsed = publicOrderSchema.safeParse(body);
  if (!parsed.success) return json({ error: parsed.error.issues[0]?.message ?? 'Invalid order.' }, 422);
  const input = parsed.data;
  if (input.website) return json({ error: 'Request blocked.' }, 403); // honeypot
  if (!(await rateLimit(`order:phone:${input.customer.phone.replace(/\D/g, '')}`, 3600, 8))) return json({ error: 'Too many orders for this phone number. Please try again later.' }, 429);

  const admin = createAdminClient();
  const { data: press } = await admin.from('presses').select('id, slug, name, status, currency').eq('slug', input.slug).maybeSingle();
  if (!press || press.status !== 'approved') return json({ error: 'This press is not accepting orders right now.' }, 404);

  // Files: validate declared metadata (bytes are verified again after upload).
  const fileChecks = [];
  for (const f of input.files) {
    const c = validateUploadMeta(f);
    if (!c.ok) return json({ error: c.error }, 422);
    fileChecks.push({ meta: f, check: c });
  }

  // Price from database rules belonging to THIS press only.
  const ruleIds = [...new Set(input.items.map((i) => i.ruleId))];
  const { data: rules } = await admin.from('price_rules').select('id, service_id, label, unit, unit_price, bulk_tiers, active, services(name, active)').eq('press_id', press.id).in('id', ruleIds);
  const byId = new Map((rules ?? []).map((r) => [r.id as string, r]));
  const lines = [];
  for (const item of input.items) {
    const r = byId.get(item.ruleId) as (typeof rules extends (infer T)[] | null ? T : never) | undefined;
    const svc = r ? (Array.isArray(r.services) ? r.services[0] : r.services) : null;
    if (!r || !r.active || !svc?.active) return json({ error: 'One of the selected options is no longer available.' }, 422);
    try {
      const q = quoteLine({ unit: r.unit, unitPriceMinor: toMinor(r.unit_price), tiers: normalizeTiers(r.bulk_tiers) }, { pages: item.pages, copies: item.copies, areaSqm: item.areaSqm });
      const detail = r.unit === 'per_page' ? `${item.pages} pages × ${item.copies} copies` : r.unit === 'per_sqm' ? `${item.areaSqm} m² × ${item.copies}` : `${item.copies} ×`;
      lines.push({ r, svc, q, description: `${svc.name}: ${r.label} (${detail})` });
    } catch (e) {
      if (e instanceof PricingError) return json({ error: e.message }, 422);
      throw e;
    }
  }

  const { data: order, error: oErr } = await admin.from('orders').insert({
    press_id: press.id, status: 'draft', customer_name: input.customer.name, customer_phone: input.customer.phone,
    customer_email: input.customer.email || null, notes: input.notes || null,
  }).select('id, tracking_code').single();
  if (oErr || !order) return json({ error: 'We could not create your order. Please try again.' }, 500);

  const cleanup = async () => { await admin.from('orders').delete().eq('id', order.id); };

  const { error: iErr } = await admin.from('order_items').insert(lines.map((l) => ({
    press_id: press.id, order_id: order.id, service_id: l.r.service_id, price_rule_id: l.r.id,
    description: l.description, quantity: l.q.quantity, unit_price: l.q.unitPriceMinor / 100, line_total: l.q.totalMinor / 100,
  })));
  if (iErr) { await cleanup(); return json({ error: 'We could not save your order items.' }, 500); }

  const uploads: { index: number; path: string; token: string }[] = [];
  const fileRows = fileChecks.map((f, index) => ({
    press_id: press.id, order_id: order.id, index,
    storage_path: `${press.id}/${order.id}/${randomUUID()}.${f.check.ok ? f.check.ext : 'bin'}`,
    original_name: f.check.ok ? f.check.safeName : f.meta.name, mime_type: f.meta.type, size_bytes: f.meta.size,
  }));
  const { error: fErr } = await admin.from('order_files').insert(fileRows.map(({ index: _i, ...row }) => row));
  if (fErr) { await cleanup(); return json({ error: 'We could not save your files.' }, 500); }
  for (const row of fileRows) {
    const { data, error } = await admin.storage.from('order-files').createSignedUploadUrl(row.storage_path);
    if (error || !data) { await cleanup(); return json({ error: 'We could not prepare the upload.' }, 500); }
    uploads.push({ index: row.index, path: row.storage_path, token: data.token });
  }

  await audit({ action: 'orders.draft_created', entityType: 'order', entityId: order.id, pressId: press.id, metadata: { files: fileRows.length } }, { ip, userAgent: (req.headers.get('user-agent') ?? '').slice(0, 300) });
  const totalMinor = lines.reduce((s, l) => s + l.q.totalMinor, 0);
  return json({ orderId: order.id, trackingCode: order.tracking_code, total: totalMinor / 100, uploads });
}
