import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { isSameOrigin, ipFromHeaders, rateLimit } from '@/lib/security/http';
import { MAX_FILE_BYTES, bytesMatchDeclared, validateUploadMeta } from '@/lib/security/upload';
import { audit } from '@/lib/audit';

const json = (body: unknown, status = 200) => NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CODE = /^[0-9a-f]{18}$/;

/** Read the first bytes and the true size of an object without downloading it all. */
async function peek(url: string): Promise<{ size: number; head: Uint8Array } | null> {
  const res = await fetch(url, { headers: { Range: 'bytes=0-15' }, cache: 'no-store' });
  if (!res.ok || !res.body) return null;
  const range = res.headers.get('content-range'); // "bytes 0-15/12345"
  const size = range ? Number(range.split('/')[1]) : Number(res.headers.get('content-length'));
  const reader = res.body.getReader();
  const { value } = await reader.read();
  await reader.cancel().catch(() => {});
  if (!value || !Number.isFinite(size)) return null;
  return { size, head: value.slice(0, 16) };
}

/**
 * Step 3: verify what was actually uploaded (size + magic bytes), then publish the order.
 * Any mismatch deletes the objects and the draft. Idempotent for already-finalized orders.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!isSameOrigin(req)) return json({ error: 'Request blocked.' }, 403);
  const { id } = await params;
  const ip = ipFromHeaders(req.headers);
  if (!(await rateLimit(`finalize:ip:${ip}`, 3600, 30))) return json({ error: 'Too many requests. Please try again later.' }, 429);
  let body: { trackingCode?: string } = {};
  try { body = await req.json(); } catch { /* handled below */ }
  if (!UUID.test(id) || !CODE.test(body.trackingCode ?? '')) return json({ error: 'Invalid request.' }, 400);

  const admin = createAdminClient();
  const { data: order } = await admin.from('orders').select('id, press_id, status, order_number, tracking_code').eq('id', id).eq('tracking_code', body.trackingCode!).maybeSingle();
  if (!order) return json({ error: 'Order not found.' }, 404);
  if (order.status !== 'draft') return json({ orderNumber: order.order_number });

  const { data: files } = await admin.from('order_files').select('id, storage_path, original_name, mime_type, size_bytes').eq('order_id', order.id);
  const abort = async (message: string) => {
    if (files?.length) await admin.storage.from('order-files').remove(files.map((f) => f.storage_path));
    await admin.from('orders').delete().eq('id', order.id);
    return json({ error: message }, 422);
  };
  if (!files?.length) return abort('No files were attached to this order.');

  for (const f of files) {
    const { data: signed } = await admin.storage.from('order-files').createSignedUrl(f.storage_path, 30);
    const info = signed?.signedUrl ? await peek(signed.signedUrl) : null;
    if (!info) return abort(`${f.original_name} did not finish uploading. Please try again.`);
    const check = validateUploadMeta({ name: f.original_name, size: info.size, type: f.mime_type });
    if (!check.ok) return abort(check.error);
    if (info.size > MAX_FILE_BYTES || info.size !== f.size_bytes) return abort(`${f.original_name} does not match what you selected. Please try again.`);
    if (!bytesMatchDeclared(info.head, check.family)) return abort(`${f.original_name} is not a valid ${check.ext.toUpperCase()} file.`);
  }

  await admin.from('order_files').update({ verified: true }).eq('order_id', order.id);
  const { data: done, error } = await admin.from('orders').update({ status: 'submitted' }).eq('id', order.id).eq('status', 'draft').select('order_number').single();
  if (error || !done) return json({ error: 'We could not place your order. Please try again.' }, 500);
  await audit({ action: 'orders.placed', entityType: 'order', entityId: order.id, pressId: order.press_id, metadata: { files: files.length } }, { ip, userAgent: (req.headers.get('user-agent') ?? '').slice(0, 300) });
  return json({ orderNumber: done.order_number });
}
