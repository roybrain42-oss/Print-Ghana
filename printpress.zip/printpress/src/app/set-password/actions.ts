'use server';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { failState, fromZod, type ActionState } from '@/lib/action';
import { passwordSchema } from '@/lib/validation';
import { requireUser } from '@/lib/auth/session';
import { audit } from '@/lib/audit';

export async function setPasswordAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { user, profile } = await requireUser();
  const parsed = z.object({ password: passwordSchema }).safeParse({ password: fd.get('password') });
  if (!parsed.success) return fromZod(parsed.error);
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) return failState('We could not update your password. Try a different one.');
  await audit({ action: 'auth.password_set', entityType: 'auth', actorId: user.id });
  redirect(profile.platform_role === 'super_admin' ? '/admin' : '/dashboard');
}
