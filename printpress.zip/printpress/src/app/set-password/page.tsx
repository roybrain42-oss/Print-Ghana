import { requireUser } from '@/lib/auth/session';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { Logo } from '@/components/logo';
import { setPasswordAction } from './actions';

export const metadata = { title: 'Set your password' };

export default async function SetPasswordPage() {
  await requireUser();
  return (
    <div className="min-h-screen">
      <div className="colorbar h-2" />
      <main id="main" className="mx-auto grid w-[min(440px,100%-2rem)] gap-6 py-12">
        <div className="flex items-center gap-2 font-display text-xl font-extrabold"><Logo /> PrintPress</div>
        <div className="card p-6">
          <h1 className="text-2xl font-extrabold">Set your password</h1>
          <p className="mt-1 text-sm text-ink-soft">Choose a password to finish setting up your account.</p>
          <ActionForm action={setPasswordAction} className="mt-4 grid gap-4" resetOnSuccess={false}>
            <Field name="password" label="New password" hint="At least 10 characters with upper case, lower case and a number.">
              <input id="password" name="password" type="password" autoComplete="new-password" required className="input" />
            </Field>
            <SubmitButton>Save password</SubmitButton>
          </ActionForm>
        </div>
      </main>
    </div>
  );
}
