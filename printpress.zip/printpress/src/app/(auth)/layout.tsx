import Link from 'next/link';
import { Logo } from '@/components/logo';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <div className="colorbar h-2" />
      <main id="main" className="mx-auto grid min-h-[calc(100vh-8px)] w-[min(440px,100%-2rem)] content-center gap-6 py-10">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-extrabold"><Logo /> PrintPress</Link>
        <div className="card p-6">{children}</div>
      </main>
    </div>
  );
}
