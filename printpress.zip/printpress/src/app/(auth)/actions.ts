'use server';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { failState, fromZod, okState, type ActionState } from '@/lib/action';
import { loginSchema, onboardingSchema, registerSchema, RESERVED_SLUGS } from '@/lib/validation';
import { audit } from '@/lib/audit';
import { currentRequestMeta, rateLimit } from '@/lib/security/http';
import { publicEnv } from '@/lib/env';
import { requireUser } from '@/lib/auth/session';
import { createAdminClient } from '@/lib/supabase/admin';
import { getPlatformSettings } from '@/lib/settings';

function safeNext(next: FormDataEntryValue | null): string {
  const n = typeof next === 'string' ? next : '';
  return n.startsWith('/') && !n.startsWith('//') && !n.startsWith('/\\') ? n : '/dashboard';
}

export async function loginAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse({ email: fd.get('email'), password: fd.get('password') });
  if (!parsed.success) return fromZod(parsed.error);
  const { ip, userAgent } = await currentRequestMeta();

  // Slow down credential stuffing: per IP and per account.
  const allowed = (await rateLimit(`login:ip:${ip}`, 900, 20)) && (await rateLimit(`login:acct:${parsed.data.email}`, 900, 8));
  if (!allowed) return failState('Too many attempts. Wait a few minutes and try again.');

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error || !data.user) {
    await audit({ action: 'auth.login_failed', entityType: 'auth', metadata: { email: parsed.data.email } }, { ip, userAgent });
    return failState('Incorrect email or password.'); // same message for unknown email and wrong password
  }
  await audit({ action: 'auth.login', entityType: 'auth', actorId: data.user.id }, { ip, userAgent });
  redirect(safeNext(fd.get('next')));
}

export async function registerAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = registerSchema.safeParse({ fullName: fd.get('fullName'), email: fd.get('email'), password: fd.get('password') });
  if (!parsed.success) return fromZod(parsed.error);
  const { ip, userAgent } = await currentRequestMeta();
  if (!(await getPlatformSettings()).registration_open) return failState('New registrations are closed right now.');
  if (!(await rateLimit(`register:ip:${ip}`, 3600, 10))) return failState('Too many sign-ups from this network. Try again later.');
  if (String(fd.get('company') ?? '') !== '') return okState('Check your email to confirm your account.'); // honeypot

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: { data: { full_name: parsed.data.fullName }, emailRedirectTo: `${publicEnv.appUrl}/auth/callback?next=/onboarding` },
  });
  if (error) return failState('We could not create that account. If you already have one, sign in instead.');
  await audit({ action: 'auth.register', entityType: 'auth', actorId: data.user?.id ?? null }, { ip, userAgent });
  if (data.session) redirect('/onboarding');
  return okState('Check your email to confirm your account, then sign in.');
}

export async function signOutAction() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  await supabase.auth.signOut();
  if (user) await audit({ action: 'auth.logout', entityType: 'auth', actorId: user.id });
  redirect('/login');
}

export async function onboardingAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { user } = await requireUser();
  const parsed = onboardingSchema.safeParse({ name: fd.get('name'), slug: fd.get('slug') });
  if (!parsed.success) return fromZod(parsed.error);
  if (RESERVED_SLUGS.has(parsed.data.slug)) return failState('Please fix the highlighted fields.', { slug: 'That address is reserved. Choose another.' });
  if (!(await rateLimit(`onboarding:user:${user.id}`, 3600, 5))) return failState('Too many attempts. Try again later.');

  const supabase = await createClient();
  const { data, error } = await supabase.rpc('register_press', { p_name: parsed.data.name, p_slug: parsed.data.slug });
  if (error) {
    if (error.code === '23505') return failState('Please fix the highlighted fields.', { slug: 'That address is already taken.' });
    return failState('We could not create your press. Check the details and try again.');
  }
  if (!(await getPlatformSettings()).require_press_approval) {
    await createAdminClient().from('presses').update({ status: 'approved', approved_at: new Date().toISOString() }).eq('id', String(data));
  }
  await audit({ action: 'press.register', entityType: 'press', entityId: String(data), pressId: String(data), actorId: user.id });
  redirect('/dashboard');
}
