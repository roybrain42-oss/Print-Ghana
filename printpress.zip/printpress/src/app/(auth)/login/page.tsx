import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth/session';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { loginAction } from '../actions';

export const metadata = { title: 'Sign in' };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const sp = await searchParams;
  const s = await getCurrentUser();
  if (s) redirect(s.profile.platform_role === 'super_admin' ? '/admin' : '/dashboard');
  return (
    <>
      <h1 className="text-2xl font-extrabold">Sign in</h1>
      {sp.error === 'link' && <p role="alert" className="mt-2 text-sm text-red-700">That confirmation link is invalid or has expired. Sign in or register again.</p>}
      <ActionForm action={loginAction} className="mt-4 grid gap-4" resetOnSuccess={false}>
        <input type="hidden" name="next" value={sp.next ?? ''} />
        <Field name="email" label="Email"><input id="email" name="email" type="email" autoComplete="email" required className="input" /></Field>
        <Field name="password" label="Password"><input id="password" name="password" type="password" autoComplete="current-password" required className="input" /></Field>
        <SubmitButton pendingText="Signing in…">Sign in</SubmitButton>
      </ActionForm>
      <p className="mt-4 text-sm text-ink-soft">New press? <Link className="font-semibold text-brand underline" href="/register">Create an account</Link></p>
    </>
  );
}
