import Link from 'next/link';
import { ActionForm, Field, SubmitButton } from '@/components/ui/action-form';
import { registerAction } from '../actions';

export const metadata = { title: 'Create account' };

export default function RegisterPage() {
  return (
    <>
      <h1 className="text-2xl font-extrabold">Create your account</h1>
      <p className="mt-1 text-sm text-ink-soft">Next you will set up your press. A platform admin reviews new presses before they go live.</p>
      <ActionForm action={registerAction} className="mt-4 grid gap-4">
        <div aria-hidden="true" className="absolute -left-[9999px]"><label>Company<input name="company" tabIndex={-1} autoComplete="off" /></label></div>
        <Field name="fullName" label="Your name"><input id="fullName" name="fullName" autoComplete="name" required className="input" /></Field>
        <Field name="email" label="Email"><input id="email" name="email" type="email" autoComplete="email" required className="input" /></Field>
        <Field name="password" label="Password" hint="At least 10 characters with upper case, lower case and a number."><input id="password" name="password" type="password" autoComplete="new-password" required className="input" /></Field>
        <SubmitButton pendingText="Creating account…">Create account</SubmitButton>
      </ActionForm>
      <p className="mt-4 text-sm text-ink-soft">Already registered? <Link className="font-semibold text-brand underline" href="/login">Sign in</Link></p>
    </>
  );
}
