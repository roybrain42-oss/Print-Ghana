import Link from 'next/link';
import { Logo } from '@/components/logo';

export default function Home() {
  return (
    <>
      <div className="colorbar h-2" />
      <header className="mx-auto flex w-[min(1120px,100%-2rem)] items-center justify-between py-4">
        <span className="flex items-center gap-2 font-display text-xl font-extrabold"><Logo /> PrintPress</span>
        <nav className="flex gap-2"><Link href="/login" className="btn btn-ghost btn-sm">Sign in</Link><Link href="/register" className="btn btn-primary btn-sm">Register your press</Link></nav>
      </header>
      <main id="main" className="mx-auto w-[min(1120px,100%-2rem)] py-16">
        <h1 className="max-w-3xl font-display text-5xl font-extrabold leading-[1.02] sm:text-7xl" style={{ textShadow: '-3px 2px 0 #00A3E0, 3px -2px 0 #E6007E' }}>Orders in. Files safe. Paid and printed.</h1>
        <p className="mt-6 max-w-xl text-lg text-ink-soft">Give every customer a page and a QR code for your press. They upload files and see the price before they order. You manage orders, payments and staff in one place.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/register" className="btn btn-primary">Register your press</Link><Link href="/login" className="btn btn-ghost">Sign in</Link></div>
        <ul className="mt-16 grid gap-4 sm:grid-cols-3">
          {[['A page for every press', 'Your name, logo, hours, services and prices, with a QR code that opens your order form.'],
            ['Files stay private', 'Customer documents are stored privately and only your staff can open them.'],
            ['Know what you earned', 'Record payments, follow revenue by day and see which services sell.']].map(([t, b]) => (
            <li key={t} className="card"><h2 className="text-lg font-bold">{t}</h2><p className="mt-1 text-sm text-ink-soft">{b}</p></li>
          ))}
        </ul>
      </main>
    </>
  );
}
