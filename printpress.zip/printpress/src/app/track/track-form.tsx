'use client';
import { useState } from 'react';
import { OrderBadge, PayBadge } from '@/components/ui/bits';
import { formatMoney } from '@/lib/pricing/engine';
import type { OrderStatus, PaymentStatus } from '@/lib/types';

type Result = { orderNumber: string; status: OrderStatus; paymentStatus: PaymentStatus; total: number; amountPaid: number; press: string; currency: string; placedAt: string };
const MESSAGE: Record<string, string> = { submitted: 'The press has your order and will confirm it shortly.', confirmed: 'Your order is confirmed and queued.', printing: 'Your order is being printed.', ready: 'Your order is ready to collect.', completed: 'This order is complete.', cancelled: 'This order was cancelled. Contact the press for details.' };

export function TrackForm({ initialCode }: { initialCode: string }) {
  const [code, setCode] = useState(initialCode); const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [res, setRes] = useState<Result | null>(null);
  async function submit() {
    setBusy(true); setError(''); setRes(null);
    try {
      const r = await fetch('/api/public/track', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, phone }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setError(j.error ?? 'Something went wrong. Please try again.'); else setRes(j);
    } catch { setError('Could not reach the server. Check your connection.'); }
    setBusy(false);
  }
  return (
    <div className="mt-6 grid gap-4">
      <div className="card grid gap-4">
        <div><label htmlFor="code" className="label">Tracking code</label><input id="code" className="input" value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off" spellCheck={false} maxLength={18} /></div>
        <div><label htmlFor="phone" className="label">Phone number</label><input id="phone" type="tel" inputMode="tel" className="input" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={20} /></div>
        <button type="button" className="btn btn-primary" disabled={busy || !code || !phone} onClick={submit}>{busy ? 'Looking…' : 'Find my order'}</button>
      </div>
      {error && <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      {res && (
        <div className="card border-2 border-ink" role="status">
          <p className="text-sm text-ink-soft">{res.press}</p>
          <h2 className="text-2xl font-extrabold">{res.orderNumber}</h2>
          <div className="my-3 flex gap-2"><OrderBadge status={res.status} /><PayBadge status={res.paymentStatus} /></div>
          <p>{MESSAGE[res.status]}</p>
          <p className="mt-3 text-sm tabular-nums">Total {formatMoney(Math.round(Number(res.total) * 100), res.currency)} · Paid {formatMoney(Math.round(Number(res.amountPaid) * 100), res.currency)}</p>
        </div>)}
    </div>
  );
}
