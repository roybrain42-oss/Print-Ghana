import { TrackForm } from './track-form';
export const metadata = { title: 'Track an order' };
export default async function TrackPage({ searchParams }: { searchParams: Promise<{ code?: string }> }) {
  const sp = await searchParams;
  return (
    <>
      <div className="colorbar h-2" />
      <main id="main" className="mx-auto w-[min(520px,100%-2rem)] py-10">
        <h1 className="text-3xl font-extrabold">Track your order</h1>
        <p className="mt-1 text-sm text-ink-soft">Enter the tracking code from your confirmation and the phone number you used.</p>
        <TrackForm initialCode={/^[0-9a-f]{18}$/i.test(sp.code ?? '') ? sp.code! : ''} />
      </main>
    </>
  );
}
