'use client';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const fmt = (n: number) => new Intl.NumberFormat('en-GH', { maximumFractionDigits: 0 }).format(n);

export function RevenueChart({ data }: { data: { day: string; revenue: number }[] }) {
  return (
    <div className="h-64 w-full" role="img" aria-label="Revenue per day">
      <ResponsiveContainer>
        <AreaChart data={data} margin={{ left: 0, right: 8, top: 8 }}>
          <defs><linearGradient id="rev" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0B5FD8" stopOpacity={0.35} /><stop offset="100%" stopColor="#0B5FD8" stopOpacity={0} /></linearGradient></defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#D5DCE4" />
          <XAxis dataKey="day" tickFormatter={(d) => String(d).slice(5)} fontSize={12} />
          <YAxis tickFormatter={fmt} fontSize={12} width={48} />
          <Tooltip formatter={(v: number) => [`GH₵${v.toFixed(2)}`, 'Revenue']} />
          <Area type="monotone" dataKey="revenue" stroke="#0B5FD8" strokeWidth={2} fill="url(#rev)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function BarsChart({ data, xKey, yKey, label, color = '#E6007E' }: {
  data: Record<string, string | number>[]; xKey: string; yKey: string; label: string; color?: string;
}) {
  return (
    <div className="h-64 w-full" role="img" aria-label={label}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ left: 0, right: 8, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#D5DCE4" />
          <XAxis dataKey={xKey} fontSize={12} interval={0} tickFormatter={(v) => String(v).slice(0, 10)} />
          <YAxis tickFormatter={fmt} fontSize={12} width={48} />
          <Tooltip />
          <Bar dataKey={yKey} fill={color} radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
