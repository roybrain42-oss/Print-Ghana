export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" role="img" aria-label="PrintPress logo">
      <circle cx="15" cy="16" r="10" fill="#00A3E0" style={{ mixBlendMode: 'multiply' }} />
      <circle cx="25" cy="16" r="10" fill="#E6007E" style={{ mixBlendMode: 'multiply' }} />
      <circle cx="20" cy="25" r="10" fill="#FFD500" style={{ mixBlendMode: 'multiply' }} />
    </svg>
  );
}
