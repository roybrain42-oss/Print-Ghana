'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { BarChart3, ClipboardList, CreditCard, LayoutDashboard, LogOut, Menu, Printer, ScrollText, Settings, Shield, Store, Tags, Users, X, Building2, UserCog } from 'lucide-react';
import { Logo } from './logo';
import { cn } from '@/lib/utils';

const ICONS = { overview: LayoutDashboard, orders: ClipboardList, payments: CreditCard, services: Tags, analytics: BarChart3, staff: Users, settings: Settings, presses: Building2, users: UserCog, logs: ScrollText, shield: Shield, store: Store, printer: Printer } as const;
export type NavItem = { href: string; label: string; icon: keyof typeof ICONS; exact?: boolean };

export function Shell({ nav, title, subtitle, userName, signOut, children }: {
  nav: NavItem[]; title: string; subtitle?: string; userName: string; signOut: () => Promise<void>; children: React.ReactNode;
}) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const Nav = (
    <nav aria-label="Main" className="grid gap-1">
      {nav.map((n) => {
        const Icon = ICONS[n.icon];
        const active = n.exact ? path === n.href : path === n.href || path.startsWith(n.href + '/');
        return (
          <Link key={n.href} href={n.href} onClick={() => setOpen(false)} aria-current={active ? 'page' : undefined}
            className={cn('flex min-h-[44px] items-center gap-3 rounded-lg px-3 text-sm font-semibold', active ? 'bg-ink text-white' : 'text-ink hover:bg-paper')}>
            <Icon size={18} aria-hidden /> {n.label}
          </Link>
        );
      })}
    </nav>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="hidden border-r border-line bg-white lg:block print:hidden">
        <div className="colorbar h-2" />
        <div className="sticky top-0 p-4">
          <div className="mb-6 flex items-center gap-2"><Logo /><div><p className="font-display text-base font-extrabold leading-tight">{title}</p>{subtitle && <p className="text-xs text-ink-soft">{subtitle}</p>}</div></div>
          {Nav}
        </div>
      </aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex print:hidden items-center justify-between border-b border-line bg-white/95 px-4 py-2 backdrop-blur">
          <button type="button" className="rounded p-2 lg:hidden" aria-label="Open menu" aria-expanded={open} onClick={() => setOpen(true)}><Menu /></button>
          <span className="hidden text-sm text-ink-soft lg:block">{subtitle}</span>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm font-semibold sm:block">{userName}</span>
            <form action={signOut}><button className="btn btn-ghost btn-sm" type="submit"><LogOut size={14} aria-hidden /> Sign out</button></form>
          </div>
        </header>
        {open && (
          <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
            <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} />
            <div className="absolute inset-y-0 left-0 w-72 bg-white p-4">
              <div className="mb-4 flex items-center justify-between"><span className="font-display font-extrabold">{title}</span><button type="button" aria-label="Close menu" onClick={() => setOpen(false)}><X /></button></div>
              {Nav}
            </div>
          </div>
        )}
        <main id="main" className="mx-auto w-full max-w-6xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
