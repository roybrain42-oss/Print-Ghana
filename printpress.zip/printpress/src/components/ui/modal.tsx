'use client';
import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';

const ModalCtx = createContext<{ close: () => void } | null>(null);
export const useModal = () => useContext(ModalCtx);

/** Accessible modal built on <dialog>: focus trap, Escape to close, click backdrop to close. */
export function Modal({ trigger, title, children, className = 'btn btn-primary btn-sm', description }: {
  trigger: React.ReactNode; title: string; children: React.ReactNode; className?: string; description?: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    <ModalCtx.Provider value={{ close: () => setOpen(false) }}>
      <button type="button" className={className} onClick={() => setOpen(true)}>{trigger}</button>
      <dialog
        ref={ref}
        aria-labelledby="modal-title"
        onClose={() => setOpen(false)}
        onClick={(e) => { if (e.target === ref.current) setOpen(false); }}
        className="w-[min(560px,calc(100%-2rem))] rounded-2xl border-2 border-ink p-0 backdrop:bg-ink/50"
      >
        <div className="colorbar h-2" />
        <div className="p-5">
          <div className="mb-4 flex items-start justify-between gap-4">
            <div>
              <h2 id="modal-title" className="text-xl font-extrabold">{title}</h2>
              {description && <p className="mt-1 text-sm text-ink-soft">{description}</p>}
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="rounded p-1 hover:bg-paper"><X size={20} /></button>
          </div>
          {open && children}
        </div>
      </dialog>
    </ModalCtx.Provider>
  );
}
