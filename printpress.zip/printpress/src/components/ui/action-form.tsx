'use client';
import { createContext, useActionState, useContext, useEffect, useRef } from 'react';
import { useFormStatus } from 'react-dom';
import type { ActionState } from '@/lib/action';
import { useToast } from './toast';
import { useModal } from './modal';

const ErrCtx = createContext<Record<string, string>>({});

export function FieldError({ name }: { name: string }) {
  const errs = useContext(ErrCtx);
  return errs[name] ? <p className="field-error" role="alert" id={`err-${name}`}>{errs[name]}</p> : null;
}

export function SubmitButton({ children, className = 'btn btn-primary', pendingText = 'Saving…' }: {
  children: React.ReactNode; className?: string; pendingText?: string;
}) {
  const { pending } = useFormStatus();
  return <button type="submit" className={className} disabled={pending} aria-busy={pending}>{pending ? pendingText : children}</button>;
}

/** Wraps a server action: toasts the result, shows field errors, closes the parent modal on success. */
export function ActionForm({ action, children, className, resetOnSuccess = true }: {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  children: React.ReactNode; className?: string; resetOnSuccess?: boolean;
}) {
  const [state, formAction] = useActionState(action, null);
  const toast = useToast();
  const modal = useModal();
  const ref = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (!state) return;
    toast(state.message, state.ok ? 'success' : 'error');
    if (state.ok) {
      if (resetOnSuccess) ref.current?.reset();
      modal?.close();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <ErrCtx.Provider value={state?.fieldErrors ?? {}}>
      <form ref={ref} action={formAction} className={className ?? 'grid gap-4'} noValidate>
        {children}
        {state && !state.ok && !state.fieldErrors && <p role="alert" className="field-error">{state.message}</p>}
      </form>
    </ErrCtx.Provider>
  );
}

export function Field({ name, label, hint, children }: { name: string; label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={name} className="label">{label}</label>
      {children}
      {hint && <p className="hint">{hint}</p>}
      <FieldError name={name} />
    </div>
  );
}
