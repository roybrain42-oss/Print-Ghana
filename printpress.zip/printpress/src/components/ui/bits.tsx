import Link from 'next/link';
import type { OrderStatus, PaymentStatus, PressStatus } from '@/lib/types';
import { cn } from '@/lib/utils';

const ORDER: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-700', submitted: 'bg-sky-100 text-sky-800', confirmed: 'bg-indigo-100 text-indigo-800',
  printing: 'bg-amber-100 text-amber-900', ready: 'bg-emerald-100 text-emerald-800',
  completed: 'bg-slate-200 text-slate-800', cancelled: 'bg-red-100 text-red-800',
};
const PAY: Record<string, string> = { unpaid: 'bg-red-100 text-red-800', partial: 'bg-amber-100 text-amber-900', paid: 'bg-emerald-100 text-emerald-800' };
const PRESS: Record<string, string> = { pending: 'bg-amber-100 text-amber-900', approved: 'bg-emerald-100 text-emerald-800', suspended: 'bg-red-100 text-red-800' };

export const OrderBadge = ({ status }: { status: OrderStatus }) => <span className={cn('badge capitalize', ORDER[status])}>{status}</span>;
export const PayBadge = ({ status }: { status: PaymentStatus }) => <span className={cn('badge capitalize', PAY[status])}>{status}</span>;
export const PressBadge = ({ status }: { status: PressStatus }) => <span className={cn('badge capitalize', PRESS[status])}>{status}</span>;

export function StatCard({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="card">
      <p className="text-sm text-ink-soft">{label}</p>
      <p className="mt-1 font-display text-3xl font-extrabold">{value}</p>
      {sub && <p className="mt-1 text-xs text-ink-soft">{sub}</p>}
    </div>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <div className="rounded-xl border-2 border-dashed border-line bg-white px-6 py-12 text-center">
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mx-auto mt-1 max-w-sm text-sm text-ink-soft">{body}</p>
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

export function PageHeader({ title, sub, actions }: { title: string; sub?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-3xl font-extrabold">{title}</h1>
        {sub && <p className="mt-1 text-sm text-ink-soft">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Pagination({ page, pages, basePath, params }: { page: number; pages: number; basePath: string; params: Record<string, string | undefined> }) {
  if (pages <= 1) return null;
  const href = (p: number) => {
    const sp = new URLSearchParams();
    Object.entries({ ...params, page: String(p) }).forEach(([k, v]) => v && sp.set(k, v));
    return `${basePath}?${sp.toString()}`;
  };
  return (
    <nav aria-label="Pagination" className="mt-4 flex items-center justify-between text-sm">
      <span className="text-ink-soft">Page {page} of {pages}</span>
      <div className="flex gap-2">
        {page > 1 && <Link className="btn btn-ghost btn-sm" href={href(page - 1)}>Previous</Link>}
        {page < pages && <Link className="btn btn-ghost btn-sm" href={href(page + 1)}>Next</Link>}
      </div>
    </nav>
  );
}

/** GET form: filters live in the URL so results are shareable and server-rendered. */
export function FilterBar({ action, q, children }: { action: string; q?: string; children?: React.ReactNode }) {
  return (
    <form action={action} method="get" className="mb-4 flex flex-wrap items-end gap-3" role="search">
      <div className="min-w-[200px] flex-1">
        <label htmlFor="q" className="label">Search</label>
        <input id="q" name="q" defaultValue={q} className="input" placeholder="Search…" maxLength={60} />
      </div>
      {children}
      <button className="btn btn-ghost" type="submit">Apply</button>
    </form>
  );
}
