-- =====================================================================
-- 002: rate limiting, analytics, platform stats, maintenance
-- =====================================================================

-- ---------------------------------------------------------------------
-- Rate limiting in Postgres (works on serverless, no extra infra).
-- Fixed-window counters keyed by e.g. "order:ip:1.2.3.4".
-- Only the service role may call it; RLS on with no policies.
-- ---------------------------------------------------------------------
create table public.rate_limits (
  key          text not null,
  window_start timestamptz not null,
  hits         int not null default 0,
  primary key (key, window_start)
);
alter table public.rate_limits enable row level security;
revoke all on public.rate_limits from anon, authenticated;

-- Returns true when the call is ALLOWED, false when over the limit.
create or replace function public.rate_limit_hit(p_key text, p_window_seconds int, p_max int)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_window timestamptz; v_hits int;
begin
  if p_window_seconds < 1 or p_max < 1 then
    raise exception 'invalid rate limit parameters';
  end if;
  v_window := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds);
  insert into public.rate_limits as r (key, window_start, hits)
  values (left(p_key, 200), v_window, 1)
  on conflict (key, window_start) do update set hits = r.hits + 1
  returning hits into v_hits;
  return v_hits <= p_max;
end $$;
revoke all on function public.rate_limit_hit(text, int, int) from public, anon, authenticated;
grant execute on function public.rate_limit_hit(text, int, int) to service_role;

-- ---------------------------------------------------------------------
-- Maintenance: schedule with pg_cron or Supabase Scheduled Functions.
--   select cron.schedule('printpress-maintenance', '15 * * * *', 'select public.run_maintenance()');
-- Storage objects of purged drafts are removed by the app's cleanup job
-- (see README); this only removes database rows.
-- ---------------------------------------------------------------------
create or replace function public.run_maintenance()
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from public.rate_limits where window_start < now() - interval '2 days';
  delete from public.orders where status = 'draft' and created_at < now() - interval '24 hours';
end $$;
revoke all on function public.run_maintenance() from public, anon, authenticated;
grant execute on function public.run_maintenance() to service_role;

-- ---------------------------------------------------------------------
-- Press analytics (SECURITY INVOKER: RLS decides what the caller can see,
-- so a member only ever aggregates their own press's rows).
-- ---------------------------------------------------------------------
create or replace function public.press_revenue_daily(p_press uuid, p_days int default 30)
returns table (day date, revenue numeric, payments bigint)
language sql stable security invoker set search_path = public as $$
  select d::date as day,
         coalesce(sum(p.amount), 0)::numeric(12,2) as revenue,
         count(p.id) as payments
  from generate_series(current_date - (least(greatest(p_days, 1), 365) - 1), current_date, interval '1 day') d
  left join public.payments p
    on p.press_id = p_press and p.voided_at is null and p.paid_at::date = d::date
  group by d
  order by d;
$$;

create or replace function public.press_revenue_by_method(p_press uuid, p_days int default 30)
returns table (method public.payment_method, revenue numeric, payments bigint)
language sql stable security invoker set search_path = public as $$
  select p.method, sum(p.amount)::numeric(12,2), count(*)
  from public.payments p
  where p.press_id = p_press and p.voided_at is null
    and p.paid_at >= now() - make_interval(days => least(greatest(p_days, 1), 365))
  group by p.method
  order by 2 desc;
$$;

create or replace function public.press_top_services(p_press uuid, p_days int default 30)
returns table (service text, quantity bigint, revenue numeric)
language sql stable security invoker set search_path = public as $$
  select coalesce(s.name, 'Other') as service,
         sum(i.quantity)::bigint,
         sum(i.line_total)::numeric(12,2)
  from public.order_items i
  join public.orders o on o.id = i.order_id
  left join public.services s on s.id = i.service_id
  where i.press_id = p_press and o.status not in ('draft', 'cancelled')
    and o.created_at >= now() - make_interval(days => least(greatest(p_days, 1), 365))
  group by 1
  order by 3 desc
  limit 8;
$$;

create or replace function public.press_order_status_counts(p_press uuid)
returns table (status public.order_status, orders bigint)
language sql stable security invoker set search_path = public as $$
  select o.status, count(*) from public.orders o
  where o.press_id = p_press and o.status <> 'draft'
  group by o.status;
$$;

-- ---------------------------------------------------------------------
-- Platform-wide stats: SECURITY DEFINER but hard-gated to super admins.
-- ---------------------------------------------------------------------
create or replace function public.platform_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare result jsonb;
begin
  if not public.is_super_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'presses_total',     (select count(*) from public.presses),
    'presses_pending',   (select count(*) from public.presses where status = 'pending'),
    'presses_approved',  (select count(*) from public.presses where status = 'approved'),
    'presses_suspended', (select count(*) from public.presses where status = 'suspended'),
    'users_total',       (select count(*) from public.profiles),
    'orders_total',      (select count(*) from public.orders where status <> 'draft'),
    'orders_30d',        (select count(*) from public.orders where status <> 'draft' and created_at >= now() - interval '30 days'),
    'revenue_total',     (select coalesce(sum(amount), 0) from public.payments where voided_at is null),
    'revenue_30d',       (select coalesce(sum(amount), 0) from public.payments where voided_at is null and paid_at >= now() - interval '30 days')
  ) into result;
  return result;
end $$;
revoke all on function public.platform_stats() from public, anon;
grant execute on function public.platform_stats() to authenticated;

create or replace function public.platform_daily(p_days int default 30)
returns table (day date, orders bigint, revenue numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_super_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  return query
  select d::date,
         (select count(*) from public.orders o where o.status <> 'draft' and o.created_at::date = d::date),
         (select coalesce(sum(p.amount), 0)::numeric(12,2) from public.payments p where p.voided_at is null and p.paid_at::date = d::date)
  from generate_series(current_date - (least(greatest(p_days, 1), 365) - 1), current_date, interval '1 day') d
  order by 1;
end $$;
revoke all on function public.platform_daily(int) from public, anon;
grant execute on function public.platform_daily(int) to authenticated;

-- Per-press rollup for the admin presses table.
create or replace function public.platform_press_rollup()
returns table (press_id uuid, orders bigint, revenue numeric, staff bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_super_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  return query
  select p.id,
         (select count(*) from public.orders o where o.press_id = p.id and o.status <> 'draft'),
         (select coalesce(sum(pay.amount), 0)::numeric(12,2) from public.payments pay where pay.press_id = p.id and pay.voided_at is null),
         (select count(*) from public.press_members m where m.press_id = p.id and m.is_active)
  from public.presses p;
end $$;
revoke all on function public.platform_press_rollup() from public, anon;
grant execute on function public.platform_press_rollup() to authenticated;

-- Analytics RPCs are only for signed-in users.
revoke execute on function public.press_revenue_daily(uuid, int)     from public, anon;
revoke execute on function public.press_revenue_by_method(uuid, int) from public, anon;
revoke execute on function public.press_top_services(uuid, int)      from public, anon;
revoke execute on function public.press_order_status_counts(uuid)    from public, anon;
grant  execute on function public.press_revenue_daily(uuid, int)     to authenticated;
grant  execute on function public.press_revenue_by_method(uuid, int) to authenticated;
grant  execute on function public.press_top_services(uuid, int)      to authenticated;
grant  execute on function public.press_order_status_counts(uuid)    to authenticated;
