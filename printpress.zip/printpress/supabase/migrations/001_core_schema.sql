-- =====================================================================
-- PrintPress: core multi-tenant schema
-- Tenancy model: every tenant-owned row carries press_id. Row Level
-- Security (RLS) enforces isolation in the database itself, so a bug in
-- app code cannot leak one press's data to another.
--
-- Trust model:
--   * Browser/user sessions (anon + authenticated roles) are RLS-bound.
--   * Public customer ordering goes through Next.js route handlers that
--     validate input, rate-limit, and write with the service role.
--     Anonymous users have NO direct table access.
--   * Customer files live in a PRIVATE bucket; downloads use short-lived
--     signed URLs issued server-side after an authorization check.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------
create type public.platform_role  as enum ('user', 'super_admin');
create type public.press_status   as enum ('pending', 'approved', 'suspended');
create type public.member_role    as enum ('owner', 'manager', 'staff');
create type public.order_status   as enum ('draft', 'submitted', 'confirmed', 'printing', 'ready', 'completed', 'cancelled');
create type public.payment_status as enum ('unpaid', 'partial', 'paid');
create type public.payment_method as enum ('cash', 'mobile_money', 'card', 'bank_transfer', 'other');
create type public.color_mode     as enum ('bw', 'color');
create type public.print_sides    as enum ('single', 'double');

-- ---------------------------------------------------------------------
-- Utility triggers
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Profiles (1:1 with auth.users)
-- ---------------------------------------------------------------------
create table public.profiles (
  id            uuid primary key references auth.users (id) on delete cascade,
  full_name     text not null default '',
  email         text,
  phone         text,
  platform_role public.platform_role not null default 'user',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger trg_profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- platform_role is NEVER read from user-controlled signup metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(left(new.raw_user_meta_data ->> 'full_name', 120), ''), lower(new.email))
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Users may edit their own profile, but never escalate their role/status.
create or replace function public.guard_profile_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_super_admin() then
    if new.platform_role is distinct from old.platform_role
       or new.is_active is distinct from old.is_active then
      raise exception 'not allowed to change role or active state' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Plans (structure ready for later subscription work)
-- ---------------------------------------------------------------------
create table public.plans (
  id            uuid primary key default gen_random_uuid(),
  code          text not null unique,
  name          text not null,
  monthly_price numeric(12,2) not null default 0 check (monthly_price >= 0),
  limits        jsonb not null default '{}'::jsonb,   -- e.g. {"staff": 5, "orders_per_month": 500}
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Presses (tenants)
-- ---------------------------------------------------------------------
create table public.presses (
  id               uuid primary key default gen_random_uuid(),
  slug             text not null unique
                   check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) between 3 and 60),
  name             text not null check (char_length(name) between 2 and 120),
  description      text check (char_length(description) <= 2000),
  logo_path        text,
  brand_color      text not null default '#0F62FE' check (brand_color ~ '^#[0-9A-Fa-f]{6}$'),
  email            text,
  phone            text,
  whatsapp         text,
  address          text,
  city             text,
  region           text,
  country          char(2) not null default 'GH',
  latitude         numeric(9,6),
  longitude        numeric(9,6),
  -- {"mon": {"open":"08:00","close":"18:00"}, "sun": null, ...}
  opening_hours    jsonb not null default '{}'::jsonb,
  currency         char(3) not null default 'GHS',
  timezone         text not null default 'Africa/Accra',
  status           public.press_status not null default 'pending',
  plan_id          uuid references public.plans (id),
  approved_at      timestamptz,
  approved_by      uuid references public.profiles (id),
  suspended_reason text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index idx_presses_status on public.presses (status);
create trigger trg_presses_updated before update on public.presses
  for each row execute function public.set_updated_at();

-- Press staff cannot approve themselves or change plan/status fields.
create or replace function public.guard_press_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_super_admin() then
    if new.status is distinct from old.status
       or new.plan_id is distinct from old.plan_id
       or new.approved_at is distinct from old.approved_at
       or new.approved_by is distinct from old.approved_by
       or new.suspended_reason is distinct from old.suspended_reason
       or new.slug is distinct from old.slug then
      raise exception 'only platform admins can change status, plan or slug' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
create trigger trg_presses_guard before update on public.presses
  for each row execute function public.guard_press_update();

-- ---------------------------------------------------------------------
-- Membership (who works at which press)
-- ---------------------------------------------------------------------
create table public.press_members (
  id         uuid primary key default gen_random_uuid(),
  press_id   uuid not null references public.presses (id) on delete cascade,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  role       public.member_role not null default 'staff',
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  unique (press_id, user_id)
);
create index idx_press_members_user on public.press_members (user_id);

-- ---------------------------------------------------------------------
-- Authorization helpers (SECURITY DEFINER so policies never recurse)
-- ---------------------------------------------------------------------
create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.platform_role = 'super_admin' and p.is_active
  );
$$;

-- Suspended presses lose all tenant access; pending presses may set up.
create or replace function public.has_press_role(p_press uuid, p_roles public.member_role[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.press_members m
    join public.presses pr on pr.id = m.press_id
    join public.profiles pf on pf.id = m.user_id
    where m.press_id = p_press
      and m.user_id = auth.uid()
      and m.is_active
      and pf.is_active
      and m.role = any (p_roles)
      and pr.status <> 'suspended'
  );
$$;

create or replace function public.is_press_member(p_press uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_press_role(p_press, array['owner','manager','staff']::public.member_role[]);
$$;

create or replace function public.shares_press_with(p_user uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.press_members me
    join public.press_members them on them.press_id = me.press_id
    where me.user_id = auth.uid() and me.is_active and them.user_id = p_user
  );
$$;

create trigger trg_profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- ---------------------------------------------------------------------
-- Services & pricing
-- ---------------------------------------------------------------------
create table public.services (
  id          uuid primary key default gen_random_uuid(),
  press_id    uuid not null references public.presses (id) on delete cascade,
  name        text not null check (char_length(name) between 2 and 120),
  description text check (char_length(description) <= 1000),
  category    text not null default 'printing',
  sort_order  int  not null default 0,
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index idx_services_press on public.services (press_id);
create trigger trg_services_updated before update on public.services
  for each row execute function public.set_updated_at();

create table public.price_rules (
  id          uuid primary key default gen_random_uuid(),
  press_id    uuid not null references public.presses (id) on delete cascade,
  service_id  uuid not null references public.services (id) on delete cascade,
  label       text not null,                       -- e.g. "A4 colour, double-sided"
  paper_size  text not null default 'A4',
  color_mode  public.color_mode not null default 'bw',
  sides       public.print_sides not null default 'single',
  unit        text not null default 'per_page' check (unit in ('per_page','per_copy','per_item','per_sqm')),
  unit_price  numeric(12,2) not null check (unit_price >= 0),
  -- [{"min_qty": 100, "percent_off": 10}, {"min_qty": 500, "percent_off": 20}]
  bulk_tiers  jsonb not null default '[]'::jsonb,
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index idx_price_rules_press   on public.price_rules (press_id);
create index idx_price_rules_service on public.price_rules (service_id);
create trigger trg_price_rules_updated before update on public.price_rules
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- Orders
-- ---------------------------------------------------------------------
create table public.press_counters (
  press_id          uuid primary key references public.presses (id) on delete cascade,
  last_order_number bigint not null default 0
);

create table public.orders (
  id             uuid primary key default gen_random_uuid(),
  press_id       uuid not null references public.presses (id) on delete cascade,
  order_number   text,                       -- assigned when the draft is finalized
  -- Customer tracking: code + phone. Rate-limit lookups in the API layer.
  tracking_code  text not null unique default encode(gen_random_bytes(9), 'hex'),
  customer_name  text not null check (char_length(customer_name) between 2 and 120),
  customer_phone text not null check (char_length(customer_phone) between 7 and 20),
  customer_email text,
  notes          text check (char_length(notes) <= 2000),
  status         public.order_status not null default 'draft',
  subtotal       numeric(12,2) not null default 0 check (subtotal >= 0),
  discount       numeric(12,2) not null default 0 check (discount >= 0),
  total          numeric(12,2) not null default 0 check (total >= 0),
  amount_paid    numeric(12,2) not null default 0 check (amount_paid >= 0),
  payment_status public.payment_status not null default 'unpaid',
  assigned_to    uuid references public.profiles (id),
  due_at         timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (press_id, order_number)
);
create index idx_orders_press_created on public.orders (press_id, created_at desc);
create index idx_orders_press_status  on public.orders (press_id, status);
create index idx_orders_phone         on public.orders (press_id, customer_phone);
create trigger trg_orders_updated before update on public.orders
  for each row execute function public.set_updated_at();

create or replace function public.assign_order_number()
returns trigger language plpgsql security definer set search_path = public as $$
declare n bigint;
begin
  if new.order_number is not null or new.status = 'draft' then
    return new;
  end if;
  insert into public.press_counters (press_id, last_order_number)
  values (new.press_id, 1)
  on conflict (press_id) do update
    set last_order_number = public.press_counters.last_order_number + 1
  returning last_order_number into n;
  new.order_number := 'ORD-' || lpad(n::text, 5, '0');
  return new;
end $$;
create trigger trg_orders_number before insert or update of status on public.orders
  for each row execute function public.assign_order_number();

-- Tenant can never be changed after creation.
create or replace function public.forbid_press_change()
returns trigger language plpgsql as $$
begin
  if new.press_id is distinct from old.press_id then
    raise exception 'press_id is immutable' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_orders_press_immutable before update on public.orders
  for each row execute function public.forbid_press_change();

create table public.order_items (
  id          uuid primary key default gen_random_uuid(),
  press_id    uuid not null references public.presses (id) on delete cascade,
  order_id    uuid not null references public.orders (id) on delete cascade,
  service_id  uuid references public.services (id) on delete set null,
  price_rule_id uuid references public.price_rules (id) on delete set null,
  description text not null,                       -- snapshot: prices change, orders must not
  quantity    int  not null check (quantity > 0),  -- pages x copies, computed server-side
  unit_price  numeric(12,2) not null check (unit_price >= 0),
  line_total  numeric(12,2) not null check (line_total >= 0),
  created_at  timestamptz not null default now()
);
create index idx_order_items_order on public.order_items (order_id);
create index idx_order_items_press on public.order_items (press_id);

create table public.order_files (
  id            uuid primary key default gen_random_uuid(),
  press_id      uuid not null references public.presses (id) on delete cascade,
  order_id      uuid not null references public.orders (id) on delete cascade,
  storage_path  text not null unique,              -- {press_id}/{order_id}/{uuid}.{ext}
  original_name text not null,
  mime_type     text not null,
  size_bytes    bigint not null check (size_bytes > 0 and size_bytes <= 52428800),
  page_count    int,
  sha256        text,
  verified      boolean not null default false,   -- set by the server after magic-byte + size check
  created_at    timestamptz not null default now()
);
create index idx_order_files_order on public.order_files (order_id);
create index idx_order_files_press on public.order_files (press_id);

-- ---------------------------------------------------------------------
-- Payments (append-mostly ledger; corrections are voids, not deletes)
-- ---------------------------------------------------------------------
create table public.payments (
  id          uuid primary key default gen_random_uuid(),
  press_id    uuid not null references public.presses (id) on delete cascade,
  order_id    uuid not null references public.orders (id) on delete cascade,
  amount      numeric(12,2) not null check (amount > 0),
  method      public.payment_method not null default 'cash',
  reference   text,                                -- MoMo txn id, Paystack ref later, etc.
  provider    text not null default 'manual',      -- 'manual' now; 'paystack' later
  recorded_by uuid references public.profiles (id),
  paid_at     timestamptz not null default now(),
  voided_at   timestamptz,
  void_reason text,
  created_at  timestamptz not null default now()
);
create index idx_payments_press_paid on public.payments (press_id, paid_at desc);
create index idx_payments_order      on public.payments (order_id);

-- Keep order totals and payment status consistent, always, in the DB.
create or replace function public.refresh_order_financials(p_order uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_sub numeric(12,2); v_paid numeric(12,2); v_disc numeric(12,2); v_total numeric(12,2);
begin
  select coalesce(sum(line_total), 0) into v_sub  from public.order_items where order_id = p_order;
  select coalesce(sum(amount), 0)     into v_paid from public.payments    where order_id = p_order and voided_at is null;
  select discount into v_disc from public.orders where id = p_order;
  v_total := greatest(v_sub - coalesce(v_disc, 0), 0);
  update public.orders
     set subtotal = v_sub,
         total = v_total,
         amount_paid = v_paid,
         payment_status = case
           when v_paid <= 0       then 'unpaid'::public.payment_status
           when v_paid < v_total  then 'partial'::public.payment_status
           else 'paid'::public.payment_status end
   where id = p_order;
end $$;

create or replace function public.trg_refresh_order_financials()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.refresh_order_financials(case when tg_op = 'DELETE' then old.order_id else new.order_id end);
  return null;
end $$;

create trigger trg_items_financials after insert or update or delete on public.order_items
  for each row execute function public.trg_refresh_order_financials();
create trigger trg_payments_financials after insert or update or delete on public.payments
  for each row execute function public.trg_refresh_order_financials();

create or replace function public.trg_orders_discount_refresh()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.refresh_order_financials(new.id);
  return null;
end $$;
create trigger trg_orders_discount after update of discount on public.orders
  for each row when (old.discount is distinct from new.discount)
  execute function public.trg_orders_discount_refresh();

-- Payment must belong to the same press as its order.
create or replace function public.check_payment_tenant()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.orders o where o.id = new.order_id and o.press_id = new.press_id) then
    raise exception 'order does not belong to this press' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_payments_tenant before insert on public.payments
  for each row execute function public.check_payment_tenant();

-- ---------------------------------------------------------------------
-- Audit log (append-only)
-- ---------------------------------------------------------------------
create table public.audit_logs (
  id          bigint generated always as identity primary key,
  press_id    uuid references public.presses (id) on delete set null,
  actor_id    uuid,                                -- null = system / service role
  action      text not null,                       -- 'orders.update', 'auth.login', 'press.approve', ...
  entity_type text not null,
  entity_id   text,
  metadata    jsonb not null default '{}'::jsonb,
  ip          inet,
  user_agent  text,
  created_at  timestamptz not null default now()
);
create index idx_audit_press_created on public.audit_logs (press_id, created_at desc);
create index idx_audit_actor         on public.audit_logs (actor_id, created_at desc);
create index idx_audit_action        on public.audit_logs (action);

create or replace function public.audit_immutable()
returns trigger language plpgsql as $$
begin
  raise exception 'audit_logs is append-only' using errcode = '42501';
end $$;
create trigger trg_audit_no_update before update or delete on public.audit_logs
  for each row execute function public.audit_immutable();

-- Generic row-level audit trigger for critical tables.
create or replace function public.audit_row()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_row jsonb; v_press uuid; v_changes jsonb;
begin
  v_row := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  v_press := case when tg_table_name = 'presses' then (v_row ->> 'id')::uuid
                  else nullif(v_row ->> 'press_id', '')::uuid end;

  if tg_op = 'UPDATE' then
    select coalesce(jsonb_object_agg(n.key, jsonb_build_object('from', o.value, 'to', n.value)), '{}'::jsonb)
      into v_changes
      from jsonb_each(to_jsonb(new)) n
      left join jsonb_each(to_jsonb(old)) o on o.key = n.key
     where n.value is distinct from o.value and n.key <> 'updated_at';
  else
    v_changes := '{}'::jsonb;
  end if;

  insert into public.audit_logs (press_id, actor_id, action, entity_type, entity_id, metadata)
  values (
    v_press, auth.uid(), tg_table_name || '.' || lower(tg_op), tg_table_name, v_row ->> 'id',
    jsonb_build_object('source', 'db_trigger', 'changes', v_changes)
  );
  return null;
end $$;

create trigger audit_presses after insert or update or delete on public.presses
  for each row execute function public.audit_row();
create trigger audit_press_members after insert or update or delete on public.press_members
  for each row execute function public.audit_row();
create trigger audit_services after insert or update or delete on public.services
  for each row execute function public.audit_row();
create trigger audit_price_rules after insert or update or delete on public.price_rules
  for each row execute function public.audit_row();
create trigger audit_orders_ins after insert on public.orders
  for each row when (new.status <> 'draft') execute function public.audit_row();
create trigger audit_orders_upd after update of status, discount, assigned_to on public.orders
  for each row execute function public.audit_row();
create trigger audit_payments after insert or update on public.payments
  for each row execute function public.audit_row();

-- ---------------------------------------------------------------------
-- Platform settings
-- ---------------------------------------------------------------------
create table public.platform_settings (
  key        text primary key,
  value      jsonb not null,
  updated_by uuid references public.profiles (id),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Press registration: the ONLY way a user creates a tenant.
-- ---------------------------------------------------------------------
create or replace function public.register_press(p_name text, p_slug text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_press uuid;
begin
  if auth.uid() is null then
    raise exception 'authentication required' using errcode = '28000';
  end if;
  insert into public.presses (name, slug) values (trim(p_name), lower(trim(p_slug)))
  returning id into v_press;
  insert into public.press_members (press_id, user_id, role) values (v_press, auth.uid(), 'owner');
  return v_press;
end $$;
revoke all on function public.register_press(text, text) from public, anon;
grant execute on function public.register_press(text, text) to authenticated;

-- ---------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------
alter table public.profiles          enable row level security;
alter table public.plans             enable row level security;
alter table public.presses           enable row level security;
alter table public.press_members     enable row level security;
alter table public.services          enable row level security;
alter table public.price_rules       enable row level security;
alter table public.press_counters    enable row level security;   -- no policies: internal only
alter table public.orders            enable row level security;
alter table public.order_items       enable row level security;
alter table public.order_files       enable row level security;
alter table public.payments          enable row level security;
alter table public.audit_logs        enable row level security;
alter table public.platform_settings enable row level security;

-- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_super_admin() or public.shares_press_with(id));
create policy profiles_update_self on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- plans
create policy plans_select on public.plans for select to authenticated using (true);
create policy plans_admin_write on public.plans for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- presses (creation only via register_press or super admin)
create policy presses_select on public.presses for select to authenticated
  using (public.is_super_admin() or public.is_press_member(id));
create policy presses_update_staff on public.presses for update to authenticated
  using (public.has_press_role(id, array['owner','manager']::public.member_role[]))
  with check (public.has_press_role(id, array['owner','manager']::public.member_role[]));
create policy presses_admin_all on public.presses for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- press_members
create policy members_select on public.press_members for select to authenticated
  using (public.is_super_admin() or public.is_press_member(press_id));
create policy members_insert on public.press_members for insert to authenticated
  with check (
    public.has_press_role(press_id, array['owner']::public.member_role[])
    or (public.has_press_role(press_id, array['manager']::public.member_role[]) and role = 'staff')
  );
create policy members_update on public.press_members for update to authenticated
  using (
    public.has_press_role(press_id, array['owner']::public.member_role[])
    or (public.has_press_role(press_id, array['manager']::public.member_role[]) and role = 'staff')
  )
  with check (
    public.has_press_role(press_id, array['owner']::public.member_role[])
    or (public.has_press_role(press_id, array['manager']::public.member_role[]) and role = 'staff')
  );
create policy members_delete on public.press_members for delete to authenticated
  using (
    public.has_press_role(press_id, array['owner']::public.member_role[])
    or (public.has_press_role(press_id, array['manager']::public.member_role[]) and role = 'staff')
  );
create policy members_admin_all on public.press_members for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- services & price_rules: members read, owner/manager write, admin read
create policy services_select on public.services for select to authenticated
  using (public.is_super_admin() or public.is_press_member(press_id));
create policy services_write on public.services for all to authenticated
  using (public.has_press_role(press_id, array['owner','manager']::public.member_role[]))
  with check (public.has_press_role(press_id, array['owner','manager']::public.member_role[]));

create policy price_rules_select on public.price_rules for select to authenticated
  using (public.is_super_admin() or public.is_press_member(press_id));
create policy price_rules_write on public.price_rules for all to authenticated
  using (public.has_press_role(press_id, array['owner','manager']::public.member_role[]))
  with check (public.has_press_role(press_id, array['owner','manager']::public.member_role[]));

-- orders: created only by the server; members read/update; no deletes (cancel instead)
create policy orders_select on public.orders for select to authenticated
  using (status <> 'draft' and (public.is_super_admin() or public.is_press_member(press_id)));
create policy orders_update on public.orders for update to authenticated
  using (status <> 'draft' and public.is_press_member(press_id))
  with check (status <> 'draft' and public.is_press_member(press_id));

create policy order_items_select on public.order_items for select to authenticated
  using (public.is_super_admin() or public.is_press_member(press_id));
create policy order_files_select on public.order_files for select to authenticated
  using (verified and (public.is_super_admin() or public.is_press_member(press_id)));

-- payments: any member records; only owner/manager may void
create policy payments_select on public.payments for select to authenticated
  using (public.is_super_admin() or public.is_press_member(press_id));
create policy payments_insert on public.payments for insert to authenticated
  with check (public.is_press_member(press_id) and recorded_by = auth.uid());
create policy payments_void on public.payments for update to authenticated
  using (public.has_press_role(press_id, array['owner','manager']::public.member_role[]))
  with check (public.has_press_role(press_id, array['owner','manager']::public.member_role[]));

-- audit_logs: read-only to admins and press owners/managers; writes only via triggers/service role
create policy audit_select on public.audit_logs for select to authenticated
  using (
    public.is_super_admin()
    or (press_id is not null and public.has_press_role(press_id, array['owner','manager']::public.member_role[]))
  );

-- platform_settings: super admin only
create policy settings_admin_all on public.platform_settings for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- ---------------------------------------------------------------------
-- Privileges: anon gets nothing on tables; users cannot touch the audit log.
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon;
revoke insert, update, delete, truncate on public.audit_logs from authenticated;
revoke all on public.press_counters from authenticated;
revoke insert, delete on public.orders from authenticated;        -- orders are created by the server
revoke insert, update, delete on public.order_items from authenticated;
revoke insert, update, delete on public.order_files from authenticated;
revoke delete on public.payments from authenticated;
revoke insert, delete on public.profiles from authenticated;
revoke insert, delete on public.presses from authenticated;       -- use register_press()

-- ---------------------------------------------------------------------
-- Public storefront views: the ONLY data anonymous visitors can read.
-- Exposes safe columns of approved presses only.
-- ---------------------------------------------------------------------
create view public.storefronts as
select id, slug, name, description, logo_path, brand_color,
       email, phone, whatsapp, address, city, region, country,
       latitude, longitude, opening_hours, currency, timezone
from public.presses
where status = 'approved';

create view public.storefront_prices as
select r.press_id, s.id as service_id, s.name as service_name,
       s.description as service_description, s.category, s.sort_order,
       r.id as price_rule_id, r.label, r.paper_size, r.color_mode, r.sides,
       r.unit, r.unit_price, r.bulk_tiers
from public.price_rules r
join public.services s on s.id = r.service_id
join public.presses  p on p.id = r.press_id
where r.active and s.active and p.status = 'approved';

grant select on public.storefronts, public.storefront_prices to anon, authenticated;

-- ---------------------------------------------------------------------
-- Storage
--   order-files : PRIVATE. Path = {press_id}/{order_id}/{uuid}.{ext}
--                 Uploads happen via server-issued signed upload URLs.
--                 Reads happen via server-issued short-lived signed URLs.
--   press-logos : public read (logos are public branding); write by owner/manager.
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('order-files', 'order-files', false, 52428800, array[
     'application/pdf',
     'image/jpeg', 'image/png',
     'application/msword',
     'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
     'application/vnd.openxmlformats-officedocument.presentationml.presentation'
   ]),
  ('press-logos', 'press-logos', true, 2097152, array['image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

create or replace function public.storage_press_id(p_name text)
returns uuid language plpgsql immutable as $$
begin
  return ((storage.foldername(p_name))[1])::uuid;
exception when others then
  return null;
end $$;

-- Staff can read (never list publicly) their own press's order files.
create policy order_files_read on storage.objects for select to authenticated
  using (
    bucket_id = 'order-files'
    and public.storage_press_id(name) is not null
    and public.is_press_member(public.storage_press_id(name))
  );

-- No insert/update/delete policies on order-files: only the service role
-- (server) writes, after validating type, size, and press ownership.

create policy logos_write on storage.objects for insert to authenticated
  with check (
    bucket_id = 'press-logos'
    and public.storage_press_id(name) is not null
    and public.has_press_role(public.storage_press_id(name), array['owner','manager']::public.member_role[])
  );
create policy logos_update on storage.objects for update to authenticated
  using (
    bucket_id = 'press-logos'
    and public.storage_press_id(name) is not null
    and public.has_press_role(public.storage_press_id(name), array['owner','manager']::public.member_role[])
  );
create policy logos_delete on storage.objects for delete to authenticated
  using (
    bucket_id = 'press-logos'
    and public.storage_press_id(name) is not null
    and public.has_press_role(public.storage_press_id(name), array['owner','manager']::public.member_role[])
  );

-- ---------------------------------------------------------------------
-- Baseline data
-- ---------------------------------------------------------------------
insert into public.plans (code, name, monthly_price, limits) values
  ('free',  'Free',  0,   '{"staff": 2,  "orders_per_month": 100}'),
  ('pro',   'Pro',   150, '{"staff": 10, "orders_per_month": 2000}')
on conflict (code) do nothing;

insert into public.platform_settings (key, value) values
  ('registration_open',    'true'),
  ('require_press_approval','true')
on conflict (key) do nothing;
